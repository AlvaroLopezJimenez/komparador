<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\OfertaProductoController;
use App\Http\Controllers\BuscadorController;
use App\Http\Controllers\TiendaController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\AvisoController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClickController;
use App\Http\Controllers\Admin\ImagenController;
use App\Models\Producto;
use App\Models\EjecucionHistoricoPrecioProducto;
use Carbon\Carbon;
use App\Models\HistoricoPrecioProducto;

require __DIR__ . '/auth.php';

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// SITEMAPS
Route::get('/sitemap.xml', [App\Http\Controllers\SitemapController::class, 'index']);
Route::get('/sitemap-categorias.xml', [App\Http\Controllers\SitemapController::class, 'categorias']);
Route::get('/sitemap-productos.xml', [App\Http\Controllers\SitemapController::class, 'productos']);

//GENERAR CONTENIDO DE PRODUCTOS AUTOMATICAMENTE CON CHATGPT - LO PONGO FUERA PORQUE SI LO DEJO DENTRO DEL AUTH NO FUNCIONA
Route::middleware('throttle:4,1')->group(function () {
    Route::post('productos/generar-contenido', [ProductoController::class, 'generarContenido'])->name('productos.generar-contenido');
});

// RUTAS PARA POLÍTICAS Y LEGAL
Route::prefix('politicas')->name('politicas.')->group(function () {
    Route::get('/contacto', function () {
        return view('politicas.contacto');
    })->name('contacto');
    
    Route::get('/aviso-legal', function () {
        return view('politicas.aviso-legal');
    })->name('aviso-legal');
    
    Route::get('/privacidad', function () {
        return view('politicas.politica-privacidad');
    })->name('privacidad');
    
    Route::get('/cookies', function () {
        return view('politicas.politica-cookies');
    })->name('cookies');
});

Route::middleware('throttle:10,1')->group(function () {
//PARA REDIRIGIR AL USUARIO A LA TIENDA - AQUI CARGA LA PAGINA INTERMEDIA
Route::get('/redirigir/{ofertaId}', [ClickController::class, 'redirigir'])->name('click.redirigir');
});


Route::middleware('throttle:10,1')->group(function () {
    // BÚSQUEDA PÚBLICA
    Route::get('/buscar', [BuscadorController::class, 'buscar'])->name('buscar');
    Route::get('/api/buscar-productos', [BuscadorController::class, 'productos'])->name('api.buscar.productos');
});

// Scraper de ofertas en segundo plano
Route::get('ofertas/scraper/ejecutar-segundo-plano', function (Request $request) {
    if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
        abort(403, 'Token inválido');
    }
    return app(\App\Http\Controllers\OfertaProductoController::class)->ejecutarScraperOfertasSegundoPlano($request);
});

// Rutas para scraping de ofertas
Route::prefix('scraping')->name('scraping.')->group(function () {
    Route::post('/obtener-precio', [App\Http\Controllers\Scraping\ScrapingController::class, 'obtenerPrecio'])->name('obtener-precio');
});


// RUTA PARA CATEGORÍAS INDIVIDUALES (MÁS ESPECÍFICA)
Route::get('/categoria/{slug}', [App\Http\Controllers\HomeController::class, 'showCategoria'])->name('categoria.show');

// Rutas para testing de scraping (solo admin)
Route::middleware(['auth', 'verified'])->prefix('admin/scraping')->name('admin.scraping.')->group(function () {
    // Vistas
    Route::get('/ejecucion-tiempo-real', [App\Http\Controllers\Scraping\EjecucionTiempoRealController::class, 'index'])->name('ejecucion-tiempo-real');
    
    Route::get('/test', [App\Http\Controllers\Scraping\TestScrapingController::class, 'index'])->name('test');
    Route::get('/test-precio', [App\Http\Controllers\Scraping\TestPrecioController::class, 'index'])->name('test.precio');
    Route::get('/diagnostico', [App\Http\Controllers\Scraping\DiagnosticoController::class, 'index'])->name('diagnostico');
    // APIs
    Route::post('/test/procesar', [App\Http\Controllers\Scraping\TestScrapingController::class, 'procesarUrl'])->name('test.procesar');
    Route::post('/test-precio/procesar', [App\Http\Controllers\Scraping\TestPrecioController::class, 'procesarUrl'])->name('test.precio.procesar');
    Route::get('/ejecucion-tiempo-real/iniciar', [App\Http\Controllers\Scraping\EjecucionTiempoRealController::class, 'iniciar'])->name('ejecucion-tiempo-real.iniciar');
    Route::post('/ejecucion-tiempo-real/procesar-siguiente', [App\Http\Controllers\Scraping\EjecucionTiempoRealController::class, 'procesarSiguiente'])->name('ejecucion-tiempo-real.procesar-siguiente');
    Route::get('/ejecucion-tiempo-real/estado', [App\Http\Controllers\Scraping\EjecucionTiempoRealController::class, 'obtenerEstado'])->name('ejecucion-tiempo-real.estado');
    Route::post('/ejecucion-tiempo-real/marcar-completada', [App\Http\Controllers\Scraping\EjecucionTiempoRealController::class, 'marcarCompletada'])->name('ejecucion-tiempo-real.marcar-completada');
    Route::get('/ofertas-errores-exitos', [App\Http\Controllers\Scraping\DiagnosticoController::class, 'ofertasErroresExitos'])->name('ofertas-errores-exitos');
    Route::get('/test-api', [App\Http\Controllers\Scraping\TestController::class, 'test'])->name('test.api');
    Route::get('/test-error', [App\Http\Controllers\Scraping\TestController::class, 'testError'])->name('test.error');
});


// RUTAS PARA CRON (sin autenticación, protegidas por token)
Route::prefix('admin')->group(function () {
    // Actualizar clicks de ofertas
    Route::get('clicks/actualizar-ofertas', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\OfertaProductoController::class)->actualizarClicksOfertas();
    });

    // Guardar histórico de precios de productos
    Route::get('historico/guardar-productos', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\ProductoController::class)->guardarHistoricoPrecios();
    });

    // Calcular precios hot
    Route::get('precios-hot/calcular', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\ProductoController::class)->calcularPreciosHot();
    });

    // Actualizar clicks de categorías
    Route::get('categorias/actualizar-clicks/procesar', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\CategoriaClicksController::class)->procesar();
    });

    // Actualizar clicks de productos
    Route::get('productos/actualizar-clicks/procesar', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\ProductoController::class)->actualizarClicks();
    });

    // Histórico de precios de ofertas
    Route::get('ofertas/historico-precios/ejecutar', function (Request $request) {
        if ($request->get('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }
        return app(\App\Http\Controllers\OfertaProductoController::class)->ejecutarHistoricoPrecios();
    });
});

// PARA PANEL ADMIN - NUEVO GRUPO CON MIDDLEWARE
Route::middleware(['web', 'auth', 'ensure_session'])->prefix('panel-privado')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // RUTA DE PRUEBA TEMPORAL - ELIMINAR DESPUÉS
    Route::get('/test-auth', function() {
        return 'Middleware auth funcionando correctamente';
    })->name('test.auth');

    Route::resource('productos', ProductoController::class);

    Route::get('profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    //PARA LA GRAFICA DE CLICK EN PRODUCTO
    Route::get('productos/{producto}/estadisticas/clicks', [ProductoController::class, 'datosClicks'])->name('productos.estadisticas.clicks');
    //PANEL ESTADISTICAS DE CLICKS PARA PRODUCTO
    Route::get('productos/{producto}/estadisticas-avanzadas', [ClickController::class, 'estadisticasAvanzadas'])
        ->name('productos.estadisticas.avanzadas');
    Route::get('productos/{producto}/clicks/rango-precio', [ClickController::class, 'rangoPrecio']);
    Route::get('productos/{producto}/clicks/por-hora', [ClickController::class, 'porHora']);
    Route::get('productos/{producto}/clicks/tiendas', [ClickController::class, 'tiendas']);
    Route::get('clics', [ClickController::class, 'index'])->name('clics.index');

    // OFERTAS - LISTADOS Y FORMULARIOS

    // Ruta para ver todas las ofertas (sin producto asociado)
    Route::get('ofertas', [OfertaProductoController::class, 'todas'])->name('ofertas.todas');

    // Ruta para crear una oferta sin producto
    Route::get('ofertas/create', [OfertaProductoController::class, 'createGeneral'])->name('ofertas.create.formularioGeneral');

    // Ruta para ver las ofertas de un producto concreto
    Route::get('productos/{producto}/ofertas', [OfertaProductoController::class, 'index'])->name('ofertas.index');

    // Formulario para crear una nueva oferta para un producto concreto
    Route::get('productos/{producto}/ofertas/create', [OfertaProductoController::class, 'create'])->name('ofertas.create');

    // Envía el formulario de creación de una nueva oferta
    Route::post('ofertas', [OfertaProductoController::class, 'store'])->name('ofertas.store');

    // Formulario para editar una oferta ya existente
    Route::get('ofertas/{oferta}/edit', [OfertaProductoController::class, 'edit'])->name('ofertas.edit');

    // Envía el formulario de edición de una oferta
    Route::put('ofertas/{oferta}', [OfertaProductoController::class, 'update'])->name('ofertas.update');

    // Elimina una oferta concreta
    Route::delete('ofertas/{oferta}', [OfertaProductoController::class, 'destroy'])->name('ofertas.destroy');

    // BÚSQUEDA INTERACTIVA PARA FORMULARIOS (no eliminar)

    // Devuelve listado JSON de productos para el selector
    Route::get('buscador-producto', [BuscadorController::class, 'productos']);

    // Devuelve listado JSON de tiendas para el selector
    Route::get('buscador-tienda', [BuscadorController::class, 'tiendas']);

    //TIENDAS

    Route::get('tiendas', [TiendaController::class, 'index'])->name('tiendas.index');

    Route::get('tiendas/create', [TiendaController::class, 'create'])->name('tiendas.create');

    Route::get('tiendas/{tienda}/edit', [TiendaController::class, 'edit'])->name('tiendas.edit');

    Route::post('tiendas', [TiendaController::class, 'store'])->name('tiendas.store');

    Route::put('tiendas/{tienda}', [TiendaController::class, 'update'])->name('tiendas.update');

    Route::delete('tiendas/{tienda}', [TiendaController::class, 'destroy'])->name('tiendas.destroy');

    //Listar ofertas de una tienda en especifico
    Route::get('tiendas/{tienda}/ofertas', [TiendaController::class, 'ofertas'])->name('tiendas.ofertas');

    //CATEGORIAS SUBCATEGORIAS SUBSUBCATEGORIAS
    Route::get('categorias/{parentId}/subcategorias', [CategoriaController::class, 'subcategorias'])
        ->name('categorias.subcategorias');
    Route::get('categorias/{categoriaId}/jerarquia', [CategoriaController::class, 'jerarquia'])
        ->name('categorias.jerarquia');
    
    Route::get('categorias', [CategoriaController::class, 'index'])->name('categorias.index');
    Route::post('categorias', [CategoriaController::class, 'store'])->name('categorias.store');
    
    Route::delete('categorias/{categoria}', [CategoriaController::class, 'destroy'])->name('categorias.destroy');
    Route::post('categorias/{categoria}/editar-nombre', [CategoriaController::class, 'updateNombre'])->name('categorias.updateNombre');

    //Historico de productos
    Route::get('productos/{producto}/estadisticas', [ProductoController::class, 'estadisticas'])->name('productos.estadisticas');
    Route::get('productos/{producto}/estadisticas/datos', [ProductoController::class, 'datosHistorico'])->name('productos.estadisticas.datos');

    // ACTUALIZACIÓN DE CLICKS DE PRODUCTOS
    Route::get('productos/actualizar-clicks/ejecutar', [ProductoController::class, 'ejecucionActualizarClicks'])->name('productos.actualizar.clicks.ejecutar');
    Route::post('productos/actualizar-clicks/procesar', [ProductoController::class, 'actualizarClicks'])->name('productos.actualizar.clicks.procesar');
    Route::get('productos/actualizar-clicks/ejecuciones', [ProductoController::class, 'indexEjecucionesClicks'])->name('productos.actualizar.clicks.ejecuciones');

    // GESTIÓN DE IMÁGENES
    Route::middleware('verificar.imagenes')->group(function () {
        Route::post('imagenes/subir', [App\Http\Controllers\Admin\ImagenController::class, 'subir'])->name('imagenes.subir');
        Route::get('imagenes/listar', [App\Http\Controllers\Admin\ImagenController::class, 'listar'])->name('imagenes.listar');
        Route::delete('imagenes/eliminar', [App\Http\Controllers\Admin\ImagenController::class, 'eliminar'])->name('imagenes.eliminar');
        Route::get('imagenes/carpetas', [App\Http\Controllers\Admin\ImagenController::class, 'carpetasDisponibles'])->name('imagenes.carpetas');
    });
    Route::get('productos/actualizar-clicks/ejecuciones/{id}/json', [ProductoController::class, 'obtenerJsonEjecucionClicks'])->name('productos.actualizar.clicks.ejecucion.json');
    Route::delete('productos/actualizar-clicks/ejecuciones/{id}', [ProductoController::class, 'eliminarEjecucionClicks'])->name('productos.actualizar.clicks.ejecucion.eliminar');

    // ACTUALIZACIÓN DE CLICKS DE CATEGORÍAS
    Route::get('categorias/actualizar-clicks/ejecutar', [App\Http\Controllers\CategoriaClicksController::class, 'ejecutar'])->name('categorias.actualizar.clicks.ejecutar');
    Route::post('categorias/actualizar-clicks/procesar', [App\Http\Controllers\CategoriaClicksController::class, 'procesar'])->name('categorias.actualizar.clicks.procesar');
    Route::get('categorias/actualizar-clicks/ejecuciones', [App\Http\Controllers\CategoriaClicksController::class, 'ejecuciones'])->name('categorias.actualizar.clicks.ejecuciones');

    // ACTUALIZACIÓN DE CLICKS DE OFERTAS
    Route::get('ofertas/actualizar-clicks/ejecutar', [OfertaProductoController::class, 'ejecutarActualizarClicksOfertas'])->name('ofertas.actualizar.clicks.ejecutar');
    Route::post('ofertas/actualizar-clicks/procesar', [OfertaProductoController::class, 'procesarClicksOfertas'])->name('ofertas.actualizar.clicks.procesar');
    Route::get('ofertas/actualizar-clicks/ejecuciones', [OfertaProductoController::class, 'ejecucionesClicksOfertas'])->name('ofertas.actualizar.clicks.ejecuciones');
    Route::get('productos/productos/guardadohistoricoprecio', [ProductoController::class, 'indexEjecucionesHistorico'])
        ->name('productos.historico.ejecuciones');
    Route::get('productos/historico-precios/ejecuciones/{id}/log', function ($id) {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_productos')
            ->findOrFail($id);
        return response()->json([
            'log' => $ejecucion->log ?? [],
        ]);
    })->name('productos.historico.ejecucion.log');
    Route::get('productos/historico-precios/lista', function () {
        $productos = Producto::select('id', 'nombre', 'precio')->get();

        return response()->json([
            'productos' => $productos,
        ]);
    })->name('productos.historico.lista');
    Route::get('productos/historico-precios/ejecutar/ver', function () {
        return view('admin.productos.ejecucionGuardadoPrecios');
    })->name('precios.actualizar.ver');
    Route::post('productos/historico-precios/ejecuciones/eliminar-antiguas', [ProductoController::class, 'eliminarAntiguas'])->name('ejecuciones.eliminar.antiguas');
    Route::delete('productos/historico-precios/ejecuciones/{ejecucion}', [ProductoController::class, 'eliminar'])->name('ejecuciones.eliminar');
    Route::get('productos/{producto}/historial-mes', [ProductoController::class, 'historialMes'])->name('productos.historial.mes');
    Route::post('productos/{producto}/historial-guardar', [ProductoController::class, 'historialGuardar'])->name('productos.historial.guardar');
    Route::post('productos/buscar-relacionados', [ProductoController::class, 'buscarRelacionados']);
    

    //Historico de ofertas

    Route::get('ofertas/{oferta}/estadisticas', [OfertaProductoController::class, 'estadisticas'])->name('ofertas.estadisticas');
    Route::get('ofertas/{oferta}/estadisticas/datos', [OfertaProductoController::class, 'estadisticasDatos'])->name('ofertas.estadisticas.datos');
    // Ver modal de ejecución en tiempo real
    Route::get('ofertas/historico-precios/ejecutar/ver', function () {
        return view('admin.ofertas.ejecucionGuardadoPrecios');
    })->name('ofertas.historico.ver');
    //////// Lista de todas las ofertas a procesar
    Route::get('ofertas/historico-precios/lista', [OfertaProductoController::class, 'listaOfertas'])->name('ofertas.historico.lista');
    //////// Guardar resultado de la ejecución
    Route::post('ofertas/historico-precios/finalizar', [OfertaProductoController::class, 'finalizarEjecucion'])->name('ofertas.historico.finalizar');
    //////// Procesar una oferta individual
    Route::post('ofertas/historico-precios/procesar', [OfertaProductoController::class, 'procesarOferta'])->name('ofertas.historico.procesar');
    //////// Ver historial de ejecuciones
    Route::get('ofertas/historico-precios/ejecuciones', [OfertaProductoController::class, 'indexEjecucionesHistorico'])->name('ofertas.historico.ejecuciones');
    //////// Ver log JSON de una ejecución concreta
    Route::get('ofertas/historico-precios/ejecuciones/{id}/log', function ($id) {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_ofertas')
            ->findOrFail($id);
        return response()->json(['log' => $ejecucion->log ?? []]);
    })->name('ofertas.historico.ejecucion.log');
    ////////// Eliminar ejecuciones antiguas
    Route::post('ofertas/historico-precios/ejecuciones/eliminar-antiguas', [OfertaProductoController::class, 'eliminarAntiguas'])->name('ofertas.ejecuciones.eliminar.antiguas');
    //////// Eliminar una ejecución concreta
    Route::delete('ofertas/historico-precios/ejecuciones/{ejecucion}', [OfertaProductoController::class, 'eliminar'])->name('ofertas.ejecuciones.eliminar');
    Route::get('ofertas/historico-precios/ejecutar', [OfertaProductoController::class, 'segundoPlanoGuardarPrecioHistoricoHoy'])
        ->name('ofertas.historico.ejecutar');
    //////// Mostrar modal calendario de historial mensual de una oferta
    Route::get('ofertas/{oferta}/historial-mes', [OfertaProductoController::class, 'historialMes'])->name('ofertas.historial.mes');
    //////// Guardar cambios en el historial de precios de una oferta
    Route::post('ofertas/{oferta}/historial-guardar', [OfertaProductoController::class, 'historialGuardar'])->name('ofertas.historial.guardar');

    //Listo de avisos
    Route::prefix('avisos')->name('avisos.')->group(function () {
        Route::get('/', [AvisoController::class, 'index'])->name('index');
        Route::delete('/{tipo}/{id}', [AvisoController::class, 'eliminar'])->name('eliminar');
    });

    // RUTAS PARA SCRAPER DE OFERTAS
    // Ejecución en segundo plano (para cron jobs)
    Route::get('ofertas/scraper/ejecutar-segundo-plano', [OfertaProductoController::class, 'ejecutarScraperOfertasSegundoPlano'])->name('ofertas.scraper.ejecutar.segundo-plano');

    // Historial de ejecuciones
    Route::get('ofertas/scraper/ejecuciones', [OfertaProductoController::class, 'indexEjecucionesScraper'])->name('ofertas.scraper.ejecuciones');
    Route::delete('ofertas/scraper/ejecuciones/{ejecucion}', [OfertaProductoController::class, 'eliminarEjecucionScraper'])->name('ofertas.scraper.ejecuciones.eliminar');
    Route::get('ofertas/scraper/ejecuciones/{ejecucion}/json', [OfertaProductoController::class, 'obtenerJsonEjecucionScraper'])->name('ofertas.scraper.ejecuciones.json');

    // Obtener precio individual desde formulario
    Route::post('ofertas/scraper/obtener-precio', [OfertaProductoController::class, 'obtenerPrecioIndividual'])->name('ofertas.scraper.obtener-precio');

    // RUTAS PARA PRECIOS HOT
    // Ejecución en segundo plano (para cron jobs)
    Route::get('precios-hot/ejecutar-segundo-plano', [App\Http\Controllers\PrecioHotController::class, 'ejecutarSegundoPlano'])->name('precios-hot.ejecutar.segundo-plano');



    // Ejecución en tiempo real (con interfaz)
    Route::get('precios-hot/ejecutar', [App\Http\Controllers\PrecioHotController::class, 'verEjecucion'])->name('precios-hot.ejecutar');

    // Historial de ejecuciones
    Route::get('precios-hot/ejecuciones', [App\Http\Controllers\PrecioHotController::class, 'ejecuciones'])->name('precios-hot.ejecuciones');

    //Guardar los precios de todos los productos en segundo plano
    Route::get('productos/historico-precios/ejecutar', function (Request $request) {
        if ($request->query('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }

        // Crear ejecución
        $ejecucion = EjecucionHistoricoPrecioProducto::create([
            'inicio' => now(),
            'log' => [],
        ]);

        $productos = \App\Models\Producto::all();
        $guardados = 0;
        $errores = 0;
        $log = [];

        foreach ($productos as $producto) {
            try {
                // Simulación: obtiene un precio aleatorio
                $precio = $producto->precio ?? rand(10, 100);

                DB::table('historico_precios_productos')->updateOrInsert(
                    [
                        'producto_id' => $producto->id,
                        'fecha' => now()->toDateString(),
                    ],
                    [
                        'precio_minimo' => $precio,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]
                );

                $guardados++;
            } catch (\Throwable $e) {
                $errores++;
                $log[] = [
                    'producto_id' => $producto->id,
                    'nombre' => $producto->nombre,
                    'error' => $e->getMessage(),
                ];
            }
        }

        $ejecucion->update([
            'fin' => now(),
            'total_productos' => count($productos),
            'total_guardados' => $guardados,
            'total_errores' => $errores,
            'log' => $log,
        ]);

        return response()->json([
            'status' => 'ok',
            'guardados' => $guardados,
            'errores' => $errores,
        ]);
    });

    Route::post('productos/historico-precios/procesar', function (Request $request) {
        $producto = Producto::findOrFail($request->input('id'));
        $forzar = $request->boolean('forzar', false); // si se permite actualizar un precio ya registrado
        $fecha = now()->toDateString();

        // Verificar si ya existe
        $existe = DB::table('historico_precios_productos')
            ->where('producto_id', $producto->id)
            ->where('fecha', $fecha)
            ->exists();

        if ($existe && !$forzar) {
            return response()->json([
                'status' => 'existe',
                'producto_id' => $producto->id,
                'nombre' => $producto->nombre,
            ]);
        }

        try {
            DB::table('historico_precios_productos')->updateOrInsert(
                [
                    'producto_id' => $producto->id,
                    'fecha' => $fecha,
                ],
                [
                    'precio_minimo' => $producto->precio ?? 0,
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );

            return response()->json([
                'status' => $existe ? 'actualizado' : 'guardado',
                'producto_id' => $producto->id,
                'nombre' => $producto->nombre,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => 'error',
                'producto_id' => $producto->id,
                'nombre' => $producto->nombre,
                'error' => $e->getMessage(),
            ]);
        }
    })->name('productos.historico.procesar');

    Route::post('productos/historico-precios/finalizar-ejecucion', function (Request $request) {
        \App\Models\EjecucionGlobal::create([
            'inicio' => now(), // puedes guardar esto aparte si quieres precisión
            'fin' => now(),
            'nombre' => 'ejecuciones_historico_precios_productos',
            'total' => $request->input('total'),
            'total_guardado' => $request->input('correctos'),
            'total_errores' => $request->input('errores'),
            'log' => $request->input('log', []),
        ]);

        return response()->json(['status' => 'ok']);
    })->name('productos.historico.finalizar');
});

// Ruta de redirección para mantener compatibilidad
Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', fn() => redirect()->route('admin.dashboard'))->name('dashboard');
});

// // RUTA DE PRUEBA CON PATRÓN IDÉNTICO AL GRUPO PROBLEMÁTICO - ELIMINAR DESPUÉS
// Route::middleware(['auth'])->prefix('panel-privado')->group(function () {
//     Route::get('/test-grupo', function() {
//         return 'Grupo de rutas funcionando correctamente';
//     })->name('test.grupo');
// });

// CATEGORÍAS PÚBLICAS (MOVIDA AL FINAL PARA EVITAR CONFLICTOS)
Route::get('/categorias', [App\Http\Controllers\HomeController::class, 'todasCategorias'])->name('categorias.todas');


// RUTA DINÁMICA PARA PRODUCTOS CON MÚLTIPLES CATEGORÍAS (DEBE IR ANTES)
Route::get('/{categorias}/{slug}', function ($categorias, $slug) {
    // Dividir las categorías en un array
    $slugsRuta = explode('/', $categorias);
    
    // Buscar el producto por slug
    $producto = \App\Models\Producto::with('categoria')->where('slug', $slug)->firstOrFail();
    
    // Obtener la jerarquía completa de categorías del producto
    $jerarquiaCompleta = $producto->categoria->obtenerJerarquiaCompleta();
    $slugsReales = collect($jerarquiaCompleta)->pluck('slug')->toArray();
    
    // Verificar si la URL coincide con la jerarquía real
    if ($slugsRuta !== $slugsReales) {
        // Construir la URL correcta con todas las categorías
        $categoriasCorrectas = implode('/', $slugsReales);
        return redirect("/{$categoriasCorrectas}/{$slug}", 301);
    }

    $desde = Carbon::today()->subDays(364);

$historico = HistoricoPrecioProducto::where('producto_id', $producto->id)
    ->where('fecha', '>=', $desde)
    ->orderBy('fecha')
    ->get()
    ->mapWithKeys(fn($item) => [
        Carbon::parse($item->fecha)->toDateString() => (float) $item->precio_minimo
    ]);

$precios = [];
for ($i = 0; $i < 365; $i++) {
    $fechaObj = Carbon::today()->subDays(364 - $i);
    $fechaYMD = $fechaObj->toDateString();
    $fechaDM = $fechaObj->format('d/m');

    $precios[] = [
        'fecha' => $fechaDM,
        'precio' => isset($historico[$fechaYMD]) ? (float) $historico[$fechaYMD] : 0,
    ];
}

    $ofertas = $producto->ofertas()->with('tienda')->where('mostrar', 'sí')->orderBy('precio_unidad')->get();

    // Construir breadcrumb dinámicamente desde la jerarquía completa
    $breadcrumb = collect($jerarquiaCompleta)->map(function ($categoria) {
        return [
            'nombre' => $categoria->nombre,
            'slug' => $categoria->slug
        ];
    })->toArray();

    $relacionados = Producto::where('id', '!=', $producto->id)
        ->where('categoria_id', $producto->categoria_id)
        ->get()
        ->filter(function ($rel) use ($producto) {
            $coincidencias = 0;
            foreach ($producto->keys_relacionados ?? [] as $tag) {
                $coincidencias += collect([$rel->marca, $rel->modelo, $rel->talla])
                    ->filter(fn($v) => Str::of($v)->lower()->contains(Str::of($tag)->lower()))
                    ->count();
            }
            $rel->coincidencias = $coincidencias;
            return $coincidencias > 0;
        })
        ->sortByDesc('coincidencias')
        ->sortBy('precio')
        ->take(10)
        ->values();

    // Obtener productos por debajo del precio medio
    $productosPrecioMedio = collect();
    $precioHot = \App\Models\PrecioHot::where('nombre', $producto->categoria->nombre)->first();
    
    if ($precioHot && !empty($precioHot->datos)) {
        $productosPrecioMedio = collect($precioHot->datos)
            ->take(10)
            ->map(function ($item) {
                $producto = \App\Models\Producto::find($item['producto_id']);
                if ($producto) {
                    return [
                        'producto' => $producto,
                        'oferta_id' => $item['oferta_id'],
                        'tienda_id' => $item['tienda_id'],
                        'img_tienda' => $item['img_tienda'],
                        'img_producto' => $item['img_producto'],
                        'precio_oferta' => $item['precio_oferta'],
                        'porcentaje_diferencia' => $item['porcentaje_diferencia'],
                        'url_oferta' => $item['url_oferta'],
                        'url_producto' => $item['url_producto'],
                        'producto_nombre' => $item['producto_nombre'],
                        'tienda_nombre' => $item['tienda_nombre']
                    ];
                }
            })->filter()->values();
    }

    // Obtener productos de Precios Hot generales
    $productosPreciosHot = collect();
    $precioHotGeneral = \App\Models\PrecioHot::where('nombre', 'Precios Hot')->first();
    
    if ($precioHotGeneral && !empty($precioHotGeneral->datos)) {
        $productosPreciosHot = collect($precioHotGeneral->datos)
            ->take(10)
            ->map(function ($item) {
                $producto = \App\Models\Producto::find($item['producto_id']);
                if ($producto) {
                    return [
                        'producto' => $producto,
                        'oferta_id' => $item['oferta_id'],
                        'tienda_id' => $item['tienda_id'],
                        'img_tienda' => $item['img_tienda'],
                        'img_producto' => $item['img_producto'],
                        'precio_oferta' => $item['precio_oferta'],
                        'porcentaje_diferencia' => $item['porcentaje_diferencia'],
                        'url_oferta' => $item['url_oferta'],
                        'url_producto' => $item['url_producto'],
                        'producto_nombre' => $item['producto_nombre'],
                        'tienda_nombre' => $item['tienda_nombre']
                    ];
                }
                return null;
            })->filter()->values();
    }

    return view('comparador.unidades', compact('producto', 'ofertas', 'breadcrumb', 'relacionados', 'productosPrecioMedio', 'productosPreciosHot', 'precios'));
})->where('categorias', '.*')->where('slug', '.*');