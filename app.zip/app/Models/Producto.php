<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    protected $table = 'productos';

    protected $fillable = [
        'nombre',
        'marca',
        'modelo',
        'talla',
        'precio',
        'unidadDeMedida',
        'imagen_grande',
        'imagen_pequena',
        'titulo',
        'subtitulo',
        'descripcion_corta',
        'descripcion_larga',
        'caracteristicas',
        'pros',
        'contras',
        'faq',
        'slug',
        'categoria_id',
        'meta_titulo',
        'meta_description',
        'obsoleto',
        'clicks',
        'keys_relacionados',
        'anotaciones_internas',
        'aviso',
    ];

    protected $casts = [
        'caracteristicas' => 'array',
        'pros' => 'array',
        'contras' => 'array',
        'faq' => 'array',
        'keys_relacionados' => 'array',
        'aviso' => 'datetime',
    ];

    public function ofertas()
    {
        return $this->hasMany(OfertaProducto::class);
    }

    public function historico()
    {
        return $this->hasMany(\App\Models\HistoricoPrecioProducto::class);
    }

    public function categoria()
    {
        return $this->belongsTo(Categoria::class, 'categoria_id');
    }

    public function palabrasClave()
    {
        return $this->hasMany(PalabraClaveProducto::class);
    }

    // Sacamos la ruta completa de categorias de un producto con su slug
    public function getRutaCompletaAttribute()
{
    $categorias = [];
    $categoria = $this->categoria;

    while ($categoria) {
        array_unshift($categorias, $categoria->slug);
        $categoria = $categoria->parent;
    }

    return implode('/', $categorias) . '/' . $this->slug;
}
}
