<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OfertaProducto extends Model
{
    protected $table = 'ofertas_producto';

    protected $fillable = [
        'producto_id',
        'tienda_id',
        'unidades',
        'precio_total',
        'frecuencia_actualizar_precio_minutos',
        'precio_unidad',
        'url',
        'variante',
        'mostrar',
        'anotaciones_internas',
        'aviso',
        'clicks',
    ];

    public function producto()
    {
        return $this->belongsTo(Producto::class);
    }

    public function tienda()
    {
        return $this->belongsTo(Tienda::class);
    }
}
