<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto;
use Illuminate\Support\Str;

class BuscadorController extends Controller
{
    public function productos(Request $request)
    {

        $request->validate([
            'q' => 'required|string|min:2|max:50'
        ]);

        $query = $request->get('q', '');
        
        if (empty($query)) {
            return response()->json([]);
        }

        $productos = Producto::where('obsoleto', 'no')
            ->where(function($q) use ($query) {
                $q->whereRaw('LOWER(nombre) LIKE ?', ['%' . strtolower($query) . '%'])
                  ->orWhereRaw('LOWER(marca) LIKE ?', ['%' . strtolower($query) . '%'])
                  ->orWhereRaw('LOWER(modelo) LIKE ?', ['%' . strtolower($query) . '%'])
                  ->orWhereRaw('LOWER(talla) LIKE ?', ['%' . strtolower($query) . '%']);
            })
            ->orderBy('clicks', 'desc')
            ->limit(7)
            ->with('categoria.parent.parent') // en caso de sub-sub-categoría
            ->get()
            ->map(function ($producto) {
                return [
                    'nombre' => $producto->nombre,
                    'slug' => $producto->slug,
                    'imagen_pequena' => $producto->imagen_pequena,
                    'precio' => $producto->precio,
                    'unidadDeMedida' => $producto->unidadDeMedida,
                    'url' => '/' . $producto->ruta_completa, // usa el accesor
                ];
            });


        return response()->json($productos);
    }

    public function tiendas(Request $request)
    {
        $query = $request->get('q', '');
        
        if (empty($query)) {
            return response()->json([]);
        }

        $tiendas = \App\Models\Tienda::whereRaw('LOWER(nombre) LIKE ?', ['%' . strtolower($query) . '%'])
            ->limit(10)
            ->get(['id', 'nombre']);

        return response()->json($tiendas);
    }

    public function buscar(Request $request)
    {
        $query = $request->get('q', '');
        
        if (empty($query)) {
            return redirect()->route('welcome');
        }

        $productos = Producto::where('obsoleto', 'no')
            ->where(function($q) use ($query) {
                $q->whereRaw('LOWER(nombre) LIKE ?', ['%' . strtolower($query) . '%'])
                ->orWhereRaw('LOWER(marca) LIKE ?', ['%' . strtolower($query) . '%'])
                ->orWhereRaw('LOWER(modelo) LIKE ?', ['%' . strtolower($query) . '%'])
                ->orWhereRaw('LOWER(talla) LIKE ?', ['%' . strtolower($query) . '%']);
            })

            ->orderBy('clicks', 'desc')
            ->paginate(20);

        return view('buscar', compact('productos', 'query'));
    }
}
