<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ImagenController extends Controller
{
    /**
     * Subir una imagen a la carpeta especificada
     */
    public function subir(Request $request)
    {
        try {
            $request->validate([
                'imagen' => 'required|image|mimes:jpeg,png,jpg,gif,webp|max:5120', // 5MB máximo
                'carpeta' => 'required|string'
            ]);

            $imagen = $request->file('imagen');
            $carpeta = $request->input('carpeta');

            if (!$imagen || !$imagen->isValid()) {
                return response()->json([
                    'success' => false,
                    'message' => 'El archivo temporal no es válido o no se recibió correctamente'
                ], 400);
            }

            $extension = $imagen->getClientOriginalExtension();
            $nombreArchivo = Str::slug(pathinfo($imagen->getClientOriginalName(), PATHINFO_FILENAME)) . '_' . time() . '.' . $extension;

            // Guardar usando el disco web_images
            Storage::disk('web_images')->putFileAs($carpeta, $imagen, $nombreArchivo);

            $rutaRelativa = $carpeta . '/' . $nombreArchivo;
            $url = Storage::disk('web_images')->url($rutaRelativa);

            return response()->json([
                'success' => true,
                'data' => [
                    'nombre' => $nombreArchivo,
                    'ruta' => $rutaRelativa,
                    'ruta_relativa' => $rutaRelativa,
                    'url' => $url,
                    'tamaño' => $imagen->getSize(),
                    'tipo' => $imagen->getMimeType()
                ],
                'message' => 'Imagen subida correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al subir la imagen: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Listar imágenes de una carpeta específica
     */
    public function listar(Request $request)
    {
        try {
            $request->validate([
                'carpeta' => 'required|string'
            ]);

            $carpeta = $request->input('carpeta');
            $archivos = Storage::disk('web_images')->files($carpeta);
            $imagenes = [];

            foreach ($archivos as $rutaRelativa) {
                $nombre = basename($rutaRelativa);
                $url = Storage::disk('web_images')->url($rutaRelativa);
                $tamaño = Storage::disk('web_images')->size($rutaRelativa);
                $fechaModificacion = Storage::disk('web_images')->lastModified($rutaRelativa);

                $extension = strtolower(pathinfo($nombre, PATHINFO_EXTENSION));
                if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                    $imagenes[] = [
                        'nombre' => $nombre,
                        'ruta' => $rutaRelativa,
                        'url' => $url,
                        'tamaño' => $tamaño,
                        'fecha_modificacion' => $fechaModificacion
                    ];
                }
            }

            // Ordenar por fecha de modificación (más recientes primero)
            usort($imagenes, function($a, $b) {
                return $b['fecha_modificacion'] - $a['fecha_modificacion'];
            });

            return response()->json([
                'success' => true,
                'data' => $imagenes,
                'message' => 'Imágenes listadas correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al listar las imágenes: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Eliminar una imagen
     */
    public function eliminar(Request $request)
    {
        try {
            $request->validate([
                'ruta' => 'required|string'
            ]);

            $ruta = $request->input('ruta');

            if (!Storage::disk('web_images')->exists($ruta)) {
                return response()->json([
                    'success' => false,
                    'message' => 'La imagen no existe'
                ], 404);
            }

            Storage::disk('web_images')->delete($ruta);

            return response()->json([
                'success' => true,
                'message' => 'Imagen eliminada correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al eliminar la imagen: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener las carpetas de imágenes disponibles
     */
    public function carpetasDisponibles()
    {
        try {
            $carpetas = array_map('basename', Storage::disk('web_images')->directories(''));

            return response()->json([
                'success' => true,
                'data' => $carpetas,
                'message' => 'Carpetas encontradas correctamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener las carpetas: ' . $e->getMessage()
            ], 500);
        }
    }
}