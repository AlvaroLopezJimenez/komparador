<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Producto;
use App\Models\OfertaProducto;
use App\Models\HistoricoPrecioOferta;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class OfertaProductoController extends Controller
{
    public function index(Producto $producto, Request $request)
{
    $perPage = $request->input('perPage', 20);
    $busqueda = $request->input('busqueda');

    $ofertas = OfertaProducto::with(['tienda', 'producto'])
        ->where('producto_id', $producto->id)
        ->when($busqueda, function ($query, $busqueda) {
            $busqueda = strtolower($busqueda);
            $query->where(function ($q) use ($busqueda) {
                $q->whereRaw('LOWER(url) LIKE ?', ["%{$busqueda}%"])
                  ->orWhereRaw('LOWER(anotaciones_internas) LIKE ?', ["%{$busqueda}%"])
                  ->orWhereHas('tienda', function ($q2) use ($busqueda) {
                      $q2->whereRaw('LOWER(nombre) LIKE ?', ["%{$busqueda}%"]);
                  })
                  ->orWhereHas('producto', function ($q3) use ($busqueda) {
                      $q3->whereRaw('LOWER(nombre) LIKE ?', ["%{$busqueda}%"])
                          ->orWhereRaw('LOWER(modelo) LIKE ?', ["%{$busqueda}%"])
                          ->orWhereRaw('LOWER(talla) LIKE ?', ["%{$busqueda}%"]);
                  });
            });
        })
        ->orderBy('precio_unidad')
        ->paginate($perPage)
        ->withQueryString();

    return view('admin.ofertas.index', compact('producto', 'ofertas', 'perPage'));
}

    public function todas(Request $request)
{
    $perPage = $request->input('perPage', 20);
    $busqueda = $request->input('busqueda');

    $ofertas = OfertaProducto::with(['tienda', 'producto'])
        ->when($busqueda, function ($query, $busqueda) {
            $busqueda = strtolower($busqueda);
            $query->where(function ($q) use ($busqueda) {
                $q->whereRaw('LOWER(url) LIKE ?', ["%{$busqueda}%"])
                  ->orWhereRaw('LOWER(anotaciones_internas) LIKE ?', ["%{$busqueda}%"])
                  ->orWhereHas('tienda', function ($q2) use ($busqueda) {
                      $q2->whereRaw('LOWER(nombre) LIKE ?', ["%{$busqueda}%"]);
                  })
                  ->orWhereHas('producto', function ($q3) use ($busqueda) {
                      $q3->whereRaw('LOWER(nombre) LIKE ?', ["%{$busqueda}%"])
                          ->orWhereRaw('LOWER(modelo) LIKE ?', ["%{$busqueda}%"])
                          ->orWhereRaw('LOWER(talla) LIKE ?', ["%{$busqueda}%"]);
                  });
            });
        })
        ->orderBy('precio_unidad')
        ->paginate($perPage)
        ->withQueryString();

    return view('admin.ofertas.todas', compact('ofertas', 'perPage'));
}



    public function edit(OfertaProducto $oferta)
    {
        $producto = $oferta->producto; // relación inversa
        return view('admin.ofertas.formulario', compact('oferta', 'producto'));
    }


    public function update(Request $request, OfertaProducto $oferta)
    {
        $validated = $request->validate([
            'tienda_id' => 'required|exists:tiendas,id',
            'unidades' => 'required|integer|min:1',
            'precio_total' => 'required|numeric|min:0',
            'precio_unidad' => 'required|numeric|min:0',
            'url' => 'required|url',
            'variante' => 'nullable|string|max:255',
            'mostrar' => 'required|string',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        $valor = (float) $request->input('frecuencia_valor');
        $unidad = $request->input('frecuencia_unidad');

        $minutos = match ($unidad) {
            'minutos' => $valor,
            'horas' => $valor * 60,
            'dias' => $valor * 1440,
            default => 1440,
        };

        $avisoFecha = $oferta->aviso; // mantener valor anterior si no se modifica

        if ($request->filled('eliminar_aviso')) {
            $avisoFecha = null;
        } elseif ($request->filled('aviso_cantidad') && $request->filled('aviso_unidad')) {
            $avisoFecha = now()->add($request->input('aviso_unidad'), (int)$request->input('aviso_cantidad'))->setTime(0, 1);
        }

        $oferta->update(array_merge($validated, [
            'frecuencia_actualizar_precio_minutos' => round($minutos),
            'aviso' => $avisoFecha,
        ]));

        return redirect()->route('admin.ofertas.index', $oferta->producto_id)->with('success', 'Oferta actualizada');
    }

    public function destroy(OfertaProducto $oferta)
    {
        $productoId = $oferta->producto_id;
        $oferta->delete();

        return redirect()->route('admin.ofertas.index', $productoId)->with('success', 'Oferta eliminada');
    }

    //Nueva oferta pasandole producto al formulario
    public function create(Producto $producto)
    {
        $oferta = null;
        return view('admin.ofertas.formulario', compact('producto', 'oferta'));
    }

    //Nueva oferta sin pasarle producto al formulario
    public function createGeneral()
    {
        $producto = null;
        $oferta = null;
        return view('admin.ofertas.formulario', compact('producto', 'oferta'));
    }


    public function store(Request $request)
    {
        // Reemplazar comas por puntos en los campos numéricos antes de validar
        $request->merge([
            'precio_total' => str_replace(',', '.', $request->precio_total),
            'precio_unidad' => str_replace(',', '.', $request->precio_unidad),
        ]);

        $validated = $request->validate([
            'producto_id' => 'required|exists:productos,id',
            'tienda_id' => 'required|exists:tiendas,id',
            'unidades' => 'required|integer|min:1',
            'precio_total' => 'required|numeric|min:0',
            'precio_unidad' => 'required|numeric|min:0',
            'url' => 'required|url',
            'variante' => 'nullable|string|max:255',
            'mostrar' => 'required|in:si,no',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        $valor = (float) $request->input('frecuencia_valor');
        $unidad = $request->input('frecuencia_unidad');

        $minutos = match ($unidad) {
            'minutos' => $valor,
            'horas' => $valor * 60,
            'dias' => $valor * 1440,
            default => 1440,
        };

        $avisoFecha = null;
        if ($request->filled('aviso')) {
            $input = $request->input('aviso');
            if (preg_match('/^(\d+)\s*(día|dias|días|semana|semanas|mes|meses)$/i', $input, $matches)) {
                $cantidad = (int) $matches[1];
                $unidad = strtolower($matches[2]);

                $unidadMap = [
                    'día' => 'days',
                    'dias' => 'days',
                    'días' => 'days',
                    'semana' => 'weeks',
                    'semanas' => 'weeks',
                    'mes' => 'months',
                    'meses' => 'months',
                ];

                if (isset($unidadMap[$unidad])) {
                    $avisoFecha = now()->add($unidadMap[$unidad], $cantidad)->setTime(0, 1);
                }
            }
        }

        OfertaProducto::create(array_merge($validated, [
            'frecuencia_actualizar_precio_minutos' => round($minutos),
        ]));


        return redirect()->route('admin.ofertas.index', $validated['producto_id'])->with('success', 'Oferta añadida correctamente');
    }

    //Mostrar el hitorial del precio de cada oferta
    public function estadisticas(OfertaProducto $oferta)
    {
        $oferta->load('producto'); // carga relación para acceder a nombre
        return view('admin.ofertas.estadisticas', compact('oferta'));
    }

    public function estadisticasDatos(OfertaProducto $oferta, Request $request)
    {
        $dias = (int) $request->query('dias', 90);
        $desde = Carbon::today()->subDays($dias - 1); // incluye hoy

        // Obtiene todos los registros desde la fecha indicada
        $historico = HistoricoPrecioOferta::where('oferta_producto_id', $oferta->id)
            ->where('fecha', '>=', $desde)
            ->orderBy('fecha')
            ->get()
            ->keyBy('fecha');

        $labels = [];
        $valores = [];

        for ($i = 0; $i < $dias; $i++) {
            $fecha = Carbon::today()->subDays($dias - 1 - $i)->toDateString();
            $labels[] = Carbon::parse($fecha)->format('d/m');
            $valores[] = isset($historico[$fecha]) ? (float) $historico[$fecha]->precio_unidad : 0;
        }

        return response()->json([
            'labels' => $labels,
            'valores' => $valores,
        ]);
    }

    // GUARDAR HISTORICO PRECIOS OFERTAS
    public function listaOfertas()
    {
        $ofertas = \App\Models\OfertaProducto::select('id', 'producto_id', 'tienda_id', 'precio_unidad')
            ->with(['producto:id,nombre', 'tienda:id,nombre'])
            ->get()
            ->map(function ($oferta) {
                return [
                    'id' => $oferta->id,
                    'nombre' => $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre,
                    'precio' => $oferta->precio_unidad,
                ];
            });

        return response()->json(['productos' => $ofertas]);
    }
    public function procesarOferta(Request $request)
    {
        $id = $request->input('id');
        $forzar = $request->input('forzar', false);

        $oferta = \App\Models\OfertaProducto::with(['producto', 'tienda'])->find($id);

        if (!$oferta) {
            return response()->json([
                'status' => 'error',
                'oferta_id' => $id,
                'error' => 'Oferta no encontrada',
            ]);
        }

        $fechaHoy = \Carbon\Carbon::today()->toDateString();

        $registroExistente = HistoricoPrecioOferta::where('oferta_producto_id', $oferta->id)
            ->where('fecha', $fechaHoy)
            ->first();

        if ($registroExistente && !$forzar) {
            return response()->json([
                'status' => 'existe',
                'oferta_id' => $oferta->id,
                'nombre' => $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre,
            ]);
        }

        try {
            \App\Models\HistoricoPrecioOferta::updateOrCreate(
                ['oferta_producto_id' => $oferta->id, 'fecha' => $fechaHoy],
                ['precio_unidad' => $oferta->precio_unidad]
            );

            return response()->json([
                'status' => $registroExistente ? 'actualizado' : 'guardado',
                'oferta_id' => $oferta->id,
                'nombre' => $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => 'error',
                'oferta_id' => $oferta->id,
                'nombre' => $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre,
                'error' => $e->getMessage(),
            ]);
        }
    }
    public function finalizarEjecucion(Request $request)
    {
        \App\Models\EjecucionGlobal::create([
            'inicio' => now(),
            'fin' => now(),
            'nombre' => 'ejecuciones_historico_precios_ofertas',
            'total' => $request->input('total', 0),
            'total_guardado' => $request->input('correctos', 0),
            'total_errores' => $request->input('errores', 0),
            'log' => $request->input('log', []),
        ]);

        return response()->json(['success' => true]);
    }
    public function indexEjecucionesHistorico(Request $request)
    {
        $busqueda = $request->input('buscar');

        $query = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_ofertas');

        if ($busqueda) {
            $query->where(function($q) use ($busqueda) {
                $q->whereDate('inicio', 'like', "%$busqueda%")
                  ->orWhereDate('fin', 'like', "%$busqueda%");
            });
        }

        $ejecuciones = $query->orderByDesc('inicio')->paginate(15)->withQueryString();
        $totalEjecuciones = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_ofertas')->count();

        return view('admin.ofertas.listadoEjecucionesGuardadoPrecios', compact('ejecuciones', 'busqueda', 'totalEjecuciones'));
    }
    public function eliminarAntiguas(Request $request)
    {
        $cantidad = $request->input('cantidad');
        \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_ofertas')
            ->orderBy('inicio')
            ->limit($cantidad)
            ->delete();

        return redirect()->back()->with('success', "$cantidad ejecuciones eliminadas.");
    }
    public function eliminar($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_ofertas')
            ->findOrFail($id);
        $ejecucion->delete();
        return redirect()->back()->with('success', 'Ejecución eliminada.');
    }

    public function segundoPlanoGuardarPrecioHistoricoHoy(Request $request)
    {
        if ($request->query('token') !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            abort(403, 'Token inválido');
        }

        $ejecucion = \App\Models\EjecucionGlobal::create([
            'inicio' => now(),
            'nombre' => 'ejecuciones_historico_precios_ofertas',
            'log' => [],
        ]);

        $ofertas = \App\Models\OfertaProducto::with(['producto', 'tienda'])->get();
        $guardados = 0;
        $errores = 0;
        $log = [];

        foreach ($ofertas as $oferta) {
            try {
                $precio = $oferta->precio_unidad ?? rand(10, 100);
                DB::table('historico_precios_ofertas')->updateOrInsert(
                    [
                        'oferta_producto_id' => $oferta->id,
                        'fecha' => now()->toDateString(),
                    ],
                    [
                        'precio_unidad' => $precio,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]
                );

                $guardados++;
            } catch (\Throwable $e) {
                $errores++;
                $log[] = [
                    'oferta_id' => $oferta->id,
                    'nombre' => $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre,
                    'error' => $e->getMessage(),
                ];
            }
        }

        $ejecucion->update([
            'fin' => now(),
            'total' => count($ofertas),
            'total_guardado' => $guardados,
            'total_errores' => $errores,
            'log' => $log,
        ]);

        return response()->json([
            'status' => 'ok',
            'guardados' => $guardados,
            'errores' => $errores,
        ]);
    }

    // MODIFICAR PRECIOS HISTORICO OFERTAS

    // MODIFICAR HISTORIAL DE PRECIO DE OFERTAS
    public function historialMes(Request $request, OfertaProducto $oferta)
    {
        $mes = (int) $request->query('mes');
        $anio = (int) $request->query('anio');

        $desde = Carbon::createFromDate($anio, $mes, 1);
        $hasta = $desde->copy()->endOfMonth();

        $registros = HistoricoPrecioOferta::where('oferta_producto_id', $oferta->id)
            ->whereBetween('fecha', [$desde->toDateString(), $hasta->toDateString()])
            ->get();

        $resultado = [];
        foreach ($registros as $registro) {
            $fechaFormateada = Carbon::parse($registro['fecha'])->format('Y-m-d');
            $resultado[$fechaFormateada] = (float) $registro['precio_unidad']; // ← CAMBIO AQUÍ
        }

        return response()->json($resultado);
    }

    public function historialGuardar(Request $request, OfertaProducto $oferta)
    {
        $cambios = $request->input('cambios', []);

        foreach ($cambios as $fecha => $precio) {
            if ($precio === null || $precio === '') continue;

            HistoricoPrecioOferta::updateOrCreate(
                ['oferta_producto_id' => $oferta->id, 'fecha' => $fecha],
                ['precio_unidad' => $precio]
            );
        }

        return response()->json(['success' => true]);
    }

    // ==========================================
    // MÉTODOS PARA SCRAPING DE OFERTAS
    // ==========================================



    /**
     * Ejecutar scraping de ofertas en segundo plano (para cron jobs)
     */
    public function ejecutarScraperOfertasSegundoPlano(Request $request)
    {
        // Usar el nuevo controlador de scraping en segundo plano
        $scraperController = new \App\Http\Controllers\Scraping\ScraperSegundoPlanoController();
        return $scraperController->ejecutarScraperOfertasSegundoPlano($request);
    }






    /**
     * Vista para listar ejecuciones de scraping
     */
    public function indexEjecucionesScraper(Request $request)
    {
        $busqueda = $request->input('buscar');

        $query = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas');

        if ($busqueda) {
            $query->where(function($q) use ($busqueda) {
                $q->whereDate('inicio', 'like', "%$busqueda%")
                  ->orWhereDate('fin', 'like', "%$busqueda%");
            });
        }

        $ejecuciones = $query->orderByDesc('inicio')->paginate(15)->withQueryString();
        $totalEjecuciones = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas')->count();

        return view('admin.ofertas.listadoEjecucionesScraper', compact('ejecuciones', 'busqueda', 'totalEjecuciones'));
    }

    /**
     * Eliminar ejecución de scraping
     */
    public function eliminarEjecucionScraper($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas')
            ->findOrFail($id);
        $ejecucion->delete();
        return redirect()->back()->with('success', 'Ejecución eliminada.');
    }

    /**
     * Obtener JSON de una ejecución específica
     */
    public function obtenerJsonEjecucionScraper($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas')
            ->findOrFail($id);
        
        $log = $ejecucion->log;
        
        // Si el log tiene el formato nuevo (con 'resultados'), devolver solo el array de resultados
        if (isset($log['resultados']) && is_array($log['resultados'])) {
            return response()->json($log['resultados']);
        }
        
        // Si es el formato antiguo (array directo), devolverlo tal como está
        if (is_array($log) && !isset($log['token'])) {
            return response()->json($log);
        }
        
        // Si es el formato nuevo pero sin 'resultados', devolver array vacío
        return response()->json([]);
    }



    /**
     * Obtener precio de una oferta individual desde el formulario
     */
    public function obtenerPrecioIndividual(Request $request)
    {
        // Validar datos de entrada
        $request->validate([
            'url' => 'required|url',
            'tienda' => 'required|string',
            'variante' => 'nullable|string'
        ]);

        try {
            // Usar el nuevo sistema de scraping interno
            $scrapingController = new \App\Http\Controllers\Scraping\ScrapingController();
            $response = $scrapingController->obtenerPrecio($request);
            $responseData = $response->getData(true);
            
            // Verificar si la respuesta contiene un error
            if (!$responseData['success']) {
                return response()->json([
                    'success' => false,
                    'error' => 'Error en el scraping: ' . ($responseData['error'] ?? 'Error desconocido')
                ]);
            }
            
            // Verificar si la respuesta contiene un precio válido
            if (!isset($responseData['precio']) || !is_numeric($responseData['precio'])) {
                return response()->json([
                    'success' => false,
                    'error' => 'Respuesta inválida del scraping: ' . json_encode($responseData)
                ]);
            }

            // Convertir precio a formato decimal (cambiar coma por punto si es necesario)
            $precio = (float) str_replace(',', '.', $responseData['precio']);

            return response()->json([
                'success' => true,
                'precio' => $precio
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Error de conexión: ' . $e->getMessage()
            ]);
        }
    }

    // ==========================================
    // MÉTODOS PARA ACTUALIZAR CLICKS DE OFERTAS
    // ==========================================

    /**
     * Vista para ejecutar actualización de clicks de ofertas en tiempo real
     */
    public function ejecutarActualizarClicksOfertas()
    {
        return view('admin.ofertas.actualizar-clicks');
    }

    /**
     * Procesar actualización de clicks de ofertas
     */
    public function procesarClicksOfertas(Request $request)
{
    // Número de días configurables
    $diasBusqueda = 7;

    // Si no hay progreso iniciado en sesión, lo creamos
    if (!Session::has('ofertas_clicks_progreso')) {
        $ofertas = OfertaProducto::select('id')->get();
        Session::put('ofertas_clicks_progreso', [
            'ofertas' => $ofertas->pluck('id')->toArray(),
            'total' => $ofertas->count(),
            'actual' => 0,
            'ejecucion_id' => \App\Models\EjecucionGlobal::create([
                'inicio' => now(),
                'nombre' => 'ejecuciones_actualizar_clicks_ofertas',
                'log' => [],
            ])->id,
        ]);
    }

    $progreso = Session::get('ofertas_clicks_progreso');
    $indiceActual = $progreso['actual'];
    $totalOfertas = $progreso['total'];
    $ofertasIds = $progreso['ofertas'];

    // Procesar una oferta si quedan por procesar
    if ($indiceActual < $totalOfertas) {
        $oferta = OfertaProducto::find($ofertasIds[$indiceActual]);

        if ($oferta) {
            $fechaInicio = Carbon::now()->subDays($diasBusqueda);

            $totalClicks = \App\Models\Click::where('oferta_id', $oferta->id)
                ->where('created_at', '>=', $fechaInicio)
                ->count();

            $oferta->update(['clicks' => $totalClicks]);
        }

        // Actualizar progreso
        $progreso['actual'] += 1;
        Session::put('ofertas_clicks_progreso', $progreso);

        // Si después de procesar esta oferta ya hemos terminado todas
        if ($progreso['actual'] >= $totalOfertas) {
            $ejecucion = \App\Models\EjecucionGlobal::find($progreso['ejecucion_id']);
            $ejecucion->update([
                'fin' => now(),
                'total' => $totalOfertas,
                'total_guardado' => $totalOfertas,
                'total_errores' => 0,
                'log' => [
                    'resultado' => "Se procesaron {$totalOfertas} ofertas exitosamente"
                ],
            ]);

            Session::forget('ofertas_clicks_progreso');

            return response()->json([
                'success' => true,
                'message' => "Se actualizaron los clicks de {$totalOfertas} ofertas exitosamente"
            ]);
        }

        return response()->json([
            'progreso' => round(($progreso['actual'] / $totalOfertas) * 100),
            'ofertas_procesadas' => $progreso['actual'],
            'total_ofertas' => $totalOfertas,
            'oferta_actual' => $oferta ? $oferta->producto->nombre . ' - ' . $oferta->tienda->nombre : 'Desconocida'
        ]);
    }
}


    /**
     * Vista para listar ejecuciones de actualización de clicks de ofertas
     */
    public function ejecucionesClicksOfertas()
    {
        $ejecuciones = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_actualizar_clicks_ofertas')
            ->orderBy('created_at', 'desc')
            ->paginate(20);
            
        return view('admin.ofertas.ejecuciones-clicks', compact('ejecuciones'));
    }
}
