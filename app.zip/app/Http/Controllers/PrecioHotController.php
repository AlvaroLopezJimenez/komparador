<?php

namespace App\Http\Controllers;

use App\Models\PrecioHot;
use App\Models\EjecucionPrecioHot;
use App\Models\Categoria;
use App\Models\Producto;
use App\Models\OfertaProducto;
use App\Models\HistoricoPrecioProducto;
use App\Models\Tienda;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PrecioHotController extends Controller
{
    public function index()
    {
        $preciosHot = PrecioHot::orderBy('created_at', 'desc')->get();
        return view('admin.precios-hot.index', compact('preciosHot'));
    }

    public function ejecutarSegundoPlano(Request $request)
    {
        $token = $request->get('token');
        if ($token !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            return response()->json(['status' => 'error', 'message' => 'Token inválido']);
        }

        // Crear registro de ejecución en la tabla global
        $ejecucion = \App\Models\EjecucionGlobal::create([
            'inicio' => now(),
            'nombre' => 'precios_hot',
            'log' => []
        ]);

        try {
            $this->procesarPreciosHot($ejecucion);
            
            $ejecucion->update([
                'fin' => now()
            ]);

            return response()->json([
                'status' => 'ok',
                'message' => 'Proceso completado',
                'total_categorias' => $ejecucion->total,
                'total_inserciones' => $ejecucion->total_guardado,
                'total_errores' => $ejecucion->total_errores
            ]);
        } catch (\Exception $e) {
            $ejecucion->update([
                'fin' => now(),
                'total_errores' => $ejecucion->total_errores + 1
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Error en el proceso: ' . $e->getMessage()
            ]);
        }
    }

    public function verEjecucion()
    {
        $tokenScraper = env('TOKEN_ACTUALIZAR_PRECIOS');
        return view('admin.precios-hot.ejecucion', compact('tokenScraper'));
    }

    public function ejecuciones()
    {
        $ejecuciones = \App\Models\EjecucionGlobal::where('nombre', 'precios_hot')
            ->orderBy('created_at', 'desc')
            ->get();
        return view('admin.precios-hot.ejecuciones', compact('ejecuciones'));
    }

    private function procesarPreciosHot($ejecucion)
    {
        $log = [];
        $totalCategorias = 0;
        $totalInserciones = 0;
        $totalErrores = 0;

        // Obtener todas las categorías
        $categorias = Categoria::all();
        $totalCategorias = $categorias->count();

        foreach ($categorias as $categoria) {
            try {
                $productosHot = $this->obtenerProductosHotPorCategoria($categoria, 20);
                
                if (!empty($productosHot)) {
                    // Guardar o actualizar en la tabla precios_hot
                    PrecioHot::updateOrCreate(
                        ['nombre' => $categoria->nombre],
                        ['datos' => $productosHot]
                    );
                    $totalInserciones++;
                    $log[] = "✅ Categoría '{$categoria->nombre}': " . count($productosHot) . " productos hot encontrados";
                } else {
                    $log[] = "⚠️ Categoría '{$categoria->nombre}': No se encontraron productos hot";
                }
            } catch (\Exception $e) {
                $totalErrores++;
                $log[] = "❌ Error en categoría '{$categoria->nombre}': " . $e->getMessage();
            }
        }

        // Procesar categoría global "Precios Hot"
        try {
            $productosHotGlobal = $this->obtenerProductosHotGlobal(60);
            
            if (!empty($productosHotGlobal)) {
                PrecioHot::updateOrCreate(
                    ['nombre' => 'Precios Hot'],
                    ['datos' => $productosHotGlobal]
                );
                $totalInserciones++;
                $log[] = "✅ Categoría global 'Precios Hot': " . count($productosHotGlobal) . " productos hot encontrados";
            } else {
                $log[] = "⚠️ Categoría global 'Precios Hot': No se encontraron productos hot";
            }
        } catch (\Exception $e) {
            $totalErrores++;
            $log[] = "❌ Error en categoría global 'Precios Hot': " . $e->getMessage();
        }

        $ejecucion->update([
            'total' => $totalCategorias,
            'total_guardado' => $totalInserciones,
            'total_errores' => $totalErrores,
            'log' => $log
        ]);
    }

    private function obtenerProductosHotPorCategoria($categoria, $limite = 20)
    {
        // Obtener todas las categorías hijas (incluyendo la actual)
        $categoriaIds = $this->obtenerCategoriaIdsIncluyendoHijas($categoria->id);
        
        // Obtener productos de estas categorías con sus relaciones
        $productos = Producto::with('categoria')
            ->whereIn('categoria_id', $categoriaIds)
            ->get();
        
        return $this->calcularProductosHot($productos, $limite);
    }

    private function obtenerProductosHotGlobal($limite = 60)
    {
        // Obtener todos los productos con sus relaciones
        $productos = Producto::with('categoria')->get();
        
        return $this->calcularProductosHot($productos, $limite);
    }

    private function calcularProductosHot($productos, $limite)
    {
        $productosHot = [];
        $haceUnMes = Carbon::now()->subMonth();

        foreach ($productos as $producto) {
            // Calcular precio medio del último mes
            $precioMedio = HistoricoPrecioProducto::where('producto_id', $producto->id)
                ->where('fecha', '>=', $haceUnMes)
                ->avg('precio_minimo');

            if (!$precioMedio) {
                continue; // Saltar productos sin historial de precios
            }

            // Buscar la oferta con precio más bajo y cargar la relación con tienda
            $mejorOferta = OfertaProducto::with('tienda')
                ->where('producto_id', $producto->id)
                ->orderBy('precio_unidad', 'asc')
                ->first();

            if (!$mejorOferta) {
                continue; // Saltar productos sin ofertas
            }

            // Calcular porcentaje de diferencia
            $diferencia = (($precioMedio - $mejorOferta->precio_unidad) / $precioMedio) * 100;

            // Solo incluir si el precio de la oferta es menor que la media
            if ($diferencia > 0) {
                $productosHot[] = [
                    'producto_id' => $producto->id,
                    'oferta_id' => $mejorOferta->id,
                    'tienda_id' => $mejorOferta->tienda_id,
                    'img_tienda' => $mejorOferta->tienda->url_imagen,
                    'img_producto' => $producto->imagen_pequena,
                    'precio_oferta' => $mejorOferta->precio_unidad,
                    'porcentaje_diferencia' => round($diferencia, 2),
                    'url_oferta' => $mejorOferta->url,
                    'url_producto' => $this->generarUrlProducto($producto),
                    'producto_nombre' => $producto->nombre,
                    'tienda_nombre' => $mejorOferta->tienda ? $mejorOferta->tienda->nombre : 'Tienda desconocida'
                ];
            }
        }

        // Ordenar por porcentaje de diferencia (mayor a menor) y tomar los primeros
        usort($productosHot, function($a, $b) {
            return $b['porcentaje_diferencia'] <=> $a['porcentaje_diferencia'];
        });

        return array_slice($productosHot, 0, $limite);
    }

    private function obtenerCategoriaIdsIncluyendoHijas($categoriaId)
    {
        $categoriaIds = [$categoriaId];
        
        // Obtener categorías hijas directas
        $hijas = Categoria::where('parent_id', $categoriaId)->get();
        
        foreach ($hijas as $hija) {
            $categoriaIds = array_merge($categoriaIds, $this->obtenerCategoriaIdsIncluyendoHijas($hija->id));
        }
        
        return $categoriaIds;
    }

    private function generarUrlProducto($producto)
    {
        // Cargar la relación de categoría si no está cargada
        if (!$producto->relationLoaded('categoria')) {
            $producto->load('categoria');
        }
        
        $categoria = $producto->categoria;
        if (!$categoria) {
            return '/productos/' . $producto->slug;
        }

        $urlParts = [$categoria->slug];
        
        // Construir la URL completa con la jerarquía de categorías
        $categoriaActual = $categoria;
        while ($categoriaActual->parent_id) {
            $categoriaPadre = Categoria::find($categoriaActual->parent_id);
            if ($categoriaPadre) {
                array_unshift($urlParts, $categoriaPadre->slug);
                $categoriaActual = $categoriaPadre;
            } else {
                break;
            }
        }
        
        return '/' . implode('/', $urlParts) . '/' . $producto->slug;
    }
} 