<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Click;
use App\Models\OfertaProducto;
use App\Models\Producto;
use Illuminate\Support\Facades\DB;
use App\Models\Tienda;
use Illuminate\Support\Facades\View;

class ClickController extends Controller
{

    //LISTAR TODOS LOS CLICKS
    public function index(Request $request)
    {
        $query = Click::with(['oferta.producto', 'oferta.tienda']);

        // Filtros opcionales (por campaña o producto)
        if ($request->filled('campana')) {
            $query->where('campaña', $request->campana);
        }

        if ($request->filled('producto')) {
            $query->whereHas('oferta', fn($q) => $q->where('producto_id', $request->producto));
        }

        $clics = $query->latest()->paginate(30);

        return view('admin.clics.index', compact('clics'));
    }

    //FUNCION PARA LAS ESTADISTICAS DE CLICK EN PRODUCTO
    public function estadisticasAvanzadas(Request $request, Producto $producto)
    {
        $desde = $request->input('desde', now()->subDays(30)->toDateString());
        $hasta = $request->input('hasta', now()->toDateString());
        $campana = $request->input('campana');

        $palabrasClave = $producto->palabrasClave()->get();

        $query = DB::table('clicks')
            ->join('ofertas_producto', 'clicks.oferta_id', '=', 'ofertas_producto.id')
            ->join('tiendas', 'ofertas_producto.tienda_id', '=', 'tiendas.id')
            ->where('ofertas_producto.producto_id', $producto->id)
            ->whereBetween('clicks.created_at', [$desde . ' 00:00:00', $hasta . ' 23:59:59']);

        if ($campana) {
            $query->where('clicks.campaña', $campana);
        }

        $agrupado = $query
            ->selectRaw('tiendas.id, tiendas.nombre, tiendas.url_imagen, tiendas.opiniones, tiendas.puntuacion, COUNT(*) as total_clicks, MIN(clicks.precio_unidad) as min, MAX(clicks.precio_unidad) as max')
            ->groupBy('tiendas.id', 'tiendas.nombre', 'tiendas.url_imagen', 'tiendas.opiniones', 'tiendas.puntuacion')
            ->orderByDesc('total_clicks')
            ->get()
            ->keyBy('id');

        $visibilidad = DB::table('ofertas_producto')
            ->selectRaw('tienda_id, COUNT(*) as total, SUM(CASE WHEN mostrar = "no" THEN 1 ELSE 0 END) as ocultas')
            ->where('producto_id', $producto->id)
            ->groupBy('tienda_id')
            ->get()
            ->mapWithKeys(function ($item) {
                return [$item->tienda_id => $item->ocultas >= $item->total];
            });

        $clicsPaginados = Click::with(['oferta.tienda'])
            ->whereHas('oferta', function ($q) use ($producto) {
                $q->where('producto_id', $producto->id);
            })
            ->when($campana, fn($q) => $q->where('campaña', $campana))
            ->whereBetween('created_at', [$desde . ' 00:00:00', $hasta . ' 23:59:59'])
            ->orderByDesc('created_at')
            ->paginate(20);

        return view('admin.productos.estadisticasClicks', compact(
            'producto',
            'desde',
            'hasta',
            'campana',
            'palabrasClave',
            'agrupado',
            'visibilidad',
            'clicsPaginados',
        ));
    }


    public function redirigir(Request $request, $ofertaId)
    {
        $cam = $request->query('cam');
        $oferta = OfertaProducto::with('producto')->findOrFail($ofertaId);
        $ip = $request->ip();

        // Calcular posición ordenada por precio
        $posicion = OfertaProducto::where('producto_id', $oferta->producto_id)
            ->orderBy('precio_unidad')
            ->pluck('id')
            ->search($oferta->id);

        // Evitar duplicados (IP + oferta + fecha)
        $existe = \App\Models\Click::where('oferta_id', $oferta->id)
            ->where('ip', $ip)
            ->whereDate('created_at', now()->toDateString())
            ->exists();

        if (!$existe) {
            Click::create([
                'oferta_id' => $oferta->id,
                'campaña' => $cam,
                'ip' => $ip,
                'precio_unidad' => $oferta->precio_unidad,
                'posicion' => $posicion !== false ? $posicion + 1 : null,
            ]);
        }

        return response()
    ->view('redireccion', [
        'url' => $oferta->url,
    ])
    ->header('X-Robots-Tag', 'noindex, nofollow');
    }

    //SACAR RANGO DE PRECIO
    public function rangoPrecio(Request $request, Producto $producto)
    {
        $desde = $request->input('desde');
        $hasta = $request->input('hasta');
        $campana = $request->input('campana');

        $query = DB::table('clicks')
            ->join('ofertas_producto', 'clicks.oferta_id', '=', 'ofertas_producto.id')
            ->where('ofertas_producto.producto_id', $producto->id)
            ->whereBetween('clicks.created_at', [$desde . ' 00:00:00', $hasta . ' 23:59:59']);

        if ($campana) {
            $query->where('clicks.campaña', $campana);
        }

        $min = $query->min('clicks.precio_unidad');
        $max = $query->max('clicks.precio_unidad');

        return response()->json([
            'min' => $min !== null ? number_format($min, 2, ',', '') : null,
            'max' => $max !== null ? number_format($max, 2, ',', '') : null,
        ]);
    }

    //PARA LA GRAFICA DE CLICKS POR HORAS
    public function porHora(Request $request, Producto $producto)
{
    $desde = $request->input('desde');
    $hasta = $request->input('hasta');
    $campana = $request->input('campana');

    $query = DB::table('clicks')
        ->join('ofertas_producto', 'clicks.oferta_id', '=', 'ofertas_producto.id')
        ->where('ofertas_producto.producto_id', $producto->id)
        ->whereBetween('clicks.created_at', [$desde . ' 00:00:00', $hasta . ' 23:59:59']);

    if ($campana) {
        $query->where('clicks.campaña', $campana);
    }

    $resultados = $query
        ->selectRaw('HOUR(clicks.created_at) as hora, FLOOR(MINUTE(clicks.created_at)/30)*30 as bloque, COUNT(*) as total')
        ->groupBy('hora', 'bloque')
        ->orderBy('hora')
        ->orderBy('bloque')
        ->get();

    $labels = [];
    $values = [];

    for ($h = 0; $h < 24; $h++) {
        foreach ([0, 30] as $m) {
            $label = str_pad($h, 2, '0', STR_PAD_LEFT) . ':' . str_pad($m, 2, '0', STR_PAD_LEFT);
            $labels[] = $label;
            $values[] = 0;
        }
    }

    foreach ($resultados as $r) {
        $index = $r->hora * 2 + ($r->bloque === 30 ? 1 : 0);
        $values[$index] = $r->total;
    }

    return response()->json([
        'labels' => $labels,
        'values' => $values,
    ]);
}



    //LISTA DE TIENDAS, CON CLICKS Y RANGO DE PRECIOS, EN LAS ESTADISTICAS DE PRODUCTO
    public function tiendas(Request $request, Producto $producto)
    {
        $desde = $request->input('desde');
        $hasta = $request->input('hasta');
        $campana = $request->input('campana');

        $query = DB::table('clicks')
            ->join('ofertas_producto', 'clicks.oferta_id', '=', 'ofertas_producto.id')
            ->join('tiendas', 'ofertas_producto.tienda_id', '=', 'tiendas.id')
            ->where('ofertas_producto.producto_id', $producto->id)
            ->whereBetween('clicks.created_at', [$desde . ' 00:00:00', $hasta . ' 23:59:59']);

        if ($campana) {
            $query->where('clicks.campaña', $campana);
        }

        $agrupado = $query
            ->selectRaw('tiendas.id, tiendas.nombre, tiendas.url_imagen, tiendas.opiniones, tiendas.puntuacion, COUNT(*) as total_clicks, MIN(clicks.precio_unidad) as min, MAX(clicks.precio_unidad) as max')
            ->groupBy('tiendas.id', 'tiendas.nombre', 'tiendas.url_imagen', 'tiendas.opiniones', 'tiendas.puntuacion')
            ->orderByDesc('total_clicks')
            ->get();

        // Verificamos si la tienda tiene TODAS sus ofertas del producto como "no visibles"
        $visibilidad = DB::table('ofertas_producto')
            ->selectRaw('tienda_id, COUNT(*) as total, SUM(CASE WHEN mostrar = "no" THEN 1 ELSE 0 END) as ocultas')
            ->where('producto_id', $producto->id)
            ->groupBy('tienda_id')
            ->get()
            ->pluck('ocultas', 'tienda_id');

        return View::make('admin.productos.partials.tiendasClicks', compact('agrupado', 'visibilidad'))->render();
    }
}
