<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Producto;
use App\Models\PrecioHot;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        // Obtener categorías top (con más clicks) - máximo 10
        $categoriasTop = Categoria::whereNull('parent_id')
            ->orderBy('clicks', 'desc')
            ->take(10)
            ->get();

        // Obtener productos top (con más clicks) - máximo 8
        $productosTop = Producto::with(['categoria.padre.padre'])
            ->orderBy('clicks', 'desc')
            ->take(8)
            ->get();

        // Obtener últimos productos añadidos - máximo 10
        $ultimosProductos = Producto::with(['categoria.padre.padre'])
            ->orderBy('created_at', 'desc')
            ->take(10)
            ->get();

        // Obtener ofertas destacadas (con mejor precio) - máximo 6
        $ofertasDestacadas = \App\Models\OfertaProducto::with(['producto.categoria.padre.padre', 'tienda'])
            ->where('mostrar', 'sí')
            ->orderBy('precio_unidad', 'asc')
            ->take(6)
            ->get();

        $preciosHot = PrecioHot::where('nombre', 'Precios Hot')->first();

        return view('index', compact('categoriasTop', 'productosTop', 'ultimosProductos', 'ofertasDestacadas', 'preciosHot'));
    }

    public function categoria($slug)
    {
        $categoria = Categoria::where('slug', $slug)->firstOrFail();
        
        // Obtener subcategorías
        $subcategorias = Categoria::where('parent_id', $categoria->id)
            ->with(['subcategorias' => function ($query) {
                $query->withCount('productos');
            }])
            ->get();

        // Calcular productos en cascada para subcategorías
        foreach ($subcategorias as $sub) {
            $sub->productos_count = $sub->productos()->count();

            foreach ($sub->subcategorias as $subsub) {
                $subsub->productos_count = $subsub->productos()->count();
                // Sumar hacia arriba
                $sub->productos_count += $subsub->productos_count;
            }
        }

        // Obtener productos de esta categoría y sus subcategorías
        $productos = $this->getProductosCategoria($categoria->id);

        return view('categoria', compact('categoria', 'subcategorias', 'productos'));
    }

public function todasCategorias()
{
    $categoriasPadre = Categoria::whereNull('parent_id')
        ->with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
        ->orderBy('nombre')
        ->get();

    // Generar lista completa de subcategorías hijas para la vista
    $subcategorias = Categoria::whereIn('parent_id', $categoriasPadre->pluck('id'))
        ->with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
        ->orderBy('clicks', 'desc')
        ->get();

    // Obtener todos los productos de todas las categorías y subcategorías
    $productos = Producto::with(['categoria.padre.padre'])
        ->orderBy('clicks', 'desc')
        ->paginate(20);

    $ultimosProductos = Producto::orderBy('created_at', 'desc')
        ->take(10)
        ->get();

    // Obtener precios hot globales
    $preciosHot = PrecioHot::where('nombre', 'Precios Hot')->first();

    return view('categorias.show', [
        'categoriaActual' => (object)[
            'nombre' => 'Todas las categorías',
        ],
        'categorias' => $categoriasPadre,
        'subcategorias' => $subcategorias,
        'productos' => $productos,
        'ultimosProductos' => $ultimosProductos,
        'breadcrumb' => [],
        'preciosHot' => $preciosHot,
    ]);
}

    public function showCategoria($slug)
{
    $categoriaActual = Categoria::where('slug', $slug)->first();
    if (!$categoriaActual) {
        return redirect()->route('categorias.todas');
    }

    // BREADCRUMB
    $breadcrumb = [];
    $categoria = $categoriaActual;
    while ($categoria) {
        array_unshift($breadcrumb, [
            'nombre' => $categoria->nombre,
            'url' => route('categoria.show', $categoria->slug)
        ]);
        $categoria = $categoria->padre;
    }

    // SUBCATEGORÍAS
    $subcategorias = Categoria::where('parent_id', $categoriaActual->id)
        ->with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
        ->orderBy('clicks', 'desc')
        ->get();

    // PRODUCTOS (incluye todos los niveles)
    $productos = $this->getProductosCategoria($categoriaActual->id);

    // ID de todas las subcategorías y sub-subcategorías
    $categoriaIds = [$categoriaActual->id];
    foreach ($subcategorias as $sub) {
        $categoriaIds[] = $sub->id;

        $subsubcategorias = Categoria::where('parent_id', $sub->id)->get();
        foreach ($subsubcategorias as $subsub) {
            $categoriaIds[] = $subsub->id;
        }
    }

    // Últimos productos añadidos (de cualquier nivel de esta categoría)
    $ultimosProductos = Producto::whereIn('categoria_id', $categoriaIds)
        ->orderBy('created_at', 'desc')
        ->take(10)
        ->get();

    // Precios Hot específicos de la categoría
    $preciosHot = PrecioHot::where('nombre', $categoriaActual->nombre)->first();

    return view('categorias.show', compact(
        'categoriaActual',
        'subcategorias',
        'productos',
        'ultimosProductos',
        'breadcrumb',
        'preciosHot',
    ));
}


    public function subcategoria($categoriaSlug, $subcategoriaSlug)
    {
        $categoria = Categoria::where('slug', $categoriaSlug)->firstOrFail();
        $subcategoria = Categoria::where('slug', $subcategoriaSlug)
            ->where('parent_id', $categoria->id)
            ->firstOrFail();

        // Obtener sub-subcategorías
        $subsubcategorias = Categoria::where('parent_id', $subcategoria->id)
            ->get();

        // Calcular productos para sub-subcategorías
        foreach ($subsubcategorias as $subsub) {
            $subsub->productos_count = $subsub->productos()->count();
        }

        // Obtener productos de esta subcategoría y sus sub-subcategorías
        $productos = $this->getProductosCategoria($subcategoria->id);

        return view('subcategoria', compact('categoria', 'subcategoria', 'subsubcategorias', 'productos'));
    }

    public function subsubcategoria($categoriaSlug, $subcategoriaSlug, $subsubcategoriaSlug)
    {
        $categoria = Categoria::where('slug', $categoriaSlug)->firstOrFail();
        $subcategoria = Categoria::where('slug', $subcategoriaSlug)
            ->where('parent_id', $categoria->id)
            ->firstOrFail();
        $subsubcategoria = Categoria::where('slug', $subsubcategoriaSlug)
            ->where('parent_id', $subcategoria->id)
            ->firstOrFail();

        // Obtener productos de esta sub-subcategoría
        $productos = Producto::where('categoria_id', $subsubcategoria->id)
            ->with(['categoria.padre.padre']) // Cargar relaciones de categoría
            ->orderBy('clicks', 'desc')
            ->paginate(20);

        // Si solo hay un producto, redirigir a la ruta correcta del producto
        if ($productos->count() === 1) {
            $producto = $productos->first();
            return redirect()->route('admin.producto.detalle', [
                'cat1' => $categoria->slug,
                'cat2' => $subcategoria->slug,
                'cat3' => $subsubcategoria->slug,
                'slug' => $producto->slug
            ]);
        }

        return view('subsubcategoria', compact('categoria', 'subcategoria', 'subsubcategoria', 'productos'));
    }

    private function getProductosCategoria($categoriaId)
    {
        // Obtener todos los IDs de subcategorías y sub-subcategorías
        $categoriaIds = [$categoriaId];
        
        $subcategorias = Categoria::where('parent_id', $categoriaId)->get();
        foreach ($subcategorias as $sub) {
            $categoriaIds[] = $sub->id;
            $subsubcategorias = Categoria::where('parent_id', $sub->id)->get();
            foreach ($subsubcategorias as $subsub) {
                $categoriaIds[] = $subsub->id;
            }
        }

        return Producto::whereIn('categoria_id', $categoriaIds)
            ->with(['categoria.padre.padre']) // Cargar relaciones de categoría
            ->orderBy('clicks', 'desc')
            ->paginate(20);
    }
} 