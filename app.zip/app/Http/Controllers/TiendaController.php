<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tienda;
use App\Models\ComisionCategoriaTienda;
use App\Models\Categoria;

class TiendaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $perPage = $request->input('perPage', 25);

        $query = \App\Models\Tienda::withCount('ofertas');

        if ($request->filled('buscar')) {
            $query->where('nombre', 'like', '%' . $request->buscar . '%');
        }

        $tiendas = $query->paginate($perPage)->appends($request->query());

        return view('admin.tiendas.index', compact('tiendas', 'perPage'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
{
    $categorias = Categoria::with('children.children')->whereNull('parent_id')->get();
    return view('admin.tiendas.formulario', [
        'tienda' => new Tienda(),
        'categorias' => $categorias,
        'comisiones' => collect(), // vacío porque es nueva
    ]);
}

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|unique:tiendas,nombre',
            'envio_gratis' => 'nullable|string',
            'envio_normal' => 'nullable|string',
            'url' => 'nullable|string',
            'url_imagen' => 'nullable|string',
            'opiniones' => 'nullable|integer',
            'puntuacion' => 'nullable|numeric|min:0|max:5',
            'url_opiniones' => 'nullable|string',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        $avisoFecha = null;
        if ($request->filled('eliminar_aviso')) {
            $avisoFecha = null;
        } elseif ($request->filled('aviso_cantidad') && $request->filled('aviso_unidad')) {
            $avisoFecha = now()->add($request->input('aviso_unidad'), (int)$request->input('aviso_cantidad'))->setTime(0, 1);
        }


        $tienda = \App\Models\Tienda::create([
            ...$request->only(['nombre', 'envio_gratis', 'envio_normal', 'url', 'url_imagen', 'url_opiniones']),
            'opiniones' => $request->filled('opiniones') ? $request->input('opiniones') : 0,
            'puntuacion' => $request->filled('puntuacion') ? $request->input('puntuacion') : 0,
            'anotaciones_internas' => $request->input('anotaciones_internas'),
            'aviso' => $avisoFecha,
        ]);

if ($request->has('comisiones')) {
    foreach ($request->input('comisiones') as $categoriaId => $comision) {
        if ($comision !== null && $comision !== '') {
            ComisionCategoriaTienda::create([
                'tienda_id' => $tienda->id,
                'categoria_id' => $categoriaId,
                'comision' => $comision,
            ]);
        }
    }
}

        return redirect()->route('admin.tiendas.index')->with('success', 'Tienda creada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
public function edit(Tienda $tienda)
{
    $tienda->load('comisiones'); // <-- SOLUCIÓN

    $categorias = Categoria::with('children.children')->whereNull('parent_id')->get();
    $comisiones = $tienda->comisiones->pluck('comision', 'categoria_id');

    return view('admin.tiendas.formulario', compact('tienda', 'categorias', 'comisiones'));
}



    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, \App\Models\Tienda $tienda)
    {
        $request->validate([
            'nombre' => 'required|unique:tiendas,nombre,' . $tienda->id,
            'envio_gratis' => 'nullable|string',
            'envio_normal' => 'nullable|string',
            'url' => 'nullable|string',
            'url_imagen' => 'nullable|string',
            'opiniones' => 'nullable|integer',
            'puntuacion' => 'nullable|numeric|min:0|max:5',
            'url_opiniones' => 'nullable|string',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        $avisoFecha = $tienda->aviso;

        if ($request->filled('eliminar_aviso')) {
            $avisoFecha = null;
        } elseif ($request->filled('aviso_cantidad') && $request->filled('aviso_unidad')) {
            $avisoFecha = now()->add($request->input('aviso_unidad'), (int)$request->input('aviso_cantidad'))->setTime(0, 1);
        }



        $tienda->update([
            ...$request->only([
                'nombre',
                'envio_gratis',
                'envio_normal',
                'url',
                'url_imagen',
                'opiniones',
                'puntuacion',
                'url_opiniones',
                'anotaciones_internas',
            ]),
            'aviso' => $avisoFecha,
        ]);

        
ComisionCategoriaTienda::where('tienda_id', $tienda->id)->delete();

if ($request->has('comisiones')) {
    foreach ($request->input('comisiones') as $categoriaId => $comision) {
        if ($comision !== null && $comision !== '') {
            ComisionCategoriaTienda::create([
                'tienda_id' => $tienda->id,
                'categoria_id' => $categoriaId,
                'comision' => $comision,
            ]);
        }
    }
}


        return redirect()->route('admin.tiendas.index')->with('success', 'Tienda actualizada correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(\App\Models\Tienda $tienda)
    {
        $tienda->delete();
        return redirect()->route('admin.tiendas.index')->with('success', 'Tienda eliminada correctamente.');
    }

    // Mostrar las ofertas asociadas a esta tienda

    public function ofertas(Tienda $tienda)
    {
        $perPage = request('perPage', 20);

        $query = $tienda->ofertas()->with('producto')->orderByDesc('created_at');

        if (request('buscar')) {
            $query->whereHas('producto', function ($q) {
                $q->where('nombre', 'like', '%' . request('buscar') . '%');
            });
        }

        $ofertas = $query->paginate($perPage)->appends(request()->query());

        return view('admin.tiendas.ofertas', compact('tienda', 'ofertas'));
    }
}
