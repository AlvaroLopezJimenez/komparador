<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Helpers\CategoriaHelper;

class CategoriaController extends Controller
{
    public function index()
    {
        $todasCategorias = Categoria::orderBy('nombre')->get();

        // Cargar toda la jerarquía de forma recursiva
        $categoriasRaiz = Categoria::with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
            ->whereNull('parent_id')
            ->orderBy('nombre')
            ->get();

        // Función recursiva para cargar subcategorías y contar productos
        $this->cargarSubcategoriasRecursivamente($categoriasRaiz);

        return view('admin.categorias.index', compact('todasCategorias', 'categoriasRaiz'));
    }

    /**
     * Carga subcategorías de forma recursiva y cuenta productos
     */
    private function cargarSubcategoriasRecursivamente($categorias)
    {
        foreach ($categorias as $categoria) {
            // Cargar subcategorías
            $categoria->load(['subcategorias' => function ($query) {
                $query->orderBy('nombre');
            }]);
            
            // Contar productos directos
            $categoria->productos_count = $categoria->productos()->count();
            
            // Recursivamente cargar subcategorías y sumar productos
            if ($categoria->subcategorias->count() > 0) {
                $this->cargarSubcategoriasRecursivamente($categoria->subcategorias);
                
                // Sumar productos de subcategorías
                foreach ($categoria->subcategorias as $sub) {
                    $categoria->productos_count += $sub->productos_count;
                }
            }
        }
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'parent_id' => 'nullable|exists:categorias,id',
            'imagen' => 'nullable|string|max:255',
        ]);

        // Crear la categoría
        Categoria::create([
            'nombre' => $request->nombre,
            'slug' => Str::slug($request->nombre),
            'parent_id' => $request->parent_id,
            'imagen' => $request->imagen,
        ]);

        return redirect()->route('admin.categorias.index')->with('success', 'Categoría creada correctamente.');
    }

    public function subcategorias($parentId)
    {
        return Categoria::where('parent_id', $parentId)->select('id', 'nombre')->get();
    }
    
    public function jerarquia($categoriaId)
    {
        $categoria = Categoria::findOrFail($categoriaId);
        $jerarquia = [];
        
        // Construir la jerarquía desde la raíz hasta la categoría actual
        $categoriaActual = $categoria;
        while ($categoriaActual) {
            array_unshift($jerarquia, [
                'id' => $categoriaActual->id,
                'nombre' => $categoriaActual->nombre
            ]);
            $categoriaActual = $categoriaActual->parent;
        }
        
        return response()->json([
            'jerarquia' => $jerarquia
        ]);
    }
    
    public function destroy(Categoria $categoria)
    {
        $tieneHijas = $categoria->subcategorias()->exists();
        $tieneProductos = $categoria->productos()->exists();

        if ($tieneHijas || $tieneProductos) {
            return back()->with('error', 'No se puede eliminar: tiene subcategorías o productos asociados.');
        }

        $categoria->delete();

        return back()->with('success', 'Categoría eliminada correctamente.');
    }

    //ACTUALIZAR NOMBRE E IMAGEN DE LA CATEGORIA
    public function updateNombre(Request $request, Categoria $categoria)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'imagen' => 'nullable|string|max:255'
        ]);

        $nombre = $request->input('nombre');
        $slug = Str::slug($nombre);

        $categoria->update([
            'nombre' => $nombre,
            'slug' => $slug,
            'imagen' => $request->input('imagen')
        ]);

        return response()->json(['success' => true]);
    }
}
