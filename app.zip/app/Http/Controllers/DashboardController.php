<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto;
use App\Models\OfertaProducto;
use App\Models\Tienda;

class DashboardController extends Controller
{
    public function index()
{
    $hoy = now()->startOfDay();

    $avisosProductos = Producto::whereNotNull('aviso')->whereDate('aviso', '<=', $hoy)->count();
    $avisosOfertas = OfertaProducto::whereNotNull('aviso')->whereDate('aviso', '<=', $hoy)->count();
    $avisosTiendas = Tienda::whereNotNull('aviso')->whereDate('aviso', '<=', $hoy)->count();

    $avisosTiendasSinComision = Tienda::all()->filter(function ($tienda) {
        $categoriaIds = \App\Models\Categoria::pluck('id')->toArray();
        $comisionadas = \App\Models\ComisionCategoriaTienda::where('tienda_id', $tienda->id)
            ->pluck('categoria_id')
            ->toArray();
        return count(array_diff($categoriaIds, $comisionadas)) > 0;
    })->count();

    $totalAvisos = $avisosProductos + $avisosOfertas + $avisosTiendas + $avisosTiendasSinComision;

    return view('admin.dashboard', compact('totalAvisos'));
}

}
