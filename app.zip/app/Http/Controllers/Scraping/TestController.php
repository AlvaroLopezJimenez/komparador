<?php

namespace App\Http\Controllers\Scraping;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TestController extends Controller
{
    /**
     * Prueba simple para verificar que el sistema funciona
     */
    public function test()
    {
        return response()->json([
            'success' => true,
            'message' => 'Sistema de scraping funcionando correctamente',
            'timestamp' => now()->toISOString()
        ]);
    }

    /**
     * Prueba de error para verificar manejo de errores
     */
    public function testError()
    {
        return response()->json([
            'success' => false,
            'error' => 'Error de prueba simulado',
            'timestamp' => now()->toISOString()
        ]);
    }
}
