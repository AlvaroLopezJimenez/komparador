<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use Illuminate\Http\JsonResponse;

class AmazonController extends PlantillaTiendaController
{
    /**
     * Amazon:
     * 1) Priorizar el bloque JSON incrustado en:
     *    <div class="a-section aok-hidden twister-plus-buying-options-price-data">{"desktop_buybox_group_1":[{...}]}</div>
     *    - Recoger todos los priceAmount y/o displayPrice de todos los grupos.
     *    - Devolver el MÍNIMO.
     * 2) Fallback: spans visibles/ocultos:
     *    - <span class="a-offscreen">72,86€</span>
     *    - <span class="aok-offscreen"> 72,86&nbsp;€ ...</span>
     *    - Texto tipo: "Precio Suscríbete y ahorra ... 72,86 €"
     *    - Devolver el MÍNIMO encontrado.
     *
     * Sin bucles de reintento. Respuesta: número sin €, con punto decimal.
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        $resultado = $this->apiHTML->obtenerHTML($url);

        if (!is_array($resultado) || empty($resultado['success']) || empty($resultado['html'])) {
            return response()->json([
                'success' => false,
                'error'   => is_array($resultado) ? ($resultado['error'] ?? 'No se pudo obtener el HTML') : 'Respuesta inválida de la API',
            ]);
        }

        $html = (string)$resultado['html'];
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // 1) JSON en twister-plus-buying-options-price-data → mínimo
        $fromJson = $this->extraerMinimoDeTwisterJson($html);
        if ($fromJson !== null) {
            return response()->json(['success' => true, 'precio' => $fromJson]);
        }

        // 2) Fallback: spans/visibles → mínimo
        $fromSpans = $this->extraerMinimoDeSpans($html);
        if ($fromSpans !== null) {
            return response()->json(['success' => true, 'precio' => $fromSpans]);
        }

        return response()->json([
            'success' => false,
            'error'   => 'No se pudo encontrar el precio en la página de Amazon',
        ]);
    }

    /* ====================== Helpers ====================== */

    /**
     * Busca todos los div.twister-plus-buying-options-price-data, parsea sus JSON
     * y devuelve el precio mínimo entre priceAmount y displayPrice.
     */
    private function extraerMinimoDeTwisterJson(string $html): ?float
    {
        $precios = [];

        // Capturar contenido JSON entre las etiquetas del div con la clase esperada
        if (preg_match_all(
            '~<div[^>]*class=["\'][^"\']*twister-plus-buying-options-price-data[^"\']*["\'][^>]*>\s*(\{.*?\})\s*</div>~is',
            $html,
            $blocks
        )) {
            foreach ($blocks[1] as $jsonRaw) {
                $json = trim($jsonRaw);
                $decoded = json_decode($json, true);
                if (!is_array($decoded)) {
                    // Si falla, intentamos extraer priceAmount/displayPrice por regex dentro del blob
                    $this->agregarPreciosDesdeBlob($json, $precios);
                    continue;
                }

                // El JSON puede contener varios grupos (desktop_buybox_group_1, _2, mobile, etc.)
                $this->agregarPreciosDesdeArray($decoded, $precios);
            }
        }

        // Si no encontró div, algunos HTML lo tienen en atributos/data o múltiples blobs seguidos
        // Intento adicional: buscar blobs { ... "priceAmount": ... } cerca de esa clase
        if (empty($precios)) {
            if (preg_match_all(
                '~twister-plus-buying-options-price-data[^>]*>\s*(\{.*?\})\s*<~is',
                $html,
                $near
            )) {
                foreach ($near[1] as $jsonRaw) {
                    $this->agregarPreciosDesdeBlob($jsonRaw, $precios);
                }
            }
        }

        if (empty($precios)) return null;

        sort($precios, SORT_NUMERIC);
        return (float)$precios[0]; // mínimo
    }

    /**
     * Recorre arrays decodificados buscando priceAmount/displayPrice, acumulando valores.
     */
    private function agregarPreciosDesdeArray(array $node, array &$out): void
    {
        foreach ($node as $k => $v) {
            if (is_array($v)) {
                $this->agregarPreciosDesdeArray($v, $out);
            } else {
                // priceAmount numérico
                if (is_string($k) && $k === 'priceAmount' && (is_numeric($v) || is_string($v))) {
                    $n = $this->aNumero((string)$v);
                    if ($n !== null) $out[] = $n;
                }
                // displayPrice string: "76,69 €"
                if (is_string($k) && $k === 'displayPrice' && is_string($v)) {
                    if (preg_match('~(?<!\d)(\d{1,3}(?:[.,]\d{2}))~', $v, $m)) {
                        $n = $this->aNumero($m[1]);
                        if ($n !== null) $out[] = $n;
                    }
                }
            }
        }
    }

    /**
     * Extrae priceAmount/displayPrice por regex dentro de un blob JSON no parseable.
     */
    private function agregarPreciosDesdeBlob(string $blob, array &$out): void
    {
        // priceAmount: 76.69  (numérico)
        if (preg_match_all('~"priceAmount"\s*:\s*(\d+(?:\.\d{2}))~i', $blob, $m)) {
            foreach ($m[1] as $raw) {
                $n = $this->aNumero($raw);
                if ($n !== null) $out[] = $n;
            }
        }
        // displayPrice: "76,69 €"
        if (preg_match_all('~"displayPrice"\s*:\s*"(.*?)"~i', $blob, $m2)) {
            foreach ($m2[1] as $txt) {
                if (preg_match('~(?<!\d)(\d{1,3}(?:[.,]\d{2}))~', $txt, $mm)) {
                    $n = $this->aNumero($mm[1]);
                    if ($n !== null) $out[] = $n;
                }
            }
        }
    }

    /**
     * Fallback: obtiene TODOS los precios de spans relevantes y devuelve el mínimo.
     * - a-offscreen / aok-offscreen
     * - Texto con "Suscríbete y ahorra" con cantidad
     */
    private function extraerMinimoDeSpans(string $html): ?float
    {
        $precios = [];

        // <span class="a-offscreen">72,86€</span>
        if (preg_match_all(
            '~<span[^>]*class=["\']a-offscreen["\'][^>]*>\s*(\d{1,3}(?:[.,]\d{2}))\s*(?:€|&euro;)?~i',
            $html,
            $m1
        )) {
            foreach ($m1[1] as $raw) {
                $n = $this->aNumero($raw);
                if ($n !== null) $precios[] = $n;
            }
        }

        // <span class="aok-offscreen"> 72,86 € ... </span>
        if (preg_match_all(
            '~<span[^>]*class=["\']aok-offscreen["\'][^>]*>\s*(\d{1,3}(?:[.,]\d{2}))\s*(?:€|&euro;)?~i',
            $html,
            $m2
        )) {
            foreach ($m2[1] as $raw) {
                $n = $this->aNumero($raw);
                if ($n !== null) $precios[] = $n;
            }
        }

        // "Precio Suscríbete y ahorra ... 72,86 €"
        if (preg_match_all(
            '~Suscr[ií]bete\s+y\s+ahorra.*?(\d{1,3}(?:[.,]\d{2}))\s*(?:€|&euro;)?~is',
            $html,
            $m3
        )) {
            foreach ($m3[1] as $raw) {
                $n = $this->aNumero($raw);
                if ($n !== null) $precios[] = $n;
            }
        }

        if (empty($precios)) return null;

        sort($precios, SORT_NUMERIC);
        return (float)$precios[0];
    }

    /**
     * Convierte "76,69" / "76.69" a float con punto decimal.
     */
    private function aNumero($raw): ?float
    {
        if (!is_string($raw) && !is_numeric($raw)) return null;
        $s = trim((string)$raw);

        // Si hay coma y punto, asumimos formato ES con punto de miles
        if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
            // Quitar puntos de miles
            $s = str_replace('.', '', $s);
        }
        $s = str_replace(',', '.', $s);

        if (!is_numeric($s)) return null;
        return (float)$s;
    }
}
