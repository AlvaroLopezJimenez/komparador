<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use App\Http\Controllers\Scraping\Tiendas\PlantillaTiendaController;
use Illuminate\Http\JsonResponse;

class AtidaController extends PlantillaTiendaController
{
    /**
     * Extrae el precio de una página de Atida.
     *
     * @param string      $url
     * @param string|null $variante
     * @return \Illuminate\Http\JsonResponse
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        $resultado = $this->apiHTML->obtenerHTML($url);

        if (!is_array($resultado) || empty($resultado['success'])) {
            return response()->json([
                'success' => false,
                'error'   => $resultado['error'] ?? 'No se pudo obtener el HTML',
            ]);
        }

        $html = (string)($resultado['html'] ?? '');

        if ($html === '') {
            return response()->json([
                'success' => false,
                'error'   => 'HTML vacío recibido',
            ]);
        }

        // Normalizamos entidades para facilitar regex (ej. &nbsp;)
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Patrones posibles detectados en Atida
        $patrones = [
            // <span class="price-wrapper ..."><span class="price" x-html="getFormattedFinalPrice()"><span class="price">23,99 €</span></span></span>
            '~<span[^>]*class=["\']price-wrapper[^"\']*["\'][^>]*>.*?(?:<span[^>]*class=["\']price[^"\']*["\'][^>]*>.*?)?(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?~si',
            // <span class="price font-semibold" x-html="getFormattedFinalPrice()">23,99 €</span>
            '~<span[^>]*x-html=["\']getFormattedFinalPrice\(\)["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?\s*</span>~si',
            // <span class="price">23,99 €</span>
            '~<span[^>]*class=["\']price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?\s*</span>~si',
            // <span class="clerk-price"> 23,99 </span>
            '~<span[^>]*class=["\']clerk-price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*</span>~si',
            // <li class="flex flex-col"><span class="font-semibold">PVP</span> 23,99 </li>
            '~<li[^>]*>\s*<span[^>]*>\s*PVP\s*</span>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\b~si',
        ];

        $precio = null;

        foreach ($patrones as $regex) {
            if (preg_match($regex, $html, $m) && !empty($m['p'])) {
                $precio = $this->normalizarImporte($m['p']);
                if ($precio !== null) {
                    break;
                }
            }
        }

        if ($precio === null) {
            return response()->json([
                'success' => false,
                'error'   => 'No se pudo encontrar el precio en la página',
            ]);
        }

        return response()->json([
            'success' => true,
            'precio'  => $precio, // número sin símbolo €; con decimales solo si existen
        ]);
    }

    /**
     * Convierte una cadena de precio europea/española a float (sin símbolo €).
     * - Acepta formatos: "23,99", "1.234,56", "23.99", "1234", etc.
     * - Devuelve null si no se puede interpretar.
     *
     * @param string $importe
     * @return float|null
     */
    private function normalizarImporte(string $importe): ?float
    {
        // Eliminar cualquier cosa que no sea dígito, coma o punto
        $s = preg_replace('/[^\d\,\.]/u', '', $importe);
        if ($s === null || $s === '') {
            return null;
        }

        $tieneComa = strpos($s, ',') !== false;
        $tienePunto = strpos($s, '.') !== false;

        if ($tieneComa && $tienePunto) {
            // Asumimos formato ES: miles con punto y decimales con coma (1.234,56)
            // Regla: el separador decimal es el último signo entre coma y punto
            $lastComma = strrpos($s, ',');
            $lastDot   = strrpos($s, '.');

            if ($lastComma !== false && ($lastDot === false || $lastComma > $lastDot)) {
                // Decimal = coma -> quitamos puntos de miles
                $s = str_replace('.', '', $s);
                $s = str_replace(',', '.', $s);
            } else {
                // Decimal = punto -> quitamos comas de miles
                $s = str_replace(',', '', $s);
                // $s mantiene el punto como decimal
            }
        } elseif ($tieneComa) {
            // Solo coma -> decimal = coma
            $s = str_replace(',', '.', $s);
        } else {
            // Solo dígitos o con punto ya decimal
            // Nada que hacer
        }

        // Validación final
        if (!preg_match('/^\d+(\.\d+)?$/', $s)) {
            return null;
        }

        // Cast a float
        $valor = (float)$s;

        return $valor;
    }
}
