<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use App\Http\Controllers\Scraping\Tiendas\PlantillaTiendaController;
use Illuminate\Http\JsonResponse;

class ElcorteinglesController extends PlantillaTiendaController
{
    /**
     * Extrae el precio de una página de El Corte Inglés (Supermercado).
     * - Reintenta hasta 3 veces la obtención del HTML.
     * - Prioriza dataLayer / JSON embebido ("price.final").
     * - Luego intenta JSON-LD (@type=Offer -> price).
     * - Fallback en HTML visible (food-prices__price).
     * - Ignora explícitamente OfferShippingDetails (shippingRate.value).
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        $html = null;
        $ultimoError = null;

        // Reintentos: hasta 3 llamadas a la API seguidas aun no hay controlador que si lo consigue que pare el bucle
        //POR ESO LO TENGO COMENTADO
        // for ($i = 1; $i <= 3; $i++) {
            $resultado = $this->apiHTML->obtenerHTML($url);

            if (is_array($resultado) && !empty($resultado['success']) && !empty($resultado['html'])) {
                $html = (string)$resultado['html'];
                // break;
            }

            $ultimoError = is_array($resultado) ? ($resultado['error'] ?? 'Error desconocido') : 'Respuesta inválida de la API';
            usleep(700000); // ~0.7s
        // }

        if ($html === null || $html === '') {
            return response()->json([
                'success' => false,
                'error'   => 'No se pudo obtener el HTML de El Corte Inglés' . ($ultimoError ? (': ' . $ultimoError) : ''),
            ]);
        }

        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // ---- 1) dataLayer / JSON embebido: "price":{"final":"31.55"} o "price":{"final":31.55} ----
        $precio = $this->extraerPrecioDePriceFinal($html);
        if ($precio !== null) {
            return response()->json(['success' => true, 'precio' => $precio]);
        }

        // ---- 2) JSON-LD <script type="application/ld+json"> ... {"@type":"Offer","price":"31.55"} ... ----
        $precio = $this->extraerPrecioDeJsonLd($html);
        if ($precio !== null) {
            return response()->json(['success' => true, 'precio' => $precio]);
        }

        // ---- 3) Fallback visible en HTML (supermercado) ----
        $precio = $this->extraerPrecioDeHtmlVisible($html);
        if ($precio !== null) {
            return response()->json(['success' => true, 'precio' => $precio]);
        }

        return response()->json([
            'success' => false,
            'error'   => 'No se pudo encontrar el precio en la página de El Corte Inglés',
        ]);
    }

    /**
     * Busca "price.final" en blobs JSON embebidos (dataLayer, window.__STATE__, etc.)
     * Coincide tanto string como numérico y evita confundir con shipping.
     */
    private function extraerPrecioDePriceFinal(string $html): ?float
    {
        // Ejemplos:
        // "price":{"final":"31.55"}
        // "price":{"original":53.25,"final":53.25,"currency":"EUR"}
        $regexes = [
            '~"price"\s*:\s*\{\s*"[^"]*final[^"]*"\s*:\s*"(?<p>\d+(?:\.\d{2})?)"~i',
            '~"price"\s*:\s*\{\s*"[^"]*final[^"]*"\s*:\s*(?<p>\d+(?:\.\d{2})?)\b~i',
        ];

        foreach ($regexes as $rx) {
            if (preg_match($rx, $html, $m) && !empty($m['p'])) {
                $p = $this->normalizarImporte($m['p']);
                if ($p !== null) return $p;
            }
        }

        return null;
    }

    /**
     * Busca <script type="application/ld+json"> y extrae el primer @type=Offer con "price".
     * Ignora objetos con "@type":"OfferShippingDetails".
     * Soporta JSON único u arrays de objetos.
     */
    private function extraerPrecioDeJsonLd(string $html): ?float
    {
        // Extraer cada bloque JSON-LD
        if (!preg_match_all('~<script[^>]+type=["\']application/ld\+json["\'][^>]*>(?<json>.*?)</script>~is', $html, $blocks)) {
            // Intento por regex directo cuando el script no está marcado correctamente
            return $this->extraerPrecioDeJsonLdPorRegex($html);
        }

        foreach ($blocks['json'] as $raw) {
            $json = trim($raw);
            if ($json === '') continue;

            // A veces incluyen comentarios o caracteres BOM; limpiamos lo básico
            $json = preg_replace('/\/\/.*$/m', '', $json);       // quitar // comentarios
            $json = preg_replace('/\/\*.*?\*\//s', '', $json);   // quitar /* ... */ comentarios

            // Intentar decodificar JSON
            $decoded = json_decode($json, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                // Si falla, último intento: regex dentro del bloque para Offer.price
                $p = $this->extraerPrecioDeJsonLdPorRegex($json);
                if ($p !== null) return $p;
                continue;
            }

            // Normalizar a lista de objetos
            $items = is_array($decoded) && isset($decoded['@type'])
                ? [$decoded]
                : (is_array($decoded) ? $decoded : []);

            // JSON-LD puede ser { "@graph": [ ... ] }
            if (isset($decoded['@graph']) && is_array($decoded['@graph'])) {
                $items = array_merge($items, $decoded['@graph']);
            }

            foreach ($items as $item) {
                if (!is_array($item)) continue;

                // Evitar ShippingDetails
                if (isset($item['@type']) && is_string($item['@type']) && stripos($item['@type'], 'OfferShippingDetails') !== false) {
                    continue;
                }

                // Si el item es un Product, puede traer "offers" -> Offer|Offer[]
                if (isset($item['@type']) && is_string($item['@type']) && stripos($item['@type'], 'Product') !== false) {
                    if (isset($item['offers'])) {
                        $offers = is_array($item['offers']) && isset($item['offers']['@type'])
                            ? [$item['offers']]
                            : (is_array($item['offers']) ? $item['offers'] : []);
                        foreach ($offers as $offer) {
                            if (!is_array($offer)) continue;
                            if (isset($offer['@type']) && stripos((string)$offer['@type'], 'Offer') === false) continue;
                            if (isset($offer['price'])) {
                                $p = $this->normalizarImporte((string)$offer['price']);
                                if ($p !== null) return $p;
                            }
                        }
                    }
                }

                // Directamente un Offer
                if (isset($item['@type']) && is_string($item['@type']) && stripos($item['@type'], 'Offer') !== false) {
                    if (isset($item['price'])) {
                        $p = $this->normalizarImporte((string)$item['price']);
                        if ($p !== null) return $p;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Búsqueda por regex para bloques con "@type":"Offer" y "price":"31.55",
     * evitando "OfferShippingDetails".
     */
    private function extraerPrecioDeJsonLdPorRegex(string $text): ?float
    {
        // Buscar bloques que contengan @type":"Offer" (no OfferShippingDetails) y luego "price": "xx.xx" o xx.xx
        if (preg_match_all('~\{[^{}]*"@type"\s*:\s*"Offer"(?!ShippingDetails)[^{}]*\}~is', $text, $blocks)) {
            foreach ($blocks[0] as $block) {
                if (preg_match('~"price"\s*:\s*"?(?<p>\d+(?:\.\d{2})?)"?~i', $block, $m) && !empty($m['p'])) {
                    $p = $this->normalizarImporte($m['p']);
                    if ($p !== null) return $p;
                }
            }
        }
        return null;
    }

    /**
     * Fallback: precio visible en el HTML del súper.
     */
    private function extraerPrecioDeHtmlVisible(string $html): ?float
    {
        $regexes = [
            // <div class="food-prices__price">31,55 €</div>
            '~<div[^>]*class=["\']food-prices__price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?\s*</div>~si',
            // <span class="food-prices__price">31,55 €</span>
            '~<span[^>]*class=["\']food-prices__price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?\s*</span>~si',
        ];

        foreach ($regexes as $rx) {
            if (preg_match($rx, $html, $m) && !empty($m['p'])) {
                $p = $this->normalizarImporte($m['p']);
                if ($p !== null) return $p;
            }
        }
        return null;
    }

    /**
     * Convierte una cadena de precio a float (sin símbolo €).
     * Acepta "31.55", "31,55", "1.234,56", etc. Devuelve null si no es interpretable.
     */
    private function normalizarImporte(string $importe): ?float
    {
        // Mantener solo dígitos, coma o punto
        $s = preg_replace('/[^\d\,\.]/u', '', $importe);
        if ($s === null || $s === '') {
            return null;
        }

        $tieneComa  = strpos($s, ',') !== false;
        $tienePunto = strpos($s, '.') !== false;

        if ($tieneComa && $tienePunto) {
            // Determinar último separador como decimal
            $lastComma = strrpos($s, ',');
            $lastDot   = strrpos($s, '.');

            if ($lastComma !== false && ($lastDot === false || $lastComma > $lastDot)) {
                // Decimal con coma -> quitar puntos (miles) y cambiar coma por punto
                $s = str_replace('.', '', $s);
                $s = str_replace(',', '.', $s);
            } else {
                // Decimal con punto -> quitar comas (miles)
                $s = str_replace(',', '', $s);
            }
        } elseif ($tieneComa) {
            // Solo coma -> usar como decimal
            $s = str_replace(',', '.', $s);
        } else {
            // Solo dígitos o ya con punto decimal
        }

        if (!preg_match('/^\d+(\.\d+)?$/', $s)) {
            return null;
        }

        return (float)$s;
    }
}
