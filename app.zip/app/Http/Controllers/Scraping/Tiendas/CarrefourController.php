<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use App\Http\Controllers\Scraping\Tiendas\PlantillaTiendaController;
use Illuminate\Http\JsonResponse;

class CarrefourController extends PlantillaTiendaController
{
    /**
     * Extrae el precio de una página de Carrefour.
     * - Reintenta hasta 3 veces la obtención del HTML (Carrefour a veces falla).
     * - Asegura que la URL termine en /p (si aplica).
     *
     * @param string      $url
     * @param string|null $variante
     * @return \Illuminate\Http\JsonResponse
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        // Muchas URLs de Carrefour requieren el sufijo /p para mostrar el PDP canónico
        if (!preg_match('~/(p|pd)$~i', rtrim($url, '/'))) {
            $url = rtrim($url, '/') . '/p';
        }

        $html = null;
        $ultimoError = null;

        $maxIntentos = 3;
        $delayUs     = 700000; // 0.7s

        for ($i = 1; $i <= $maxIntentos; $i++) {
            $resultado = $this->apiHTML->obtenerHTML($url);

            if (is_array($resultado) && !empty($resultado['success']) && !empty($resultado['html'])) {
                $html = (string) $resultado['html'];
                break; // Éxito → salimos del bucle
            }

            // Fallo → guardamos último error y reintentamos si quedan intentos
            $ultimoError = is_array($resultado)
                ? ($resultado['error'] ?? 'Error desconocido')
                : 'Respuesta inválida de la API';

            if ($i < $maxIntentos) {

                // Esperar dos segundos antes de reintentar
                sleep(2);
            }
        }

        if ($html === null || $html === '') {
            return response()->json([
                'success' => false,
                'error'   => 'No se pudo obtener el HTML de Carrefour' . ($ultimoError ? (': ' . $ultimoError) : ''),
            ]);
        }

        // Normalizamos entidades (&nbsp; -> espacio, etc.)
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Único selector conocido:
        // <span class="buybox__price"> 23,60 € </span>
        $regex = '~<span[^>]*class=["\']buybox__price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})?)\s*(?:€|&euro;)?\s*</span>~si';

        if (!preg_match($regex, $html, $m) || empty($m['p'])) {
            return response()->json([
                'success' => false,
                'error'   => 'No se encontró el precio en la página (selector buybox__price)',
            ]);
        }

        $precio = $this->normalizarImporte($m['p']);

        if ($precio === null) {
            return response()->json([
                'success' => false,
                'error'   => 'Formato de precio no reconocido',
            ]);
        }

        return response()->json([
            'success' => true,
            'precio'  => $precio, // número sin símbolo €
        ]);
    }

    /**
     * Convierte una cadena de precio europea/española a float (sin símbolo €).
     * - Acepta "23,60", "1.234,56", "23.60", "1234", etc.
     * - Devuelve null si no se puede interpretar.
     *
     * @param string $importe
     * @return float|null
     */
    private function normalizarImporte(string $importe): ?float
    {
        // Mantener solo dígitos, coma o punto
        $s = preg_replace('/[^\d\,\.]/u', '', $importe);
        if ($s === null || $s === '') {
            return null;
        }

        $tieneComa  = strpos($s, ',') !== false;
        $tienePunto = strpos($s, '.') !== false;

        if ($tieneComa && $tienePunto) {
            // Decimales = el último separador que aparezca
            $lastComma = strrpos($s, ',');
            $lastDot   = strrpos($s, '.');

            if ($lastComma !== false && ($lastDot === false || $lastComma > $lastDot)) {
                // Decimal con coma -> quitar puntos de miles
                $s = str_replace('.', '', $s);
                $s = str_replace(',', '.', $s);
            } else {
                // Decimal con punto -> quitar comas de miles
                $s = str_replace(',', '', $s);
                // dejar punto como decimal
            }
        } elseif ($tieneComa) {
            // Solo coma -> usar como decimal
            $s = str_replace(',', '.', $s);
        } else {
            // Solo dígitos o ya con punto decimal
        }

        if (!preg_match('/^\d+(\.\d+)?$/', $s)) {
            return null;
        }

        return (float)$s;
    }
}
