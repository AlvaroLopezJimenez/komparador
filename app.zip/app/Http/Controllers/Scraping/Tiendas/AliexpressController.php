<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use Illuminate\Http\JsonResponse;

class AliexpressController extends PlantillaTiendaController
{
    /**
     * Usa la API de RapidAPI "aliexpress-datahub" para obtener el precio.
     * NO se hace scraping de HTML.
     *
     * Entrada:
     *  - $url: ej. https://es.aliexpress.com/item/1005005244562338.html
     *  - $variante: skuId (string) para el que queremos el precio. Si existe
     *               "promotionPrice" se usa; si no, "price".
     *  - Si $variante es null/vacío, devolverá el mínimo (promotionPrice|price) entre los SKUs base.
     *
     * Devuelve:
     *  - { success: true, precio: <float sin € y con punto> }
     *  - { success: false, error: "..." }
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        // 1) Extraer itemId de la URL
        $itemId = $this->extraerItemId($url);
        if ($itemId === null) {
            return response()->json([
                'success' => false,
                'error'   => 'No se pudo extraer el itemId de la URL de AliExpress',
            ]);
        }

        // 2) Llamada a la API de RapidAPI (API key embebida en el archivo, como pides)
        $apiKey = 'e7641b483cmshcac145d48569584p1de82ejsn452206de102d'; // <-- tu API KEY aquí
        $endpoint = "https://aliexpress-datahub.p.rapidapi.com/item_detail_2?itemId={$itemId}&currency=EUR&region=ES&locale=es_ES";

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 5,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST  => 'GET',
            CURLOPT_HTTPHEADER     => [
                'x-rapidapi-host: aliexpress-datahub.p.rapidapi.com',
                'x-rapidapi-key: ' . $apiKey,
            ],
        ]);

        $response = curl_exec($ch);
        $err      = curl_error($ch);
        $status   = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($err) {
            return response()->json([
                'success' => false,
                'error'   => 'Error en cURL: ' . $err,
            ]);
        }

        if ($status < 200 || $status >= 300) {
            return response()->json([
                'success' => false,
                'error'   => 'HTTP ' . $status . ' al llamar a la API de AliExpress',
                'raw'     => $response,
            ]);
        }

        // 3) Parsear JSON
        $data = json_decode($response, true);
        if (!is_array($data) || empty($data['result']['item']['sku']['base'])) {
            return response()->json([
                'success' => false,
                'error'   => 'Respuesta inesperada de la API (sin sku.base)',
                'raw'     => $response,
            ]);
        }

        $base = $data['result']['item']['sku']['base']; // array de SKUs
        if (!is_array($base) || empty($base)) {
            return response()->json([
                'success' => false,
                'error'   => 'Sin SKUs en la respuesta',
            ]);
        }

        // 4) Selección de precio según $variante (skuId) o mínimo si no viene variante
        $precio = null;

        if ($variante !== null && $variante !== '') {
            $skuIdWanted = (string) $variante;
            foreach ($base as $sku) {
                if (!is_array($sku)) continue;
                if (!isset($sku['skuId'])) continue;

                if ((string)$sku['skuId'] === $skuIdWanted) {
                    // Preferir promotionPrice, si no price
                    $raw = $sku['promotionPrice'] ?? $sku['price'] ?? null;
                    $precio = $this->aNumero($raw);
                    break;
                }
            }

            if ($precio === null) {
                return response()->json([
                    'success' => false,
                    'error'   => 'No se encontró el skuId indicado en los SKUs base',
                ]);
            }
        } else {
            // Sin variante -> mínimo entre todos (promotionPrice si existe, si no price)
            $candidatos = [];
            foreach ($base as $sku) {
                if (!is_array($sku)) continue;
                $raw = $sku['promotionPrice'] ?? $sku['price'] ?? null;
                $n = $this->aNumero($raw);
                if ($n !== null) $candidatos[] = $n;
            }

            if (empty($candidatos)) {
                return response()->json([
                    'success' => false,
                    'error'   => 'No hay precios en los SKUs base',
                ]);
            }

            sort($candidatos, SORT_NUMERIC);
            $precio = (float) $candidatos[0];
        }

        return response()->json([
            'success' => true,
            'precio'  => $precio, // sin símbolo €, con punto decimal
        ]);
    }

    /* ====================== Helpers ====================== */

    /**
     * Extrae el itemId de URLs tipo:
     *  - https://es.aliexpress.com/item/1005005244562338.html
     *  - https://www.aliexpress.com/item/1005005244562338.html?spm=...
     *  - También acepta que le pasen directamente el ID (sólo dígitos).
     */
    private function extraerItemId(string $url): ?string
    {
        $url = trim($url);

        // Si son solo dígitos, ya es el itemId
        if (preg_match('/^\d{6,}$/', $url)) {
            return $url;
        }

        // Buscar el patrón .../item/<ID>.html
        if (preg_match('~/(?:item/)?(\d{6,})\.html~i', $url, $m)) {
            return $m[1];
        }

        // Como último recurso, buscar un número largo en la URL
        if (preg_match('/(\d{6,})/', $url, $m2)) {
            return $m2[1];
        }

        return null;
    }

    /**
     * Convierte "76,54" o "76.54" (string/num) a float con punto decimal.
     */
    private function aNumero($raw): ?float
    {
        if ($raw === null) return null;
        if (!is_string($raw) && !is_numeric($raw)) return null;

        $s = trim((string)$raw);

        // Si trae coma y punto, asumimos formato ES con punto de miles
        if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
            $s = str_replace('.', '', $s);
        }
        $s = str_replace(',', '.', $s);

        if (!is_numeric($s)) return null;
        return (float)$s;
    }
}
