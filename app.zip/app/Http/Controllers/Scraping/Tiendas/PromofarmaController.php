<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use Illuminate\Http\JsonResponse;

class PromofarmaController extends PlantillaTiendaController
{
    /**
     * Promofarma: el precio correcto está en:
     * <span id="price" ... data-price="22,09€">
     *
     * Sin bucles de reintento.
     * Devuelve número sin símbolo € y con punto decimal.
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        $resultado = $this->apiHTML->obtenerHTML($url);

        if (!is_array($resultado) || empty($resultado['success']) || empty($resultado['html'])) {
            return response()->json([
                'success' => false,
                'error'   => is_array($resultado) ? ($resultado['error'] ?? 'No se pudo obtener el HTML') : 'Respuesta inválida de la API',
            ]);
        }

        $html = (string) $resultado['html'];
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // 1) Buscar atributo data-price en el span con id="price"
        if (preg_match(
            '~<span[^>]*id=["\']price["\'][^>]*data-price=["\'](?<p>[\d.,]+)\s*(?:€|&euro;)?["\']~i',
            $html,
            $m
        ) && !empty($m['p'])) {
            $precio = $this->aNumero($m['p']);
            if ($precio !== null) {
                return response()->json(['success' => true, 'precio' => $precio]);
            }
        }

        // 2) Fallback: buscar texto interno en el span con id="price"
        if (preg_match(
            '~<span[^>]*id=["\']price["\'][^>]*>\s*(?<p>\d{1,3}(?:[.,]\d{2}))\s*(?:€|&euro;)?~i',
            $html,
            $m2
        ) && !empty($m2['p'])) {
            $precio = $this->aNumero($m2['p']);
            if ($precio !== null) {
                return response()->json(['success' => true, 'precio' => $precio]);
            }
        }

        return response()->json([
            'success' => false,
            'error'   => 'No se pudo encontrar el precio en la página de Promofarma',
        ]);
    }

    /**
     * Convierte "22,09" o "22.09" a float con punto decimal.
     */
    private function aNumero($raw): ?float
    {
        if (!is_string($raw) && !is_numeric($raw)) return null;
        $s = trim((string)$raw);

        if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
            // Caso raro con miles y coma decimal
            $s = str_replace('.', '', $s);
        }
        $s = str_replace(',', '.', $s);

        if (!is_numeric($s)) return null;
        return (float)$s;
    }
}
