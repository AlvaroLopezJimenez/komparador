<?php

namespace App\Http\Controllers\Scraping\Tiendas;

use Illuminate\Http\JsonResponse;

class MiraviaController extends PlantillaTiendaController
{
    /**
     * Miravia: el precio correcto es `priceNumber` (no confundir con
     * `originalPriceNumber` ni `unitPriceText`).
     *
     * Sin bucles de reintento.
     * Devuelve número sin símbolo € y con punto decimal.
     */
    public function obtenerPrecio($url, $variante = null): JsonResponse
    {
        $resultado = $this->apiHTML->obtenerHTML($url);

        if (!is_array($resultado) || empty($resultado['success']) || empty($resultado['html'])) {
            return response()->json([
                'success' => false,
                'error'   => is_array($resultado) ? ($resultado['error'] ?? 'No se pudo obtener el HTML') : 'Respuesta inválida de la API',
            ]);
        }

        $html = (string) $resultado['html'];
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // 1) priceNumber (clave exacta)
        //    Soporta: "priceNumber":"44.29"  |  "priceNumber":44.29
        if (preg_match('~["\']priceNumber["\']\s*:\s*["\']?(?<p>\d+(?:[.,]\d{2}))~i', $html, $m) && !empty($m['p'])) {
            $precio = $this->aNumero($m['p']);
            if ($precio !== null) {
                return response()->json(['success' => true, 'precio' => $precio]);
            }
        }

        // 2) Fallback: priceText (ej. "44,29€") — NO confundir con originalPriceText ni unitPriceText
        if (preg_match('~["\']priceText["\']\s*:\s*["\']\s*(?<p>\d{1,3}(?:[.,]\d{2}))\s*(?:€|&euro;)?\s*["\']~i', $html, $m2) && !empty($m2['p'])) {
            $precio = $this->aNumero($m2['p']);
            if ($precio !== null) {
                return response()->json(['success' => true, 'precio' => $precio]);
            }
        }

        // 3) Fallback adicional por si viene en data-atributos (menos común)
        //    Ej: data-price-number="44.29"
        if (preg_match('~data-price-number\s*=\s*["\'](?<p>\d+(?:[.,]\d{2}))["\']~i', $html, $m3) && !empty($m3['p'])) {
            $precio = $this->aNumero($m3['p']);
            if ($precio !== null) {
                return response()->json(['success' => true, 'precio' => $precio]);
            }
        }

        return response()->json([
            'success' => false,
            'error'   => 'No se pudo encontrar priceNumber en la página de Miravia',
        ]);
    }

    /**
     * Convierte "44,29" o "44.29" a float con punto decimal.
     */
    private function aNumero($raw): ?float
    {
        if (!is_string($raw) && !is_numeric($raw)) return null;
        $s = trim((string)$raw);

        // Si hay coma y punto, asumimos formato ES con miles en punto (poco probable aquí)
        if (strpos($s, ',') !== false && strpos($s, '.') !== false) {
            $s = str_replace('.', '', $s);
        }
        $s = str_replace(',', '.', $s);

        if (!is_numeric($s)) return null;
        return (float)$s;
    }
}
