<?php

namespace App\Http\Controllers\Scraping;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OfertaProducto;
use App\Models\Tienda;
use App\Models\EjecucionGlobal;
use Illuminate\Support\Facades\DB;

class DiagnosticoController extends Controller
{
    /**
     * Mostrar diagnóstico del sistema de scraping
     */
    public function index()
    {
        // Obtener estadísticas de ofertas
        $totalOfertas = OfertaProducto::count();
        $ofertasMostrar = OfertaProducto::where('mostrar', 'si')->count();
        $ofertasOcultas = OfertaProducto::where('mostrar', 'no')->count();
        
        // Obtener ofertas que cumplen criterios para scraping
        $ofertasElegibles = OfertaProducto::with(['producto', 'tienda'])
            ->where('mostrar', 'si')
            ->whereRaw('TIMESTAMPDIFF(MINUTE, updated_at, NOW()) >= frecuencia_actualizar_precio_minutos')
            ->orderByRaw('TIMESTAMPDIFF(MINUTE, updated_at, NOW()) DESC')
            ->limit(10)
            ->get();
        
        // Obtener tiendas disponibles
        $tiendas = Tienda::withCount(['ofertas' => function($query) {
            $query->where('mostrar', 'si');
        }])->get();
        
        // Calcular ejecuciones de scraping por día
        $ejecucionesPorDia = $this->calcularEjecucionesPorDia();
        
        // Verificar controladores de tiendas disponibles
        $controladoresTiendas = $this->obtenerControladoresTiendas();
        
        // Calcular limitaciones de API
        $limitacionesAPI = $this->calcularLimitacionesAPI();
        
        return view('admin.scraping.diagnostico', compact(
            'totalOfertas',
            'ofertasMostrar', 
            'ofertasOcultas',
            'ofertasElegibles',
            'tiendas',
            'controladoresTiendas',
            'ejecucionesPorDia',
            'limitacionesAPI'
        ));
    }
    
    /**
     * Obtener lista de controladores de tiendas disponibles
     */
    private function obtenerControladoresTiendas()
    {
        $tiendasPath = app_path('Http/Controllers/Scraping/Tiendas');
        $controladores = [];
        
        if (file_exists($tiendasPath)) {
            $archivos = scandir($tiendasPath);
            
            foreach ($archivos as $archivo) {
                if (pathinfo($archivo, PATHINFO_EXTENSION) === 'php' && 
                    $archivo !== 'PlantillaTiendaController.php' &&
                    $archivo !== 'INSTRUCCIONES_TIENDAS.txt') {
                    
                    $nombreTienda = str_replace('Controller.php', '', $archivo);
                    $controladores[] = $nombreTienda;
                }
            }
        }
        
        sort($controladores);
        return $controladores;
    }
    
    /**
     * Calcular ejecuciones de scraping por día basado en la frecuencia de actualización
     */
    private function calcularEjecucionesPorDia()
    {
        // Obtener todas las ofertas activas con su frecuencia de actualización
        $ofertasActivas = OfertaProducto::with('tienda')
            ->where('mostrar', 'si')
            ->where('frecuencia_actualizar_precio_minutos', '>', 0)
            ->get();
        
        $ejecucionesPorTienda = [];
        $totalEjecuciones = 0;
        
        // Obtener controladores disponibles para verificación
        $controladoresTiendas = $this->obtenerControladoresTiendas();
        
        foreach ($ofertasActivas as $oferta) {
            $tiendaNombre = $oferta->tienda->nombre;
            $frecuenciaMinutos = $oferta->frecuencia_actualizar_precio_minutos;
            
            // Calcular cuántas veces se ejecuta por día (1440 minutos = 24 horas)
            $ejecucionesPorDia = 1440 / $frecuenciaMinutos;
            
            if (!isset($ejecucionesPorTienda[$tiendaNombre])) {
                // Verificar si existe controlador para esta tienda
                $controladorExiste = $this->verificarControladorTienda($tiendaNombre, $controladoresTiendas);
                
                $ejecucionesPorTienda[$tiendaNombre] = [
                    'ofertas' => 0,
                    'ejecuciones_por_dia' => 0,
                    'frecuencias' => [],
                    'controlador_existe' => $controladorExiste
                ];
            }
            
            $ejecucionesPorTienda[$tiendaNombre]['ofertas']++;
            $ejecucionesPorTienda[$tiendaNombre]['ejecuciones_por_dia'] += $ejecucionesPorDia;
            $ejecucionesPorTienda[$tiendaNombre]['frecuencias'][] = [
                'minutos' => $frecuenciaMinutos,
                'ejecuciones_por_dia' => $ejecucionesPorDia
            ];
            
            $totalEjecuciones += $ejecucionesPorDia;
        }
        
        // Ordenar por número de ejecuciones (descendente)
        uasort($ejecucionesPorTienda, function($a, $b) {
            return $b['ejecuciones_por_dia'] <=> $a['ejecuciones_por_dia'];
        });
        
        return [
            'total_ejecuciones_por_dia' => round($totalEjecuciones, 2),
            'total_ofertas_activas' => $ofertasActivas->count(),
            'por_tienda' => $ejecucionesPorTienda
        ];
    }
    
    /**
     * Normalizar nombre de tienda para comparar con controladores
     */
    private function normalizarNombreTienda($nombreTienda)
    {
        // Convertir a minúsculas y quitar espacios, guiones, puntos, etc.
        $normalizado = strtolower($nombreTienda);
        $normalizado = preg_replace('/[^a-z0-9]/', '', $normalizado);
        return $normalizado;
    }
    
    /**
     * Verificar si existe controlador para una tienda
     */
    private function verificarControladorTienda($nombreTienda, $controladoresTiendas)
    {
        $nombreNormalizado = $this->normalizarNombreTienda($nombreTienda);
        
        foreach ($controladoresTiendas as $controlador) {
            $controladorNormalizado = $this->normalizarNombreTienda($controlador);
            if ($nombreNormalizado === $controladorNormalizado) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Obtener ofertas con errores y éxitos de scraping
     */
    public function ofertasErroresExitos(Request $request)
    {
        $fecha = $request->input('fecha', now()->toDateString());
        $mostrarExitos = $request->input('mostrar_exitos', 'true') === 'true';
        $mostrarErrores = $request->input('mostrar_errores', 'true') === 'true';
        $perPage = $request->input('perPage', 20);
        
        // Obtener ejecuciones del día seleccionado
        $ejecuciones = EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas')
            ->whereDate('created_at', $fecha)
            ->orderBy('created_at', 'desc')
            ->get();
        
        $ofertasResultados = [];
        $ofertasUltimoEstado = []; // Para trackear el último estado de cada oferta
        
        foreach ($ejecuciones as $ejecucion) {
            if (!isset($ejecucion->log['resultados']) || !is_array($ejecucion->log['resultados'])) {
                continue;
            }
            
            foreach ($ejecucion->log['resultados'] as $resultado) {
                $ofertaId = $resultado['oferta_id'];
                $horaEjecucion = $ejecucion->created_at;
                
                // Solo guardar el resultado más reciente de cada oferta
                if (!isset($ofertasUltimoEstado[$ofertaId]) || 
                    $horaEjecucion > $ofertasUltimoEstado[$ofertaId]['hora']) {
                    
                    $ofertasUltimoEstado[$ofertaId] = [
                        'oferta_id' => $ofertaId,
                        'tienda_nombre' => $resultado['tienda_nombre'],
                        'url' => $resultado['url'],
                        'variante' => $resultado['variante'],
                        'precio_anterior' => $resultado['precio_anterior'],
                        'precio_nuevo' => $resultado['precio_nuevo'],
                        'success' => $resultado['success'],
                        'error' => $resultado['error'],
                        'hora' => $horaEjecucion,
                        'cambios_detectados' => $resultado['cambios_detectados'] ?? false
                    ];
                }
            }
        }
        
        // Convertir a array y aplicar filtros
        $ofertasResultados = array_values($ofertasUltimoEstado);
        
        // Aplicar filtros
        $ofertasResultados = array_filter($ofertasResultados, function($oferta) use ($mostrarExitos, $mostrarErrores) {
            if ($oferta['success'] === true) {
                return $mostrarExitos;
            } else {
                return $mostrarErrores;
            }
        });
        
        // Ordenar por hora (más reciente primero)
        usort($ofertasResultados, function($a, $b) {
            return $b['hora'] <=> $a['hora'];
        });
        
        // Paginación manual
        $total = count($ofertasResultados);
        $page = $request->input('page', 1);
        $offset = ($page - 1) * $perPage;
        $ofertasPaginadas = array_slice($ofertasResultados, $offset, $perPage);
        
        // Obtener fechas disponibles para el calendario
        $fechasDisponibles = $this->obtenerFechasDisponibles();
        
        // Calcular estadísticas totales del día (sin filtros)
        $todasLasOfertas = array_values($ofertasUltimoEstado);
        $totalExitos = count(array_filter($todasLasOfertas, function($oferta) {
            return $oferta['success'] === true;
        }));
        $totalErrores = count(array_filter($todasLasOfertas, function($oferta) {
            return $oferta['success'] === false;
        }));
        
        return response()->json([
            'ofertas' => $ofertasPaginadas,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'last_page' => ceil($total / $perPage),
            'fechas_disponibles' => $fechasDisponibles,
            'fecha_seleccionada' => $fecha,
            'mostrar_exitos' => $mostrarExitos,
            'mostrar_errores' => $mostrarErrores,
            'estadisticas_dia' => [
                'exitos' => $totalExitos,
                'errores' => $totalErrores,
                'total' => count($todasLasOfertas)
            ]
        ]);
    }
    
    /**
     * Obtener fechas disponibles para el calendario
     */
    private function obtenerFechasDisponibles()
    {
        $fechas = EjecucionGlobal::where('nombre', 'ejecuciones_scrapear_ofertas')
            ->selectRaw('DATE(created_at) as fecha')
            ->distinct()
            ->orderBy('fecha', 'desc')
            ->pluck('fecha')
            ->toArray();
        
        return $fechas;
    }
    
    /**
     * Calcular limitaciones de API basadas en las ofertas activas
     */
    private function calcularLimitacionesAPI()
    {
        // Obtener todas las ofertas activas con su frecuencia de actualización
        $ofertasActivas = OfertaProducto::with('tienda')
            ->where('mostrar', 'si')
            ->where('frecuencia_actualizar_precio_minutos', '>', 0)
            ->get();
        
        $peticionesPorTienda = [];
        $totalPeticionesAliExpress = 0;
        $totalPeticionesHTML = 0;
        
        foreach ($ofertasActivas as $oferta) {
            $tiendaNombre = $oferta->tienda->nombre;
            $frecuenciaMinutos = $oferta->frecuencia_actualizar_precio_minutos;
            
            // Calcular peticiones por día (1440 minutos = 24 horas)
            $peticionesPorDia = 1440 / $frecuenciaMinutos;
            $peticionesPorMes = $peticionesPorDia * 30; // Aproximadamente 30 días
            
            if (!isset($peticionesPorTienda[$tiendaNombre])) {
                $peticionesPorTienda[$tiendaNombre] = [
                    'ofertas' => 0,
                    'peticiones_por_dia' => 0,
                    'peticiones_por_mes' => 0
                ];
            }
            
            $peticionesPorTienda[$tiendaNombre]['ofertas']++;
            $peticionesPorTienda[$tiendaNombre]['peticiones_por_dia'] += $peticionesPorDia;
            $peticionesPorTienda[$tiendaNombre]['peticiones_por_mes'] += $peticionesPorMes;
            
            // Clasificar por tipo de API
            if (strtolower($tiendaNombre) === 'aliexpress') {
                $totalPeticionesAliExpress += $peticionesPorMes;
            } else {
                $totalPeticionesHTML += $peticionesPorMes;
            }
        }
        
        // Definir limitaciones de API
        $limitaciones = [
            'aliexpress' => [
                'limite_diario' => 300,
                'limite_hora' => 100,
                'peticiones_por_mes' => round($totalPeticionesAliExpress, 0),
                'peticiones_por_dia' => round($totalPeticionesAliExpress / 30, 1),
                'peticiones_por_hora' => round(($totalPeticionesAliExpress / 30) / 24, 1),
                'por_tienda' => $peticionesPorTienda
            ],
            'html' => [
                'limite_mensual' => 5000,
                'peticiones_por_mes' => round($totalPeticionesHTML, 0),
                'peticiones_por_dia' => round($totalPeticionesHTML / 30, 1),
                'por_tienda' => $peticionesPorTienda
            ]
        ];
        
        return $limitaciones;
    }
}
