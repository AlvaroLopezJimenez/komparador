<?php

namespace App\Http\Controllers\Scraping;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OfertaProducto;
use App\Models\EjecucionGlobal;
use App\Models\Producto;
use Illuminate\Support\Facades\Log;

class ScraperSegundoPlanoController extends ScraperBaseController
{
    /**
     * Ejecutar scraping de ofertas en segundo plano (para cron jobs)
     */
    public function ejecutarScraperOfertasSegundoPlano(Request $request)
    {
        // Verificar token de seguridad
        $token = $request->query('token');
        if (!$token || $token !== env('TOKEN_ACTUALIZAR_PRECIOS')) {
            return response()->json([
                'status' => 'error',
                'message' => 'Token inválido'
            ], 403);
        }

        return $this->procesarScraperOfertas($token);
    }

    /**
     * Ejecutar scraping de ofertas (método principal)
     */
    private function procesarScraperOfertas($token = null)
    {
        // Evitar timeout en ejecuciones largas
        set_time_limit(0);

        $ejecucion = EjecucionGlobal::create([
            'inicio' => now(),
            'nombre' => 'ejecuciones_scrapear_ofertas',
            'log'    => $token ? ['token' => $token] : [],
        ]);

        // 1) Selección de ofertas a procesar
        $ofertas = $this->obtenerOfertasElegibles(50);

        $totalOfertas = $ofertas->count();
        $actualizadas = 0;
        $errores      = 0;
        $log          = [];

        if ($totalOfertas === 0) {
            $ejecucion->update([
                'fin'            => now(),
                'total'          => 0,
                'total_guardado' => 0,
                'total_errores'  => 0,
                'log'            => [],
            ]);

            return response()->json([
                'status'         => 'ok',
                'total_ofertas'  => 0,
                'actualizadas'   => 0,
                'errores'        => 0,
            ]);
        }

        // 2) Procesar ofertas de forma secuencial sin pausas
        foreach ($ofertas as $oferta) {
            try {
                $resultado = $this->procesarOfertaScraper($oferta);
                $log[] = $resultado;

                if (!empty($resultado['success'])) {
                    $actualizadas++;
                } else {
                    $errores++;
                }

            } catch (\Exception $e) {
                $errores++;
                $log[] = [
                    'oferta_id'                 => $oferta->id,
                    'tienda_nombre'             => $oferta->tienda->nombre ?? null,
                    'url'                       => $oferta->url,
                    'variante'                  => $oferta->variante,
                    'precio_anterior'           => $oferta->precio_total,
                    'precio_nuevo'              => null,
                    'success'                   => false,
                    'error'                     => $e->getMessage(),
                    'cambios_detectados'        => false,
                    'url_notificacion_llamada'  => false,
                ];
            }
        }

        $ejecucion->update([
            'fin'            => now(),
            'total'          => $totalOfertas,
            'total_guardado' => $actualizadas,
            'total_errores'  => $errores,
            'log'            => $log,
        ]);

        return response()->json([
            'status'         => 'ok',
            'total_ofertas'  => $totalOfertas,
            'actualizadas'   => $actualizadas,
            'errores'        => $errores,
        ]);
    }




}
