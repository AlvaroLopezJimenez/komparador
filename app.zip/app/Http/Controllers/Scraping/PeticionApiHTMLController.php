<?php

namespace App\Http\Controllers\Scraping;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PeticionApiHTMLController extends Controller
{
    private $apiKey = 'e7641b483cmshcac145d48569584p1de82ejsn452206de102d';
    private $apiUrl = 'https://scrapingant.p.rapidapi.com/get';

    /**
     * Obtener HTML de una URL usando la API de scraping
     */
    public function obtenerHTML($url)
    {
        try {
            $response = Http::timeout(60)->withHeaders([
                'x-rapidapi-host' => 'scrapingant.p.rapidapi.com',
                'x-rapidapi-key' => $this->apiKey
            ])->get($this->apiUrl, [
                'url' => $url,
                'proxy_country' => 'ES',
                'response_format' => 'html'
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'html' => $response->body()
                ];
            } else {
                return [
                    'success' => false,
                    'error' => 'Error en la API: ' . $response->status() . ' - ' . $response->body()
                ];
            }

        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => 'Error de conexión: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Método alternativo usando cURL (por si acaso)
     */
    public function obtenerHTMLCurl($url)
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $this->apiUrl . "?url=" . urlencode($url) . "&proxy_country=ES&response_format=html",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => [
                "x-rapidapi-host: scrapingant.p.rapidapi.com",
                "x-rapidapi-key: " . $this->apiKey
            ],
        ]);

        $response = curl_exec($curl);
        $err = curl_error($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        if ($err) {
            return [
                'success' => false,
                'error' => "cURL Error: " . $err
            ];
        }

        if ($httpCode !== 200) {
            return [
                'success' => false,
                'error' => "HTTP Error: " . $httpCode . " - " . $response
            ];
        }

        return [
            'success' => true,
            'html' => $response
        ];
    }
}
