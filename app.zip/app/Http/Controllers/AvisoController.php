<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tienda;
use App\Models\Categoria;
use App\Models\ComisionCategoriaTienda;

class AvisoController extends Controller
{
    public function index()
    {
        $hoy = now()->startOfDay();

        $avisosProductos = \App\Models\Producto::whereNotNull('aviso')
            ->whereDate('aviso', '<=', $hoy)
            ->select('id', 'nombre', 'aviso', 'anotaciones_internas')
            ->get()
            ->map(fn($p) => [
                'tipo' => 'producto',
                'id' => $p->id,
                'nombre' => $p->nombre,
                'aviso' => $p->aviso->format('d/m/Y'),
                'anotaciones' => $p->anotaciones_internas,
                'editar' => route('admin.productos.edit', $p->id),
                'eliminar' => route('admin.avisos.eliminar', ['tipo' => 'producto', 'id' => $p->id]),
            ]);

        $avisosOfertas = \App\Models\OfertaProducto::whereNotNull('aviso')
            ->whereDate('aviso', '<=', $hoy)
            ->with('producto', 'tienda')
            ->get()
            ->map(fn($o) => [
                'tipo' => 'oferta',
                'id' => $o->id,
                'nombre' => $o->producto->nombre . ' - ' . $o->tienda->nombre,
                'aviso' => $o->aviso ? \Carbon\Carbon::parse($o->aviso)->format('d/m/Y') : '',
                'anotaciones' => $o->anotaciones_internas,
                'editar' => route('admin.ofertas.edit', $o->id),
                'eliminar' => route('admin.avisos.eliminar', ['tipo' => 'oferta', 'id' => $o->id]),
            ]);

        $avisosTiendas = \App\Models\Tienda::whereNotNull('aviso')
            ->whereDate('aviso', '<=', $hoy)
            ->get()
            ->map(fn($t) => [
                'tipo' => 'tienda',
                'id' => $t->id,
                'nombre' => $t->nombre,
                'aviso' => $t->aviso ? \Carbon\Carbon::parse($t->aviso)->format('d/m/Y') : '',
                'anotaciones' => $t->anotaciones_internas,
                'editar' => route('admin.tiendas.edit', $t->id),
                'eliminar' => route('admin.avisos.eliminar', ['tipo' => 'tienda', 'id' => $t->id]),
            ]);

            //Comprueba si cada una de las tiendas tiene un valor en cada categoria
        $avisosTiendasSinComision = Tienda::all()->filter(function ($tienda) {
    $categoriaIds = Categoria::pluck('id')->toArray();
    $comisionadas = ComisionCategoriaTienda::where('tienda_id', $tienda->id)
        ->pluck('categoria_id')
        ->toArray();
    // Si hay al menos una categoría que no tenga comisión asignada
    return count(array_diff($categoriaIds, $comisionadas)) > 0;
})->map(function ($t) {
    return [
        'tipo' => 'tienda',
        'id' => $t->id,
        'nombre' => $t->nombre . ' (faltan comisiones)',
        'aviso' => '',
        'anotaciones' => $t->anotaciones_internas,
        'editar' => route('admin.tiendas.edit', $t->id),
        'eliminar' => route('admin.avisos.eliminar', ['tipo' => 'tienda', 'id' => $t->id]),
    ];
});

        $avisos = collect([
    ...$avisosProductos,
    ...$avisosOfertas,
    ...$avisosTiendas,
    ...$avisosTiendasSinComision, // <- ESTO FALTABA
])->sortBy('aviso');

        return view('admin.avisos.index', compact('avisos'));
    }

    public function eliminar(Request $request)
    {
        $tipo = $request->route('tipo');
        $id = $request->route('id');

        $modelos = [
            'producto' => \App\Models\Producto::class,
            'oferta' => \App\Models\OfertaProducto::class,
            'tienda' => \App\Models\Tienda::class,
        ];

        if (!isset($modelos[$tipo])) {
            abort(404, 'Tipo de aviso no válido.');
        }

        $modelo = $modelos[$tipo]::findOrFail($id);
        $modelo->update(['aviso' => null]);

        return redirect()->route('admin.avisos.index')->with('success', 'Aviso eliminado correctamente.');
    }
}
