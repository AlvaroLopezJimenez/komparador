<?php

namespace App\Http\Controllers;

use App\Models\Producto;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Carbon\Carbon;
use App\Models\HistoricoPrecioProducto;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\JsonResponse;
use App\Models\Categoria;
use App\Models\PalabraClaveProducto;
use Illuminate\Validation\ValidationException;


class ProductoController extends Controller
{
    public function index(Request $request)
    {
        $busqueda = $request->input('buscar');

        $query = Producto::with('categoria')
            ->withCount([
                'ofertas',
                'ofertas as ofertas_visibles_count' => fn($q) => $q->where('mostrar', 'si'),
                'ofertas as clicks_ultimos_30_dias' => fn($q) =>
                $q->join('clicks', 'clicks.oferta_id', '=', 'ofertas_producto.id')
                    ->where('clicks.created_at', '>=', now()->subDays(30))
            ]);

        if ($busqueda) {
            $query->where(function ($q) use ($busqueda) {
                $q->where('nombre', 'like', '%' . $busqueda . '%')
                    ->orWhere('marca', 'like', '%' . $busqueda . '%')
                    ->orWhere('modelo', 'like', '%' . $busqueda . '%')
                    ->orWhere('talla', 'like', '%' . $busqueda . '%');
            });
        }

        $productos = $query->latest()->paginate(10);

        return view('admin.productos.index', compact('productos', 'busqueda'));
    }



    public function create()
    {
        $categoriasRaiz = Categoria::with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
        ->whereNull('parent_id')
        ->orderBy('nombre')
        ->get();

        // Cargar subcategorías de forma recursiva
        $this->cargarSubcategoriasRecursivamente($categoriasRaiz);

        return view('admin.productos.formulario', [
            'producto' => null,
            'categoriasRaiz' => $categoriasRaiz,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string',
            'slug' => 'required|string|unique:productos,slug',
            'marca' => 'required|string',
            'modelo' => 'required|string',
            'talla' => 'nullable|string',
            'unidadDeMedida' => 'required|in:total,unidad,kilos,litros',
            'precio' => 'nullable|numeric',
            'imagen_grande' => 'nullable|string',
            'imagen_pequena' => 'nullable|string',
            'imagen_grande_manual' => 'nullable|string',
            'imagen_pequena_manual' => 'nullable|string',
            'caracteristicas' => 'nullable|string',
            'pros' => 'nullable|array',
            'contras' => 'nullable|array',
            'faq' => 'nullable|array',
            'keys_relacionados' => 'nullable|array',
            'titulo' => 'required|string',
            'subtitulo' => 'nullable|string',
            'descripcion_corta' => 'nullable|string',
            'descripcion_larga' => 'nullable|string',
            'meta_titulo' => 'nullable|string',
            'meta_description' => 'nullable|string',
            'categoria_id' => 'required|exists:categorias,id',
            'obsoleto' => 'required|in:si,no',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        // Validar que al menos una forma de imagen esté proporcionada
        if (empty($validated['imagen_grande']) && empty($validated['imagen_grande_manual'])) {
            throw ValidationException::withMessages([
                'imagen_grande' => 'Debe proporcionar una imagen grande, ya sea subiendo un archivo o especificando la ruta manualmente.'
            ]);
        }

        if (empty($validated['imagen_pequena']) && empty($validated['imagen_pequena_manual'])) {
            throw ValidationException::withMessages([
                'imagen_pequena' => 'Debe proporcionar una imagen pequeña, ya sea subiendo un archivo o especificando la ruta manualmente.'
            ]);
        }

        // Usar la imagen de upload si está disponible, sino usar la manual
        $imagenGrande = $validated['imagen_grande'] ?: $validated['imagen_grande_manual'];
        $imagenPequena = $validated['imagen_pequena'] ?: $validated['imagen_pequena_manual'];

        $avisoFecha = null;

        if ($request->filled('eliminar_aviso')) {
            $avisoFecha = null;
        } elseif ($request->filled('aviso_cantidad') && $request->filled('aviso_unidad')) {
            $avisoFecha = now()->add($request->input('aviso_unidad'), (int)$request->input('aviso_cantidad'))->setTime(0, 1);
        }

        $caracteristicas = array_filter(array_map('trim', explode("\n", $validated['caracteristicas'] ?? '')));

        $producto = Producto::create([
            'nombre' => $validated['nombre'],
            'slug' => $validated['slug'],
            'marca' => $validated['marca'],
            'modelo' => $validated['modelo'],
            'talla' => $validated['talla'],
            'unidadDeMedida' => $validated['unidadDeMedida'],
            'precio' => $validated['precio'],
            'imagen_grande' => $imagenGrande,
            'imagen_pequena' => $imagenPequena,
            'titulo' => $validated['titulo'],
            'subtitulo' => $validated['subtitulo'],
            'descripcion_corta' => $validated['descripcion_corta'],
            'descripcion_larga' => $validated['descripcion_larga'],
            'caracteristicas' => $caracteristicas,
            'pros' => $validated['pros'] ?? [],
            'contras' => $validated['contras'] ?? [],
            'faq' => $validated['faq'] ?? [],
            'keys_relacionados' => $validated['keys_relacionados'] ?? [],
            'categoria_id' => $validated['categoria_id'],
            'meta_titulo' => $validated['meta_titulo'],
            'meta_description' => $validated['meta_description'],
            'obsoleto' => $validated['obsoleto'],
            'anotaciones_internas' => $validated['anotaciones_internas'] ?? null,
            'aviso' => $avisoFecha,
        ]);

        foreach ($request->input('palabras_clave', []) as $clave) {
            if (!empty($clave['palabra']) && !empty($clave['codigo'])) {
                PalabraClaveProducto::create([
                    'producto_id' => $producto->id,
                    'palabra' => $clave['palabra'],
                    'codigo' => $clave['codigo'],
                    'activa' => $clave['activa'] ?? 'si',
                ]);
            }
        }


        return redirect()->route('admin.productos.index')->with('success', 'Producto guardado correctamente.');
    }


    public function edit(Producto $producto)
    {
        $categoriasRaiz = Categoria::with(['subcategorias' => function ($query) {
            $query->orderBy('nombre');
        }])
        ->whereNull('parent_id')
        ->orderBy('nombre')
        ->get();

        // Cargar subcategorías de forma recursiva
        $this->cargarSubcategoriasRecursivamente($categoriasRaiz);

        return view('admin.productos.formulario', compact('producto', 'categoriasRaiz'));
    }


    public function update(Request $request, Producto $producto)
    {
        $validated = $request->validate([
            'nombre' => 'required|string',
            'slug' => 'required|string|unique:productos,slug,' . $producto->id,
            'marca' => 'required|string',
            'modelo' => 'required|string',
            'talla' => 'nullable|string',
            'unidadDeMedida' => 'required|in:total,unidad,kilos,litros',
            'precio' => 'nullable|numeric',
            'imagen_grande' => 'nullable|string',
            'imagen_pequena' => 'nullable|string',
            'imagen_grande_manual' => 'nullable|string',
            'imagen_pequena_manual' => 'nullable|string',
            'caracteristicas' => 'nullable|string',
            'pros' => 'nullable|array',
            'contras' => 'nullable|array',
            'faq' => 'nullable|array',
            'keys_relacionados' => 'nullable|array',
            'titulo' => 'required|string',
            'subtitulo' => 'nullable|string',
            'descripcion_corta' => 'nullable|string',
            'descripcion_larga' => 'nullable|string',
            'meta_titulo' => 'nullable|string',
            'meta_description' => 'nullable|string',
            'categoria_id' => 'required|exists:categorias,id',
            'obsoleto' => 'required|in:si,no',
            'anotaciones_internas' => 'nullable|string',
            'aviso' => 'nullable|date',
        ]);

        // Validar que al menos una forma de imagen esté proporcionada
        if (empty($validated['imagen_grande']) && empty($validated['imagen_grande_manual'])) {
            throw ValidationException::withMessages([
                'imagen_grande' => 'Debe proporcionar una imagen grande, ya sea subiendo un archivo o especificando la ruta manualmente.'
            ]);
        }

        if (empty($validated['imagen_pequena']) && empty($validated['imagen_pequena_manual'])) {
            throw ValidationException::withMessages([
                'imagen_pequena' => 'Debe proporcionar una imagen pequeña, ya sea subiendo un archivo o especificando la ruta manualmente.'
            ]);
        }

        // Usar la imagen de upload si está disponible, sino usar la manual
        $imagenGrande = $validated['imagen_grande'] ?: $validated['imagen_grande_manual'];
        $imagenPequena = $validated['imagen_pequena'] ?: $validated['imagen_pequena_manual'];

        $avisoFecha = $producto->aviso; // valor anterior por defecto

        if ($request->filled('eliminar_aviso')) {
            $avisoFecha = null;
        } elseif ($request->filled('aviso_cantidad') && $request->filled('aviso_unidad')) {
            $avisoFecha = now()->add($request->input('aviso_unidad'), (int)$request->input('aviso_cantidad'))->setTime(0, 1);
        }


        $caracteristicas = array_filter(array_map('trim', explode("\n", $validated['caracteristicas'] ?? '')));

        $producto->update([
            'nombre' => $validated['nombre'],
            'slug' => $validated['slug'],
            'marca' => $validated['marca'],
            'modelo' => $validated['modelo'],
            'talla' => $validated['talla'],
            'unidadDeMedida' => $validated['unidadDeMedida'],
            'precio' => $validated['precio'],
            'imagen_grande' => $imagenGrande,
            'imagen_pequena' => $imagenPequena,
            'titulo' => $validated['titulo'],
            'subtitulo' => $validated['subtitulo'],
            'descripcion_corta' => $validated['descripcion_corta'],
            'descripcion_larga' => $validated['descripcion_larga'],
            'caracteristicas' => $caracteristicas,
            'pros' => $validated['pros'] ?? [],
            'contras' => $validated['contras'] ?? [],
            'faq' => $validated['faq'] ?? [],
            'keys_relacionados' => $validated['keys_relacionados'] ?? [],
            'categoria_id' => $validated['categoria_id'],
            'meta_titulo' => $validated['meta_titulo'],
            'meta_description' => $validated['meta_description'],
            'obsoleto' => $validated['obsoleto'],
            'anotaciones_internas' => $validated['anotaciones_internas'] ?? null,
            'aviso' => $avisoFecha,
        ]);

        $clavesForm = $request->input('palabras_clave', []);
        $clavesExistentes = $producto->palabrasClave()->get()->keyBy('codigo');

        foreach ($clavesForm as $clave) {
            if (empty($clave['palabra']) || empty($clave['codigo'])) continue;

            $registro = $clavesExistentes->get($clave['codigo']);

            if ($registro) {
                $registro->update([
                    'palabra' => $clave['palabra'],
                    'activa' => $clave['activa'] ?? 'si',
                ]);
            } else {
                PalabraClaveProducto::create([
                    'producto_id' => $producto->id,
                    'palabra' => $clave['palabra'],
                    'codigo' => $clave['codigo'],
                    'activa' => $clave['activa'] ?? 'si',
                ]);
            }
        }

        return redirect()->route('admin.productos.index')->with('success', 'Producto actualizado correctamente.');
    }


    public function destroy(Producto $producto)
    {
        $producto->delete();
        return redirect()->route('admin.productos.index')->with('success', 'Producto eliminado correctamente.');
    }

    public function datosHistorico(Request $request, Producto $producto)
    {
        $dias = (int) $request->query('dias', 90);
        $desde = Carbon::today()->subDays($dias - 1); // incluye hoy

        // Obtiene todos los registros desde la fecha indicada
        $historico = HistoricoPrecioProducto::where('producto_id', $producto->id)
            ->where('fecha', '>=', $desde)
            ->orderBy('fecha')
            ->get()
            ->keyBy('fecha');

        $labels = [];
        $valores = [];

        for ($i = 0; $i < $dias; $i++) {
            $fecha = Carbon::today()->subDays($dias - 1 - $i)->toDateString();
            $labels[] = Carbon::parse($fecha)->format('d/m');
            $valores[] = isset($historico[$fecha]) ? (float) $historico[$fecha]->precio_minimo : 0;
        }

        return response()->json([
            'labels' => $labels,
            'valores' => $valores,
        ]);
    }


    public function estadisticas(Producto $producto)
    {
        return view('admin.productos.estadisticas', compact('producto'));
    }

    // Guardar el precio del dia en el historial de todos los productos
    public function indexEjecucionesHistorico(Request $request)
    {
        $busqueda = $request->input('buscar');

        $query = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_productos');

        if ($busqueda) {
            $query->where(function($q) use ($busqueda) {
                $q->whereDate('inicio', 'like', "%$busqueda%")
                  ->orWhereDate('fin', 'like', "%$busqueda%");
            });
        }

        $ejecuciones = $query->orderByDesc('inicio')->paginate(15)->withQueryString();
        $totalEjecuciones = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_productos')->count();

        return view('admin.productos.listadoEjecucionesGuardadoPrecios', compact('ejecuciones', 'busqueda', 'totalEjecuciones'));
    }

    //Eliminar x cantidad de registros de actualizaciones de precios de productos
    public function eliminarAntiguas(Request $request)
    {
        $cantidad = $request->input('cantidad');

        \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_productos')
            ->orderBy('inicio')
            ->limit($cantidad)
            ->delete();

        return redirect()->back()->with('success', "$cantidad ejecuciones eliminadas.");
    }

    //Eliminar solo un registro de actualizaciones de precios de productos
    public function eliminar($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_historico_precios_productos')
            ->findOrFail($id);
        $ejecucion->delete();

        return redirect()->back()->with('success', 'Ejecución eliminada.');
    }

    //MODIFICAR HISTORIAL DE PRECIO DE PRODUCTOS
    public function historialMes(Request $request, Producto $producto)
    {
        $mes = (int) $request->query('mes');
        $anio = (int) $request->query('anio');

        $desde = Carbon::createFromDate($anio, $mes, 1);
        $hasta = $desde->copy()->endOfMonth();

        $registros = HistoricoPrecioProducto::where('producto_id', $producto->id)
            ->whereBetween('fecha', [$desde->toDateString(), $hasta->toDateString()])
            ->get();

        $resultado = [];
        foreach ($registros as $registro) {
            $fechaFormateada = Carbon::parse($registro['fecha'])->format('Y-m-d');
            $resultado[$fechaFormateada] = (float) $registro['precio_minimo'];
        }

        return response()->json($resultado);
    }

    public function historialGuardar(Request $request, Producto $producto)
    {
        $cambios = $request->input('cambios', []);

        foreach ($cambios as $fecha => $precio) {
            if ($precio === null || $precio === '') continue;

            HistoricoPrecioProducto::updateOrCreate(
                ['producto_id' => $producto->id, 'fecha' => $fecha],
                ['precio_minimo' => $precio]
            );
        }

        return response()->json(['success' => true]);
    }

    //BUSCAR PRODUCTOS RELACIONADOS CON LAS PALABRAS CLAVES QUE TENGO ESCRITAS EN EL FORMULARIO DE PRODUCTO
    public function buscarRelacionados(Request $request)
    {
        $keywords = $request->input('keywords', []);
        $productoId = $request->input('producto_id');

        $productos = Producto::query()
            ->where(function ($q) use ($keywords) {
                foreach ($keywords as $palabra) {
                    $q->orWhere('marca', 'like', "%$palabra%")
                        ->orWhere('modelo', 'like', "%$palabra%")
                        ->orWhere('talla', 'like', "%$palabra%");
                }
            })
            ->when($productoId, fn($q) => $q->where('id', '!=', $productoId))
            ->count();

        return response()->json(['total' => $productos]);
    }

    //GRAFICA ESTADISITICAS PARA VER LOS CLICKS Y PODER MARCAR SI 30,90,180 O UN AÑO
    public function datosClicks(Request $request, Producto $producto)
    {
        $dias = (int) $request->query('dias', 90);
        $desde = now()->subDays($dias - 1)->startOfDay();

        $clicksPorDia = DB::table('clicks')
            ->join('ofertas_producto', 'clicks.oferta_id', '=', 'ofertas_producto.id')
            ->where('ofertas_producto.producto_id', $producto->id)
            ->where('clicks.created_at', '>=', $desde)
            ->selectRaw('DATE(clicks.created_at) as fecha, COUNT(*) as total')
            ->groupBy('fecha')
            ->orderBy('fecha')
            ->get()
            ->keyBy('fecha');

        $labels = [];
        $valores = [];

        for ($i = 0; $i < $dias; $i++) {
            $fecha = now()->subDays($dias - 1 - $i)->toDateString();
            $labels[] = \Carbon\Carbon::parse($fecha)->format('d/m');
            $valores[] = isset($clicksPorDia[$fecha]) ? $clicksPorDia[$fecha]->total : 0;
        }

        return response()->json([
            'labels' => $labels,
            'valores' => $valores,
        ]);
    }

    // Actualizar clicks de todos los productos
    public function actualizarClicks(Request $request)
    {
        // Crear ejecución en la tabla global
        $ejecucion = \App\Models\EjecucionGlobal::create([
            'inicio' => now(),
            'nombre' => 'ejecuciones_clicks_producto',
            'log' => [],
        ]);

        $productos = Producto::all();
        $actualizados = 0;
        $errores = 0;
        $log = [];

        foreach ($productos as $producto) {
            try {
                // Contar clicks del último mes para este producto
                $clicksUltimoMes = \App\Models\Click::whereHas('oferta', function($query) use ($producto) {
                    $query->where('producto_id', $producto->id);
                })
                ->where('created_at', '>=', now()->subMonth())
                ->count();

                // Actualizar el campo clicks del producto
                $producto->update(['clicks' => $clicksUltimoMes]);

                $actualizados++;
                $log[] = [
                    'producto_id' => $producto->id,
                    'nombre' => $producto->nombre,
                    'clicks' => $clicksUltimoMes,
                    'status' => 'actualizado'
                ];
            } catch (\Throwable $e) {
                $errores++;
                $log[] = [
                    'producto_id' => $producto->id,
                    'nombre' => $producto->nombre,
                    'error' => $e->getMessage(),
                    'status' => 'error'
                ];
            }
        }

        $ejecucion->update([
            'fin' => now(),
            'total' => count($productos),
            'total_guardado' => $actualizados,
            'total_errores' => $errores,
            'log' => $log,
        ]);

        return response()->json([
            'status' => 'ok',
            'actualizados' => $actualizados,
            'errores' => $errores,
            'ejecucion_id' => $ejecucion->id
        ]);
    }

    // Vista para ejecutar la actualización de clicks
    public function ejecucionActualizarClicks()
    {
        return view('admin.productos.ejecucionActualizarClicks');
    }

    // Listar ejecuciones de actualizaciones de clicks de productos
    public function indexEjecucionesClicks()
    {
        $ejecuciones = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_clicks_producto')
            ->orderBy('created_at', 'desc')
            ->paginate(10);
        return view('admin.productos.ejecucionesClicks', compact('ejecuciones'));
    }

    // Ver detalles de una ejecución específica
    public function obtenerJsonEjecucionClicks($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_clicks_producto')
            ->findOrFail($id);
        return response()->json($ejecucion);
    }

    // Eliminar una ejecución específica de actualizaciones de clicks
    public function eliminarEjecucionClicks($id)
    {
        $ejecucion = \App\Models\EjecucionGlobal::where('nombre', 'ejecuciones_clicks_producto')
            ->findOrFail($id);
        $ejecucion->delete();

        return redirect()->back()->with('success', 'Ejecución eliminada correctamente.');
    }

    public function generarContenido(Request $request)
    {
        // Log temporal para debug
        \Log::info('Método generarContenido llamado', [
            'user' => auth()->user() ? auth()->user()->id : 'no autenticado',
            'request_data' => $request->all()
        ]);
        
        try {
            $request->validate([
                'nombre' => 'required|string',
                'marca' => 'required|string',
                'modelo' => 'required|string',
                'talla' => 'required|string',
                'prompt' => 'required|string'
            ]);

            $nombre = $request->input('nombre');
            $marca = $request->input('marca');
            $modelo = $request->input('modelo');
            $talla = $request->input('talla');
            $prompt = $request->input('prompt');

            // Configurar la petición a ChatGPT
            $apiKey = config('services.openai.api_key');
            if (!$apiKey) {
                // Para pruebas, devolver datos de ejemplo
                $data = [
                    'titulo' => 'Comparador de ' . $nombre,
                    'subtitulo' => 'Descripción corta del producto ' . $marca . ' ' . $modelo,
                    'descripcion_corta' => 'Descripción más detallada del producto ' . $nombre . ' de la marca ' . $marca,
                    'descripcion_larga' => 'Descripción larga con información detallada sobre el producto ' . $nombre,
                    'caracteristicas' => "Característica 1\nCaracterística 2\nCaracterística 3\nCaracterística 4\nCaracterística 5\nCaracterística 6",
                    'meta_titulo' => 'Meta título para ' . $nombre,
                    'meta_descripcion' => 'Meta descripción para ' . $nombre,
                    'pros' => ['Pro 1', 'Pro 2', 'Pro 3', 'Pro 4', 'Pro 5'],
                    'contras' => ['Contra 1', 'Contra 2', 'Contra 3'],
                    'preguntas_frecuentes' => [
                        ['pregunta' => 'Pregunta 1', 'respuesta' => 'Respuesta 1'],
                        ['pregunta' => 'Pregunta 2', 'respuesta' => 'Respuesta 2'],
                        ['pregunta' => 'Pregunta 3', 'respuesta' => 'Respuesta 3']
                    ]
                ];
                return response()->json($data);
            }

            try {
                $client = \OpenAI::client($apiKey);
            } catch (\Exception $e) {
                \Log::error('Error al obtener cliente OpenAI: ' . $e->getMessage());
                // Fallback a datos de ejemplo si hay error con el cliente
                $data = [
                    'titulo' => 'Comparador de ' . $nombre,
                    'subtitulo' => 'Descripción corta del producto ' . $marca . ' ' . $modelo,
                    'descripcion_corta' => 'Descripción más detallada del producto ' . $nombre . ' de la marca ' . $marca,
                    'descripcion_larga' => 'Descripción larga con información detallada sobre el producto ' . $nombre,
                    'caracteristicas' => "Característica 1\nCaracterística 2\nCaracterística 3\nCaracterística 4\nCaracterística 5\nCaracterística 6",
                    'meta_titulo' => 'Meta título para ' . $nombre,
                    'meta_descripcion' => 'Meta descripción para ' . $nombre,
                    'pros' => ['Pro 1', 'Pro 2', 'Pro 3', 'Pro 4', 'Pro 5'],
                    'contras' => ['Contra 1', 'Contra 2', 'Contra 3'],
                    'preguntas_frecuentes' => [
                        ['pregunta' => 'Pregunta 1', 'respuesta' => 'Respuesta 1'],
                        ['pregunta' => 'Pregunta 2', 'respuesta' => 'Respuesta 2'],
                        ['pregunta' => 'Pregunta 3', 'respuesta' => 'Respuesta 3']
                    ]
                ];
                return response()->json($data);
            }

            $response = $client->chat()->create([
                'model' => 'gpt-3.5-turbo',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ],
                'temperature' => 0.7,
                'max_tokens' => 2000
            ]);

            $content = $response->choices[0]->message->content;
            
            // Log de la respuesta para debug
            \Log::info('Respuesta de ChatGPT:', ['content' => $content]);

            // Extraer JSON de la respuesta (puede tener texto antes o después)
            $jsonMatch = preg_match('/\{.*\}/s', $content, $matches);
            
            if (!$jsonMatch) {
                \Log::error('No se pudo extraer JSON de la respuesta de ChatGPT', ['content' => $content]);
                return response()->json(['error' => 'No se pudo extraer JSON válido de la respuesta'], 500);
            }

            $jsonString = $matches[0];
            $data = json_decode($jsonString, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return response()->json(['error' => 'JSON inválido en la respuesta'], 500);
            }

            // Procesar las características (convertir de string a array)
            if (isset($data['caracteristicas']) && is_string($data['caracteristicas'])) {
                $caracteristicas = array_map('trim', explode(',', $data['caracteristicas']));
                $data['caracteristicas'] = implode("\n", $caracteristicas);
            }

            // Procesar pros (convertir de string a array)
            if (isset($data['pros']) && is_string($data['pros'])) {
                $pros = array_map('trim', explode(',', $data['pros']));
                $data['pros'] = $pros;
            }

            // Procesar contras (convertir de string a array)
            if (isset($data['contras']) && is_string($data['contras'])) {
                $contras = array_map('trim', explode(',', $data['contras']));
                $data['contras'] = $contras;
            }

            return response()->json($data);

        } catch (\Illuminate\Validation\ValidationException $e) {
            \Log::error('Error de validación en generarContenido: ' . json_encode($e->errors()));
            return response()->json(['error' => 'Datos de entrada inválidos: ' . implode(', ', $e->errors())], 422);
        } catch (\Exception $e) {
            \Log::error('Error al generar contenido con ChatGPT: ' . $e->getMessage());
            return response()->json(['error' => 'Error al generar contenido: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Carga subcategorías de forma recursiva
     */
    private function cargarSubcategoriasRecursivamente($categorias)
    {
        foreach ($categorias as $categoria) {
            $categoria->load(['subcategorias' => function ($query) {
                $query->orderBy('nombre');
            }]);
            
            if ($categoria->subcategorias->count() > 0) {
                $this->cargarSubcategoriasRecursivamente($categoria->subcategorias);
            }
        }
    }
}
