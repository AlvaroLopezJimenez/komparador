<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Compara precios de pañales, toallitas y productos para bebé en un solo lugar. Encuentra las mejores ofertas actualizadas.">
<meta property="og:title" content="CholloPañales - Compara precios de productos de bebé">
<meta property="og:description" content="Encuentra los mejores precios en pañales, toallitas, cremas y más.">
<meta property="og:image" content="{{ asset('images/logo.png') }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="CholloPañales">
<meta name="twitter:description" content="Compara precios y ahorra en productos para bebé.">
<meta name="twitter:image" content="{{ asset('images/logo.png') }}">

    <title>Pañales al mejor precio y ofertas en productos de bebé - CholloPañales</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    {{-- HEADER DESDE LA RUTA COMPONENTS/HEADER --}}
    <x-header />
    {{-- BARRA DE CATEGORÍAS --}}
    <div>
        <div class="max-w-7xl mx-auto px-6 py-1 bg-pink-100 border-b border-pink-200">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2 overflow-x-auto pb-0 scrollbar-hide" style="-webkit-overflow-scrolling: touch;">
                    {{-- Categorías manuales --}}
                    <a href="{{ route('categoria.show', 'pañales') }}" class="flex flex-col items-center space-y-1 min-w-[70px] flex-shrink-0">
                        <div class="w-9 h-9 bg-pink-200 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-pink-600 width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                            </svg>
                        </div>
                        <span class="text-base font-semibold text-pink-700 text-center">Pañales</span>
                    </a>
                    
                    <a href="{{ route('categoria.show', 'toallitas') }}" class="flex flex-col items-center space-y-1 min-w-[70px] flex-shrink-0">
                        <div class="w-9 h-9 bg-blue-200 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <span class="text-base font-semibold text-blue-700 text-center">Toallitas</span>
                    </a>
                    
                    <a href="{{ route('categoria.show', 'cremas') }}" class="flex flex-col items-center space-y-1 min-w-[70px] flex-shrink-0">
                        <div class="w-9 h-9 bg-green-200 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>
                            </svg>
                        </div>
                        <span class="text-base font-semibold text-green-700 text-center">Cremas</span>
                    </a>
                    
                    <a href="{{ route('categoria.show', 'juguetes') }}" class="flex flex-col items-center space-y-1 min-w-[70px] flex-shrink-0">
                        <div class="w-9 h-9 bg-yellow-200 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <span class="text-base font-semibold text-yellow-700 text-center">Juguetes</span>
                    </a>
                    
                    <a href="{{ route('categoria.show', 'alimentacion') }}" class="flex flex-col items-center space-y-1 min-w-[70px] flex-shrink-0">
                        <div class="w-9 h-9 bg-orange-200 rounded-full flex items-center justify-center">
                            <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 01-2 2H9a2 2 0 01-2-2v-6m6 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"></path>
                            </svg>
                        </div>
                        <span class="text-base font-semibold text-orange-700 text-center">Alimentación</span>
                    </a>
                </div>
                
                {{-- Botón Ver Todas en móvil y escritorio, estilos diferenciados --}}
                <a href="{{ route('categorias.todas') }}"
                   class="flex items-center justify-center bg-pink-500 hover:bg-pink-600 text-white rounded-full transition-colors flex-shrink-0 ml-2
                   text-xs font-semibold min-w-[60px] px-2 py-1 sm:hidden"
                >
                    Ver todas
                    <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </a>
                <a href="{{ route('categorias.todas') }}"
                   class="hidden sm:flex items-center justify-center bg-pink-500 hover:bg-pink-600 text-white rounded-full transition-colors flex-shrink-0 ml-2
                   text-sm font-semibold min-w-[90px] px-4 py-2"
                >
                    Ver todas
                    <svg class="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </a>
            </div>
        </div>
    </div>

    {{-- CONTENIDO PRINCIPAL --}}
    <main class="max-w-7xl mx-auto px-6 py-2 rounded-xl bg-gray-100">

        {{-- PRODUCTOS TOP --}}
        @if(isset($productosTop) && $productosTop->count() > 0)
        <section class="mb-4">
            <h1 class="text-3xl font-bold mb-6">Comparador de precios de pañales y productos para bebé</h1>

            <div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
                @foreach($productosTop as $producto)
                <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}"
                   class="group flex flex-col items-center bg-white rounded-xl shadow-md transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer p-4">
                    <div class="w-full flex justify-center mb-3">
                        @if($producto->imagen_pequena)
                            <img loading="lazy" src="{{ asset('images/' .$producto->imagen_pequena) }}"
                                 alt="{{ $producto->nombre }}"
                                 class="w-32 h-32 object-contain rounded-lg shadow-sm transition-all duration-300 group-hover:shadow-lg bg-gray-100">
                        @else
                            <div class="w-32 h-32 flex items-center justify-center rounded-lg bg-gradient-to-br from-blue-100 to-blue-200">
                                <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                        @endif
                    </div>
                    <p class="font-semibold text-gray-700 text-center text-sm mb-1 line-clamp-2">{{ $producto->nombre }}</p>
<p class="text-center mb-1">
    <span class="text-xs text-gray-500">Desde:</span>
<span class="text-xl font-bold text-pink-600">{{ number_format($producto->precio, 2) }}€
    @if($producto->unidadDeMedida === 'unidad')
        <span class="text-xs text-gray-500">/Und.</span>
    @elseif($producto->unidadDeMedida === 'kilos')
        <span class="text-xs text-gray-500">/kg.</span>
    @elseif($producto->unidadDeMedida === 'litros')
        <span class="text-xs text-gray-500">/L.</span>
    @endif
</span>
</p>
</a>
                @endforeach
            </div>
        </section>
        @endif

        {{-- CARRUSEL DE CATEGORÍAS TOP --}}
        @if(isset($categoriasTop) && $categoriasTop->count() > 0)
<section class="w-full bg-pink-50 py-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Categorías Más Visitadas</h2>

        {{-- Flecha izquierda --}}
        <button type="button"
                id="flechaIzquierda"
                class="absolute left-0 top-[60%] -translate-y-1/2 z-10 bg-white hover:bg-pink-100 text-pink-600 rounded-full p-2 shadow transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
        </button>

        {{-- Flecha derecha --}}
        <button type="button"
                id="flechaDerecha"
                class="absolute right-0 top-[60%] -translate-y-1/2 z-10 bg-white hover:bg-pink-100 text-pink-600 rounded-full p-2 shadow transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
            </svg>
        </button>

        {{-- Carrusel --}}
        <div class="relative">
            <div id="carouselCategorias"
                 class="flex gap-4 overflow-x-auto scrollbar-hide scroll-smooth px-1">
                @foreach($categoriasTop as $categoria)
                <a href="{{ 'categoria/' . $categoria->slug }}"
                   class="flex-none w-28 sm:w-32 md:w-36 bg-white rounded-xl shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 p-4 text-center">
                    <div class="w-16 h-16 mx-auto mb-3">
                        @if($categoria->imagen)
                            <img loading="lazy" src="{{ asset('images/' . $categoria->imagen) }}"
                                 alt="{{ $categoria->nombre }}"
                                 class="w-full h-full object-contain rounded-md bg-gray-100">
                        @else
                            <div class="w-full h-full flex items-center justify-center rounded-md bg-gradient-to-br from-pink-100 to-pink-200">
                                <svg class="w-8 h-8 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                                </svg>
                            </div>
                        @endif
                    </div>
                    <span class="text-base font-semibold text-gray-800 leading-snug">{{ $categoria->nombre }}</span>
                </a>
                @endforeach
            </div>
        </div>
    </div>
</section>

@endif

{{-- SECCIÓN PRECIOS HOT --}}
        @if(isset($preciosHot) && $preciosHot && count($preciosHot->datos) > 0)
<section class="mb-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">🔥 Precios Hot</h2>
    <div class="flex overflow-x-auto scrollbar-hide gap-4 px-1">
        @foreach($preciosHot->datos as $productoHot)
        <div class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 relative min-w-[320px] md:min-w-[360px] flex-shrink-0">
            <div class="p-4">
                {{-- Badge descuento --}}
                <span class="absolute top-2 right-2 bg-red-100 text-red-700 text-xs font-semibold px-2 py-1 rounded z-10">
    -{{ (int) floatval(str_replace(',', '.', $productoHot['porcentaje_diferencia'])) }}%
</span>

                <div class="flex mb-3 items-start">
                    {{-- Imagen producto --}}
                    <img loading="lazy" src="{{ asset('images/' . $productoHot['img_producto']) }}"
                         alt="{{ $productoHot['producto_nombre'] }}"
                         class="w-20 h-20 object-contain rounded bg-gray-100 shadow-sm flex-shrink-0">

                    {{-- Logo tienda + nombre producto --}}
                    <div class="flex flex-col justify-between flex-grow h-full">
                        <div class="flex justify-center w-full">
                            <img loading="lazy" src="{{ asset('images/' . $productoHot['img_tienda']) }}"
                                 alt="{{ $productoHot['tienda_nombre'] }}"
                                 class="object-contain max-h-7 w-auto mb-2">
                        </div>
                        <h3 class="font-semibold text-gray-800 text-sm md:text-base leading-tight pl-3">
                            {{ $productoHot['producto_nombre'] }}
                        </h3>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div>
                        <div class="flex items-baseline gap-1">
                            <p class="text-lg font-bold text-red-600">
                                {{ number_format($productoHot['precio_oferta'], 2) }}€
                            </p>
                            <span class="text-sm text-gray-500">/Und.</span>
                        </div>
                        @if(isset($productoHot['unidades']))
                            <p class="text-sm text-gray-600">{{ $productoHot['unidades'] }} unidades</p>
                        @endif
                    </div>
                    <a href="{{ $productoHot['url_producto'] }}" 
                           class="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded transition">
                            Ver producto
                        </a>
                    <a href="{{ $productoHot['url_oferta'] }}"
                       target="_blank"
                       class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                        Comprar
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>
@endif

        <!-- {{-- OFERTAS DESTACADAS --}}
        @if(isset($ofertasDestacadas) && $ofertasDestacadas->count() > 0)
        <section class="mb-12">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Ofertas Destacadas</h2>
            <div class="flex overflow-x-auto scrollbar-hide gap-4 px-1">
                @foreach($ofertasDestacadas as $oferta)
                <div class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 relative min-w-[280px] md:min-w-[300px] flex-shrink-0">
                    <div class="p-4">
                        {{-- Badge Oferta --}}
                        <span class="absolute top-2 right-2 bg-red-100 text-red-700 text-xs font-semibold px-2 py-0.5 rounded z-10">
                            Oferta
                        </span>

                        <div class="flex mb-3 items-start">
                            {{-- Imagen del producto --}}
                            <img loading="lazy" src="{{ asset('images/' . $producto->imagen_pequena) }}" alt="{{ $producto->nombre }}" class="w-16 h-16 object-contain rounded bg-gray-100 shadow-sm flex-shrink-0">

                            {{-- Columna: logo tienda centrado + nombre producto --}}
                            <div class="flex flex-col justify-between flex-grow h-full">
                                {{-- Logo tienda centrado horizontalmente respecto a toda la tarjeta --}}
                                <div class="flex justify-center w-full">
                                    <img loading="lazy" src="{{ asset('images/' . $oferta->tienda->url_imagen) }}" alt="{{ $oferta->tienda->nombre }}" class="object-contain max-h-7 w-auto mb-2">
                                </div>

                                {{-- Nombre del producto con padding izquierdo --}}
                                <h3 class="font-semibold text-gray-800 text-sm md:text-base leading-tight pl-3">{{ $oferta->producto->nombre }}</h3>
                            </div>
                        </div>

                        {{-- Precio, unidades y botón --}}
                        <div class="flex items-center justify-between">
                            <div>
                                <div class="flex items-baseline gap-1">
                                    <p class="text-lg font-bold text-green-600">
                                        {{ number_format($oferta->precio_unidad, 2) }}€
                                    </p>
                                    <span class="text-sm text-gray-500">/Und.</span>
                                </div>
                            <p class="text-sm text-gray-600">{{ $oferta->unidades }} unidades</p>
                        </div>
                        <a href="{{ route('click.redirigir', $oferta->id) }}" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">Ver Oferta</a>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </section>
        @endif -->

        {{-- ÚLTIMOS PRODUCTOS --}}
        @if(isset($ultimosProductos) && $ultimosProductos->count() > 0)
        <section class="mb-12">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Últimos Productos Añadidos</h2>
            <div class="relative">
                <div class="flex space-x-4 lg:space-x-3 overflow-x-auto pb-4 scrollbar-hide">
                    @foreach($ultimosProductos as $producto)
                    <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}"
                    class="group flex flex-col items-center bg-white rounded-xl shadow-md transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer p-4 w-2/5 min-w-[160px] sm:w-1/4 sm:min-w-[200px] lg:w-1/5 lg:min-w-[220px]">
                        <div class="w-full flex justify-center mb-3">
                            @if($producto->imagen_pequena)
                                <img loading="lazy" src="{{ asset('images/' .$producto->imagen_pequena) }}"
                                    alt="{{ $producto->nombre }}"
                                    class="w-32 h-32 object-contain rounded-lg shadow-sm transition-all duration-300 group-hover:shadow-lg bg-gray-100">
                            @else
                                <div class="w-32 h-32 flex items-center justify-center rounded-lg bg-gradient-to-br from-blue-100 to-blue-200">
                                    <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                </div>
                            @endif
                        </div>
                        <h3 class="font-semibold text-gray-700 text-center text-sm mb-1 line-clamp-2">
                            {{ $producto->nombre }}
                        </h3>
                        <p class="text-center mb-1">
                            <span class="text-xl font-bold text-pink-600">{{ number_format($producto->precio, 2) }}€
                                @if($producto->unidadDeMedida === 'unidad')
                                    <span class="text-xs text-gray-500">/Und.</span>
                                @elseif($producto->unidadDeMedida === 'kilos')
                                    <span class="text-xs text-gray-500">/kg.</span>
                                @elseif($producto->unidadDeMedida === 'litros')
                                    <span class="text-xs text-gray-500">/L.</span>
                                @endif
                            </span>
                        </p>
                    </a>
                    @endforeach
                </div>
            </div>
        </section>
        @endif

        

    </main>
{{-- FOOTER DESDE LA RUTA COMPONENTS/FOOTER --}}
    <x-footer />
    <style>
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>

    
{{-- JS PARA EL HEADER --}}
@stack('scripts')

{{-- MOVER EL SCROLL HORIZONTAL DE LAS CATEGORIAS --}}
<script>
    const carrusel = document.getElementById('carouselCategorias');
    const flechaIzquierda = document.getElementById('flechaIzquierda');
    const flechaDerecha = document.getElementById('flechaDerecha');

    flechaIzquierda.addEventListener('click', () => {
        carrusel.scrollBy({ left: -200, behavior: 'smooth' });
    });

    flechaDerecha.addEventListener('click', () => {
        carrusel.scrollBy({ left: 200, behavior: 'smooth' });
    });
</script>

</body>
</html> 