<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{{ $producto->meta_titulo }}</title>
  <meta name="description" content="{{ $producto->meta_description }}">
  <link rel="canonical" href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}">
  <meta property="og:title" content="{{ $producto->meta_titulo }}">
<meta property="og:description" content="{{ $producto->meta_description }}">
<meta property="og:image" content="{{ asset('images/' . $producto->imagen_grande) }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:type" content="product">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $producto->meta_titulo }}">
<meta name="twitter:description" content="{{ $producto->meta_description }}">
<meta name="twitter:image" content="{{ asset('images/' . $producto->imagen_grande) }}">

  @vite(['resources/css/app.css', 'resources/js/app.js'])
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-size: 1.05rem;
    }

    .card-hover {
      transition: transform 0.2s ease-in-out, background-color 0.2s ease-in-out;
    }

    .card-hover:hover {
      transform: scale(1.02);
      background-color: #f9f9f9;
    }

    .divider {
      position: relative;
    }

    .divider::after {
      content: "";
      position: absolute;
      top: 20%;
      bottom: 20%;
      right: 0;
      width: 1px;
      background: linear-gradient(to bottom, transparent, rgba(0, 0, 0, 0.1), transparent);
    }

    .icon-small {
      width: 16px;
      height: 16px;
      display: inline-block;
      vertical-align: middle;
    }

    @media (max-width: 1024px) {
      .bloque-movil-scroll {
        display: flex;
        overflow-x: auto;
        gap: 0.75rem;
        padding-bottom: 0.5rem;
        scroll-snap-type: x mandatory;
      }

      .bloque-movil-scroll>* {
        flex: 0 0 auto;
        scroll-snap-align: start;
      }

      .product-card {
        display: grid !important;
        grid-template-columns: repeat(3, 1fr);
        grid-template-areas:
          "logo precio-und precio-und"
          "envio und precio-total"
          "boton boton boton";
        gap: 0.5rem;
        padding: 1rem;
      }

      .logo {
        grid-area: logo;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .logo img {
        display: block;
        margin: 0 auto;
      }

      .precio-und {
        grid-area: precio-und;
        text-align: center !important;
        align-self: center;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .envio {
        grid-area: envio;
        text-align: center;
      }

      .und {
        grid-area: und;
        text-align: center;
      }

      .precio-total {
        grid-area: precio-total;
        text-align: center;
      }

      .boton {
        grid-area: boton;
        text-align: center;
      }

      .divider::after {
        display: none;
      }
    }
  </style>
</head>

<body class="bg-gray-50">
  <!-- <pre>{{ print_r($producto->toArray(), true) }}</pre> -->
  @php

  $preciosUnd = $ofertas->pluck('precio_unidad')->map(fn($p) => floatval($p))->all();
  $precioMin = count($preciosUnd) > 0 ? min($preciosUnd) : null;
  $precioMax = count($preciosUnd) > 0 ? max($preciosUnd) : null;
  @endphp



  {{-- HEADER --}}
  <x-header />
    
  <div class="max-w-7xl mx-auto flex flex-col gap-6 py-4 px-4 bg-gray-100">
    {{-- BREADCRUMB --}}
<nav class="mb-1">
    <ol class="flex items-center space-x-1 text-sm text-gray-600">
        <li>
            <a href="{{ route('home') }}" class="hover:text-pink-600">Inicio</a>
        </li>
        @foreach($breadcrumb as $item)
        <li class="flex items-center">
            <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
            </svg>
            <a href="{{ url('categoria/' . $item['slug']) }}" class="hover:text-pink-600">{{ $item['nombre'] }}</a>
        </li>
        @endforeach
    </ol>
</nav>

    <!-- BLOQUE MÓVIL ÚNICAMENTE -->
    <h1 class="text-xl font-bold mb-2 block lg:hidden">{{ $producto->titulo}}</h1>

    <div class="block lg:hidden bg-white rounded-lg shadow p-4 flex flex-col gap-4">
      <img src="{{ asset('images/' . $producto->imagen_grande) }}" loading="lazy" alt="Imagen de {{$producto->nombre}}" class="w-full max-h-60 object-contain mx-auto">
      <div class="text-center text-2xl font-extrabold text-pink-400">{{ $precioMin }} - {{ $precioMax }} €/Und.</div>
      <a href="#listado-precios" class="block w-full text-center py-3 bg-blue-500 text-white rounded font-semibold hover:bg-blue-600">
        Compara entre {{ count($ofertas) }} ofertas
      </a>
      <div class="text-sm text-gray-600 leading-relaxed relative overflow-hidden max-h-[4.5em]" id="descripcion-corta">
        {{ $producto->descripcion_corta}}
        <span class="absolute bottom-0 right-0 bg-white pl-2 text-blue-500 font-semibold cursor-pointer" id="leer-mas">Leer más</span>
      </div>
      <div class="bloque-movil-scroll overflow-x-auto whitespace-nowrap pb-2">
        @foreach ($relacionados as $relacionado)
        <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}" class="inline-block align-top bg-gray-50 rounded-lg border p-3 w-36 text-center card-hover hover:bg-gray-100">
          <img src="{{ asset('images/' . $relacionado->imagen_pequena) }}" loading="lazy" alt="{{$relacionado->nombre}}" class="w-full h-auto object-contain mb-2">
          <div class="text-sm font-semibold">{{ $relacionado->talla }}</div>
          <div class="text-sm text-pink-500">{{ number_format($relacionado->precio, 2, ',', '.') }}/Und.</div>
        </a>
        @endforeach
      </div>
    </div>

    <!-- BLOQUE DESKTOP ÚNICAMENTE -->
    <div class="hidden lg:grid grid-cols-4 gap-4 mb-4">
      <div class="bg-white rounded-lg shadow p-4 items-center justify-center flex">
        <img src="{{ asset('images/' . $producto->imagen_pequena) }}" alt="Imagen de {{$producto->nombre}}" class="max-h-70 object-contain">
      </div>

      <div class="col-span-2 bg-white rounded-lg shadow overflow-hidden flex flex-col">
        <div class="pt-4 pb-2 px-4">
          <h1 class="text-xl font-bold mb-2">{{ $producto->titulo}}</h1>
          <p class="text-gray-600 text-sm leading-relaxed">
            {{ $producto->descripcion_corta}}
          </p>
        </div>

        <!-- LÍNEA CON TEXTO EN MEDIO -->
        <div class="flex items-center px-4 mt-2 mb-4 gap-2">
          <div class="flex-grow border-t border-gray-200"></div>
          <h2 class="text-base font-semibold text-gray-700 whitespace-nowrap">Ofertas de pañales similares a {{ $producto->marca }} {{ $producto->modelo }} {{ $producto->talla }}</h2>
          <div class="flex-grow border-t border-gray-200"></div>
        </div>

        <!-- CARRUSEL DE PRODUCTOS -->
        <div class="overflow-x-auto whitespace-nowrap pb-2 px-4">
          @foreach ($relacionados as $relacionado)
          <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}" class="inline-block align-top card-hover p-4 border border-gray-200 rounded-lg text-center hover:bg-gray-50 transition-transform duration-200 w-[160px] mr-2">
            <div class="flex justify-center mb-2">
              <img src="{{ asset('images/' . $relacionado->imagen_pequena) }}" loading="lazy" alt="{{$relacionado->nombre}}" class="w-[94px] max-w-full h-auto object-contain">
            </div>
            <div class="text-sm font-semibold text-black-700">{{ $relacionado->marca }} - {{ $relacionado->talla }}</div>
            <div class="text-xl font-bold text-pink-500">{{ number_format($producto->precio, 2) }}€
    @if($producto->unidadDeMedida === 'unidad')
        <span class="text-xs text-gray-500">/Und.</span>
    @elseif($producto->unidadDeMedida === 'kilos')
        <span class="text-xs text-gray-500">/kg.</span>
    @elseif($producto->unidadDeMedida === 'litros')
        <span class="text-xs text-gray-500">/L.</span>
    @endif
          </div>
          </a>
          @endforeach
        </div>
      </div>
      
      {{-- GRAFICO HISTORICO PRECIO DESKTOP--}}
      <div class="bg-white rounded-lg shadow p-4" style="height: 350px;">
        <canvas id="graficoPrecios" class="w-full h-full"></canvas>
      </div>
    </div>

    <div class="flex flex-col-reverse lg:flex-row gap-6">
      <aside class="w-full lg:w-1/4">
        <div class="bg-white shadow rounded-lg p-4">
          <!-- Productos por debajo del precio medio -->
          @if($productosPrecioMedio->count() > 0)
          <div class="mb-6">
            <h3 class="text-lg font-semibold mb-3 text-gray-800 border-b border-gray-200 pb-2">Productos Rebajados</h3>
            <div class="space-y-2">
              @foreach($productosPrecioMedio as $index => $item)
              <a href="{{ $item['url_producto'] }}" class="block">
                <div class="flex items-center space-x-3 p-2 bg-gray-50 rounded hover:bg-gray-100 transition-colors">
                  <div class="flex-shrink-0">
                    <img src="{{ asset('images/' . $item['img_producto']) }}" alt="{{ $item['producto_nombre'] }}" class="w-10 h-10 object-cover rounded">
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium text-gray-900 truncate">{{ $item['producto_nombre'] }}</div>
                    <div class="flex items-center justify-between mt-1">
                      <div class="text-sm font-bold text-pink-500">
                        <span class="text-xs text-gray-500">Desde </span>
                        {{ number_format($item['precio_oferta'], 2, ',', '.') }}€
                        @if($item['producto']['unidadDeMedida'] === 'unidad')
                            <span class="text-xs text-gray-500">/Und.</span>
                        @elseif($item['producto']['unidadDeMedida'] === 'kilos')
                            <span class="text-xs text-gray-500">/Kg.</span>
                        @elseif($item['producto']['unidadDeMedida'] === 'litros')
                            <span class="text-xs text-gray-500">/L.</span>
                        @endif
                      </div>
                      <div class="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                        -{{ round($item['porcentaje_diferencia']) }}%
                      </div>
                    </div>
                  </div>
                </div>
              </a>
              @endforeach
            </div>
          </div>
          @endif

          <!-- Productos Precios Hot -->
          @if($productosPreciosHot->count() > 0)
          <div>
            <h3 class="text-lg font-semibold mb-3 text-gray-800 border-b border-gray-200 pb-2">Precios Hot 🔥 </h3>
            <div class="space-y-2">
              @foreach($productosPreciosHot as $index => $item)
              <a href="{{ $item['url_producto'] }}" class="block">
                <div class="flex items-center space-x-3 p-2 bg-blue-50 rounded hover:bg-blue-100 transition-colors">
                  <div class="flex-shrink-0">
                    <img src="{{ asset('images/' . $item['img_producto']) }}" alt="{{ $item['producto_nombre'] }}" class="w-10 h-10 object-cover rounded">
                  </div>
                  <div class="flex-1 min-w-0">
                    <div class="text-sm font-medium text-gray-900 truncate">{{ $item['producto_nombre'] }}</div>
                    <div class="flex items-center justify-between mt-1">
                      <div class="text-sm font-bold text-pink-500">
                      <span class="text-xs text-gray-500">Desde </span>
                        {{ number_format($item['precio_oferta'], 2, ',', '.') }}€
                        @if($item['producto']['unidadDeMedida'] === 'unidad')
                            <span class="text-xs text-gray-500">/Und.</span>
                        @elseif($item['producto']['unidadDeMedida'] === 'kilos')
                            <span class="text-xs text-gray-500">/Kg.</span>
                        @elseif($item['producto']['unidadDeMedida'] === 'litros')
                            <span class="text-xs text-gray-500">/L.</span>
                        @endif
                      </div>
                      <div class="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                        -{{ round($item['porcentaje_diferencia']) }}%
                      </div>
                    </div>
                  </div>
                </div>
              </a>
              @endforeach
            </div>
          </div>
          @endif
        </div>
      </aside>

      <!-- GRÁFICO PARA MÓVIL Y TABLET -->
      <div class="block lg:hidden bg-white rounded-lg shadow p-4 mb-4">
        <canvas id="graficoPreciosMovil" style="width:100%; min-height:250px;"></canvas>
      </div>

      <main id="listado-precios" class="w-full lg:w-3/4">
        <h2 class="text-2xl font-semibold mb-4">{{ $producto->subtitulo}}</h2>
        <!-- Filtros arriba del listado -->
        @php
$tiendasUnicas = collect($ofertas)->map(fn($o) => $o->tienda->nombre)->unique()->sort()->values();
        $cantidadesUnicas = collect($ofertas)->map(fn($o) => $o->unidades)->unique()->sort()->values();
        @endphp
        @php
        // Detectar si viene el parámetro ?v=xxx
        $unidadSeleccionada = request('v');
        $ofertasFiltradas = $unidadSeleccionada
            ? $ofertas->where('unidades', $unidadSeleccionada)
            : $ofertas;
        @endphp
        <div class="flex flex-wrap gap-4 mb-6 items-center bg-gray-200 border rounded">
          <div>
            <label for="filtro-tienda" class="font-semibold mr-2 text-sm">Tienda:</label>
            <select id="filtro-tienda" class="border rounded px-2 py-1 min-w-[180px] w-[180px] text-sm">
              <option value="">Todas</option>
              @foreach($tiendasUnicas as $tienda)
                <option value="{{ $tienda }}">{{ $tienda }}</option>
              @endforeach
            </select>
          </div>
          <div>
            <label class="font-semibold mr-2 text-sm"><input type="checkbox" id="filtro-envio" class="mr-1"> Envío gratis</label>
          </div>
          <div>
            <label for="filtro-cantidad" class="font-semibold mr-2 text-sm">Cantidad:</label>
            <select id="filtro-cantidad" class="border rounded px-2 py-1 min-w-[140px] w-[140px] text-sm">
              <option value="">Todas</option>
              @foreach($cantidadesUnicas as $cantidad)
                <option value="{{ $cantidad }}" {{ $unidadSeleccionada == $cantidad ? 'selected' : '' }}>{{ $cantidad }} Unidades</option>
              @endforeach
            </select>
          </div>
          <div class="flex items-center gap-1">
            <span class="font-semibold mr-2 text-sm">Ordenar por:</span>
            <button id="btn-orden-unidades" type="button" class="border rounded px-3 py-1 bg-blue-500 text-white font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 transition">Unidades</button>
            <button id="btn-orden-precio" type="button" class="border rounded px-3 py-1 bg-white text-blue-500 font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 transition">Precio total</button>
          </div>
        </div>
        <div id="listado-ofertas" class="space-y-2"></div>
        @php
        $ofertasArray = $ofertas->map(function($item) {
          return [
            "id" => $item->id,
            "nombre" => $item->tienda->nombre,
            "tienda" => $item->tienda->nombre,
            "logo" => asset('images/' . $item->tienda->url_imagen),
            "envio_gratis" => $item->tienda->envio_gratis,
            "envio_normal" => $item->tienda->envio_normal,
            "unidades" => $item->unidades,
            "precio_total" => number_format($item->precio_total, 2, ',', ''),
            "precio_unidad" => number_format($item->precio_unidad, 2, ',', ''),
            "url" => route('click.redirigir', ['ofertaId' => $item->id]) . (request()->has('cam') ? '?cam=' . request('cam') : ''),
          ];
        })->values();
        @endphp
        <script>
          // Datos de ofertas para JS
document.getElementById('filtro-cantidad').addEventListener('change', marcarInteraccion);
document.getElementById('btn-orden-unidades').addEventListener('click', function() {
  ordenActual = 'unidades';
  setOrdenBotones();
  filtroInteractuado = true;
  renderOfertas();
});
document.getElementById('btn-orden-precio').addEventListener('click', function() {
  ordenActual = 'precio_total';
  setOrdenBotones();
  filtroInteractuado = true;
  renderOfertas();
});
document.addEventListener('DOMContentLoaded', function() {
  setOrdenBotones();
  renderOfertas();
});
          const ofertas = {!! json_encode($ofertasArray) !!};

          let ordenActual = null; // En la primera carga, respeta el orden del backend
          let filtroInteractuado = false;

          // Obtener el parámetro v de la URL para filtrado inicial
          function getParamV() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('v');
          }

          function renderOfertas() {
            const tienda = document.getElementById('filtro-tienda').value;
            const envioGratis = document.getElementById('filtro-envio').checked;
            const cantidad = document.getElementById('filtro-cantidad').value;
            let filtradas = ofertas.slice();
            if (tienda) filtradas = filtradas.filter(o => o.tienda === tienda);
            if (envioGratis) filtradas = filtradas.filter(o => (o.envio_gratis && o.envio_gratis.toLowerCase().includes('gratis')));
            if (cantidad) filtradas = filtradas.filter(o => String(o.unidades) === cantidad);
            // Solo ordenar si el usuario lo solicita
            if (ordenActual === 'precio_total') {
              filtradas.sort((a, b) => parseFloat(a.precio_total.replace(',', '.')) - parseFloat(b.precio_total.replace(',', '.')));
            } else if (ordenActual === 'unidades') {
              filtradas.sort((a, b) => parseFloat(a.precio_unidad.replace(',', '.')) - parseFloat(b.precio_unidad.replace(',', '.')));
            }
            // Si ordenActual es null, respeta el orden original del backend
            const cont = document.getElementById('listado-ofertas');
            cont.innerHTML = '';
            if (filtradas.length === 0) {
              if (filtroInteractuado) {
                cont.innerHTML = `<div class='bg-red-100 border-l-4 border-red-500 text-red-800 p-6 rounded text-lg text-center'>No hay ofertas que coincidan con los filtros seleccionados.</div>`;
              } else {
                cont.innerHTML = `<div class='bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-6 rounded text-lg text-center'>No hay ofertas disponibles actualmente para este producto.</div>`;
              }
              return;
            }
            filtradas.forEach(item => {
              // Intercambiar estilos según filtro activo
              let precioTotalClass = 'text-sm text-gray-500';
              let precioTotalLabelClass = 'font-semibold';
              let precioUnidadClass = 'text-3xl font-extrabold text-pink-400';
              let precioUnidadLabelClass = 'text-sm text-gray-500';
              if (ordenActual === 'precio_total') {
                // Solo el valor del precio total destacado
                precioTotalClass = 'text-3xl font-extrabold text-pink-400';
                precioTotalLabelClass = 'text-sm text-gray-500';
                precioUnidadClass = 'text-sm text-gray-500';
                precioUnidadLabelClass = 'font-semibold';
              }
              cont.innerHTML += `
                <a href="${item.url}" class="product-card block bg-white rounded-lg shadow py-2 px-4 sm:px-6 grid sm:grid-cols-[100px_1fr_1fr_1fr_1fr_auto] sm:items-center sm:gap-4 card-hover hover:shadow-md">
                  <div class="logo flex items-center justify-center divider min-w-0 overflow-hidden">
                    <img src="${item.logo}" loading="lazy" alt="${item.nombre}" class="w-full max-w-[130px] sm:h-[45px] h-[36px] object-contain">
                  </div>
                  <div class="envio text-gray-700 divider text-center min-w-0 overflow-hidden">
                    <p class="text-sm text-gray-500 font-bold"><img src='{{ asset('images/van.png') }}' loading="lazy" alt='Van' class='icon-small'> ${item.envio_gratis}</p>
                    <p class="text-sm text-gray-500"><img src='{{ asset('images/van.png') }}' loading="lazy" alt='Van' class='icon-small'> ${item.envio_normal}</p>
                  </div>
                  <div class="und text-gray-700 divider text-center min-w-0 overflow-hidden">
                    <div class="font-semibold">Cantidad</div>
                    <div class="text-sm text-gray-500 leading-tight">${item.unidades} Unidades</div>
                  </div>
                  <div class="precio-total text-gray-700 divider text-center min-w-0 overflow-hidden">
                    <div class="${precioTotalLabelClass}">Precio total</div>
                    <div class="${precioTotalClass}">${item.precio_total} <span class="text-sm text-gray-500 font-normal">€</span></div>
                  </div>
                  <div class="precio-und text-center text-gray-700 divider min-w-0 overflow-hidden">
                    <div class="${precioUnidadLabelClass}">Precio por unidad</div>
                    <div class="${precioUnidadClass}">
                      ${item.precio_unidad}
                      <span class="text-sm text-gray-500 font-normal">€/Und.</span>
                    </div>
                  </div>
                  <div class="boton text-center min-w-0 overflow-hidden">
                    <span class="inline-block w-full py-3 px-2 bg-blue-500 text-white text-sm font-semibold rounded hover:bg-blue-600">Ir a la tienda</span>
                  </div>
                </a>
              `;
            });
          }

          function marcarInteraccion() {
            filtroInteractuado = true;
            renderOfertas();
          }

          function setOrdenBotones() {
            const btnUnidades = document.getElementById('btn-orden-unidades');
            const btnPrecio = document.getElementById('btn-orden-precio');
            [btnUnidades, btnPrecio].forEach(btn => {
              btn.classList.remove('bg-gray-700', 'text-white', 'bg-white', 'text-blue-500');
              btn.classList.add('bg-white', 'text-blue-500'); // Estado base inactivo
            });
            if (ordenActual === 'unidades' || ordenActual === null) {
              btnUnidades.classList.add('bg-gray-700', 'text-white'); // Activo
              btnUnidades.classList.remove('bg-white', 'text-blue-500');
            } else if (ordenActual === 'precio_total') {
              btnPrecio.classList.add('bg-gray-700', 'text-white'); // Activo
              btnPrecio.classList.remove('bg-white', 'text-blue-500');
            }
          }

          document.getElementById('filtro-tienda').addEventListener('change', marcarInteraccion);
          document.getElementById('filtro-envio').addEventListener('change', marcarInteraccion);
          document.getElementById('filtro-cantidad').addEventListener('change', marcarInteraccion);
          document.getElementById('btn-orden-unidades').addEventListener('click', function() {
            ordenActual = 'unidades'; // Ahora 'unidades' significa precio_unidad
            setOrdenBotones();
            filtroInteractuado = true;
            renderOfertas();
          });
          document.getElementById('btn-orden-precio').addEventListener('click', function() {
            ordenActual = 'precio_total';
            setOrdenBotones();
            filtroInteractuado = true;
            renderOfertas();
          });

          document.addEventListener('DOMContentLoaded', function() {
            setOrdenBotones();
            // Filtrado inicial por parámetro v si existe
            const vParam = getParamV();
            if (vParam) {
              document.getElementById('filtro-cantidad').value = vParam;
            }
            renderOfertas();
          });
        </script>

        <!-- INFO DETALLADA DEL PRODUCTO -->
        <section class="mt-8 bg-white rounded-2xl shadow-lg p-6 text-gray-800 leading-relaxed space-y-8">

          <!-- TÍTULO -->
          <header>
            <h2 class="text-2xl font-bold mb-2">{{ $producto->marca}} {{ $producto->modelo}} {{ $producto->talla}} – Análisis completo</h2>
            <p class="text-gray-600 text-sm">{{ $producto->descripcion_larga}}</p>
          </header>

          <!-- CARACTERÍSTICAS -->
          <section>
            <h3 class="text-xl font-semibold mb-4">Características principales</h3>
            <ul class="list-disc pl-5 space-y-1 text-gray-700">
              @foreach ($producto->caracteristicas as $caracteristica)
              <li>{{ $caracteristica }}</li>
              @endforeach
            </ul>
          </section>

          <!-- PROS Y CONTRAS -->
          <section>
            <h3 class="text-xl font-semibold mb-4">Pros y contras</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div class="bg-green-50 border-l-4 border-green-400 p-4 rounded-lg">
                <h4 class="font-semibold text-green-700 mb-2">Pros</h4>
                <ul class="list-disc pl-5 text-sm text-green-800 space-y-1">
                  @foreach ($producto->pros as $pro)
                  <li>{{ $pro }}</li>
                  @endforeach
                </ul>
              </div>
              <div class="bg-red-50 border-l-4 border-red-400 p-4 rounded-lg">
                <h4 class="font-semibold text-red-700 mb-2">Contras</h4>
                <ul class="list-disc pl-5 text-sm text-red-800 space-y-1">
                  @foreach ($producto->contras as $contra)
                  <li>{{ $contra }}</li>
                  @endforeach
                </ul>
              </div>
            </div>
          </section>

          <!-- PREGUNTAS FRECUENTES (ACORDEÓN CON FLECHAS) -->
          <section x-data="{ open: null }">
            <h3 class="text-xl font-semibold mb-4">Preguntas frecuentes</h3>
            <div class="space-y-3">
              @foreach ($producto->faq as $i => $item)
              <div class="border rounded-lg overflow-hidden">
                <button @click="open === {{ $i }} ? open = null : open = {{ $i }}"
                  class="w-full flex justify-between items-center px-4 py-3 text-left font-medium bg-gray-100 hover:bg-gray-200 transition">
                  <span>{{ $item['pregunta'] }}</span>
                  <svg :class="open === {{ $i }} ? 'rotate-180' : ''"
                    class="w-5 h-5 text-gray-500 transition-transform duration-300" fill="none" stroke="currentColor" stroke-width="2"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
                <div x-show="open === {{ $i }}" x-collapse class="px-4 py-3 text-sm text-gray-700 bg-white">
                  {{ $item['respuesta'] }}
                </div>
              </div>
              @endforeach
            </div>
          </section>

          <!--Snippets para mejorar el SEO -->
          <!--Para indexar en GOOGLE la ficha de producto -->
          @php
          // Generar array de ofertas para cada versión (por unidades)
          $offersJsonLd = $cantidadesUnicas->map(function($cantidad) use ($producto, $ofertas) {
              $oferta = $ofertas->where('unidades', $cantidad)->sortBy('precio_total')->first();
              if (!$oferta) return null;
              return [
                  "@type" => "Offer",
                  "url" => $producto->categoria->construirUrlCategorias($producto->slug) . '?v=' . $cantidad,
                  "price" => number_format($oferta->precio_total, 2, '.', ''),
                  "priceCurrency" => "EUR",
                  "itemCondition" => "https://schema.org/NewCondition",
                  "availability" => "https://schema.org/InStock",
                  "seller" => [
                      "@type" => "Organization",
                      "name" => $oferta->tienda->nombre
                  ],
                  "sku" => $oferta->id,
                  "description" => $producto->descripcion_corta . ' - ' . $cantidad . ' unidades',
              ];
          })->filter()->values();

          $productJsonLd = [
              "@context" => "https://schema.org",
              "@type" => "Product",
              "name" => $producto->titulo,
              "image" => [ asset('images/panales/' . $producto->imagen_grande) ],
              "description" => $producto->descripcion_corta,
              "brand" => [
                  "@type" => "Brand",
                  "name" => $producto->marca,
                  "url" => url('buscar?q=' . Str::slug($producto->marca))
              ],
              "offers" => $offersJsonLd
          ];
          @endphp
          <!--Para indexar las preguntas frecuentes -->
          @php
          $faqJsonLd = [
          "@context" => "https://schema.org",
          "@type" => "FAQPage",
          "mainEntity" => collect($producto->faq, true)->map(fn($item) => [
          "@type" => "Question",
          "name" => $item['pregunta'],
          "acceptedAnswer" => [
          "@type" => "Answer",
          "text" => $item['respuesta']
          ]
          ])->values()
          ];
          @endphp

          <script type="application/ld+json">
            {
              !!json_encode($faqJsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) !!
            }
          </script>


          <script type="application/ld+json">
            {
              !!json_encode($productJsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) !!
            }
          </script>
          <!--Para indexar el buscador -->
          <script type="application/ld+json">
            {
              "@context": "https://schema.org",
              "@type": "WebSite",
              "name": "CholloPañales",
              "url": "https://chollopanales.com",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://chollopanales.com/buscar?q={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            }
          </script>
      </main>
    </div>
    </section>
  </div>

  {{-- FOOTER DESDE LA RUTA COMPONENTS/FOOTER --}}
    <x-footer />

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const ctx = document.getElementById('graficoPrecios').getContext('2d');
      const precios = @json($precios);
      const labels = precios.map(p => p.fecha);
      const datos = precios.map(p => p.precio);

      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Precio (€)',
            data: datos,
            fill: true,
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.1)',
            tension: 0.3
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: {
            mode: 'index',
            intersect: false
          },
          plugins: {
            tooltip: {
              mode: 'index',
              intersect: false,
              callbacks: {
                label: context => `Precio: ${context.parsed.y.toFixed(2)} €`
              }
            }
          },
          scales: {
            y: {
              beginAtZero: false,
              ticks: {
                callback: value => value.toFixed(2) + ' €'
              }
            }
          }
        }
      });

      const container = document.getElementById('graficoPrecios').parentElement;
      const resizeObserver = new ResizeObserver(() => chart.resize());
      resizeObserver.observe(container);

      // Gráfico para móvil
      const canvasMovil = document.getElementById('graficoPreciosMovil');
      if (canvasMovil) {
        const ctxMovil = canvasMovil.getContext('2d');
        const chartMovil = new Chart(ctxMovil, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [{
              label: 'Precio (€)',
              data: datos,
              fill: true,
              borderColor: 'rgb(75, 192, 192)',
              backgroundColor: 'rgba(75, 192, 192, 0.1)',
              tension: 0.3
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: true,
            interaction: {
              mode: 'index',
              intersect: false
            },
            plugins: {
              tooltip: {
                mode: 'index',
                intersect: false,
                callbacks: {
                  label: context => `Precio: ${context.parsed.y.toFixed(2)} €`
                }
              }
            },
            scales: {
              y: {
                beginAtZero: false,
                ticks: {
                  callback: value => value.toFixed(2) + ' €'
                }
              }
            }
          }
        });
        const containerMovil = canvasMovil.parentElement;
        const resizeObserverMovil = new ResizeObserver(() => chartMovil.resize());
        resizeObserverMovil.observe(containerMovil);
      }
    });
  </script>


  {{-- JS PARA EL ACORDEON DE PREGUNTAS FRECUENTES --}}
  <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

{{-- JS PARA EL BUSCADOR DEL HEADER --}}
@stack('scripts')
</body>

</html>