<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">
                    Inicio ->
                </h2>
            </a>
            <a href="{{ route('admin.productos.index') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">
                    Producto ->
                </h2>
            </a>
            <h2 class="font-semibold text-xl text-white leading-tight">
                {{ $producto ? 'Editar producto' : 'Añadir producto' }}
            </h2>
        </div>
    </x-slot>

    <div class="max-w-5xl mx-auto py-10 px-4 space-y-8 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-md">

        <form method="POST" enctype="multipart/form-data"
            action="{{ $producto ? route('admin.productos.update', $producto) : route('admin.productos.store') }}">
            @csrf
            @if($producto)
            @method('PUT')
            @endif
            {{--CATEGORIA, SUBCATEGORIA Y SUBSUBCATEGORIA --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Categoría</legend>

                <div id="categorias-container" class="space-y-4">
                    <!-- Los selectores de categorías se generarán dinámicamente aquí -->
                </div>

                <div class="flex gap-2">
                    <button type="button" id="agregar-categoria" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                        + Agregar nivel de categoría
                    </button>
                    <button type="button" id="limpiar-categorias" class="bg-gray-600 hover:bg-gray-700 text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Limpiar categorías
                    </button>
                </div>

                <!-- Campo oculto para la categoría final -->
                <input type="hidden" name="categoria_id" id="categoria-final" value="{{ old('categoria_id', $producto->categoria_id ?? '') }}">
            </fieldset>

            {{-- DATOS PRINCIPALES --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Información general</legend>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre *</label>
                        <input type="text" name="nombre" value="{{ old('nombre', $producto->nombre ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('nombre') border-red-500 @enderror">
                        @error('nombre') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Slug *</label>
                        <input type="text" id="slug" name="slug" value="{{ old('slug', $producto->slug ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('slug') border-red-500 @enderror">
                        @error('slug') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Marca *</label>
                        <input type="text" name="marca" value="{{ old('marca', $producto->marca ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('marca') border-red-500 @enderror">
                        @error('marca') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Modelo *</label>
                        <input type="text" name="modelo" value="{{ old('modelo', $producto->modelo ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('modelo') border-red-500 @enderror">
                        @error('modelo') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Talla</label>
                        <input type="text" name="talla" value="{{ old('talla', $producto->talla ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('talla') border-red-500 @enderror">
                        @error('talla') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Unidad de medida</label>
                        <select name="unidadDeMedida" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('unidadDeMedida') border-red-500 @enderror">
                            <option value="total" {{ old('unidadDeMedida', $producto->unidadDeMedida ?? '') == 'total' ? 'selected' : '' }}>Total</option>
                            <option value="unidad" {{ old('unidadDeMedida', $producto->unidadDeMedida ?? '') == 'unidad' ? 'selected' : '' }}>Unidad</option>
                            <option value="kilos" {{ old('unidadDeMedida', $producto->unidadDeMedida ?? '') == 'kilos' ? 'selected' : '' }}>Kilos</option>
                            <option value="litros" {{ old('unidadDeMedida', $producto->unidadDeMedida ?? '') == 'litros' ? 'selected' : '' }}>Litros</option>
                        </select>
                        @error('unidadDeMedida') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div class="md:col-span-2">
                        <button type="button" id="rellenar-info-automatica" 
                            class="bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                            <span id="btn-text">Rellenar información automáticamente</span>
                            <span id="btn-loading" class="hidden">
                                <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Procesando...
                            </span>
                        </button>
                        <div id="progreso-info" class="mt-2 text-sm text-gray-600 dark:text-gray-400 hidden">
                            <div id="progreso-texto">Iniciando proceso...</div>
                        </div>
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Precio (€)</label>
                        <input type="number" step="0.01" name="precio" value="{{ old('precio', $producto->precio ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('precio') border-red-500 @enderror">
                        @error('precio') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">¿Obsoleto? *</label>
                        <div class="flex gap-6">
                            <label class="inline-flex items-center">
                                <input type="radio" name="obsoleto" value="no"
                                    {{ old('obsoleto', $producto->obsoleto ?? 'no') === 'no' ? 'checked' : '' }}
                                    class="form-radio text-pink-600">
                                <span class="ml-2 text-gray-700 dark:text-gray-200">No</span>
                            </label>
                            <label class="inline-flex items-center">
                                <input type="radio" name="obsoleto" value="si"
                                    {{ old('obsoleto', $producto->obsoleto ?? 'no') === 'si' ? 'checked' : '' }}
                                    class="form-radio text-pink-600">
                                <span class="ml-2 text-gray-700 dark:text-gray-200">Sí</span>
                            </label>
                        </div>
                    </div>

                </div>
            </fieldset>

            {{-- IMÁGENES --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-4 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imágenes</legend>

                <!-- Pestañas de gestión de imágenes -->
                <div class="border-b border-gray-200 dark:border-gray-600">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <button type="button" id="tab-upload" class="tab-button border-b-2 border-blue-500 py-2 px-1 text-sm font-medium text-blue-600 dark:text-blue-400" aria-current="page">
                            Subir imagen
                        </button>
                        <button type="button" id="tab-manual" class="tab-button border-b-2 border-transparent py-2 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300">
                            Nombre manual
                        </button>
                    </nav>
                </div>

                <!-- Contenido de la pestaña de subida -->
                <div id="content-upload" class="tab-content space-y-4">
                    <!-- Imagen Grande -->
                    <div>
                        <label class="block mb-2 font-medium text-gray-700 dark:text-gray-200">Imagen Grande *</label>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <!-- Selector de carpeta -->
                            <div>
                                <label class="block mb-1 text-sm text-gray-600 dark:text-gray-400">Carpeta</label>
                                <div class="flex gap-2">
                                    <select id="carpeta-imagen-grande" class="flex-1 px-3 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border text-sm">
                                        <option value="">Selecciona una carpeta</option>
                                        <option value="panales">panales</option>
                                        <option value="categorias">categorias</option>
                                        <option value="tiendas">tiendas</option>
                                    </select>
                                    <button type="button" id="btn-ver-imagenes-grande" class="bg-gray-500 hover:bg-gray-600 text-white px-3 py-2 rounded text-sm">
                                        Ver
                                    </button>
                                </div>
                                
                                <!-- Información de imagen actual -->
                                @php
                                    $imgGrandeActual = old('imagen_grande', $producto->imagen_grande ?? '');
                                    $carpetaGrandeActual = $imgGrandeActual ? explode('/', $imgGrandeActual)[0] : '';
                                @endphp
                                @if($imgGrandeActual)
                                <div class="mt-2 p-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded text-xs">
                                    <div class="text-green-700 dark:text-green-300 font-medium">✓ Imagen actual:</div>
                                    <div class="text-green-600 dark:text-green-400 break-words">{{ $imgGrandeActual }}</div>
                                    
                                    <!-- Vista previa de imagen actual -->
                                    <div class="mt-2 flex items-center gap-2">
                                        <img id="preview-upload-grande" src="{{ asset('images/' . $imgGrandeActual) }}" alt="Vista previa" class="h-12 w-12 object-contain border rounded">
                                        <button type="button" id="btn-limpiar-grande" class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                            Limpiar
                                        </button>
                                    </div>
                                </div>
                                @else
                                <!-- Vista previa vacía (oculta por defecto) -->
                                <div class="mt-2 flex items-center gap-2 hidden" id="preview-container-grande">
                                    <img id="preview-upload-grande" src="" alt="Vista previa" class="h-12 w-12 object-contain border rounded">
                                    <button type="button" id="btn-limpiar-grande" class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                        Limpiar
                                    </button>
                                </div>
                                @endif
                            </div>
                            
                            <!-- Área de upload -->
                            <div class="md:col-span-2">
                                <label class="block mb-1 text-sm text-gray-600 dark:text-gray-400">Seleccionar imagen</label>
                                <div class="flex gap-2">
                                    <input type="file" id="file-imagen-grande" accept="image/*" class="hidden">
                                    <button type="button" id="btn-seleccionar-grande" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">
                                        Seleccionar archivo
                                    </button>
                                    <span id="nombre-archivo-grande" class="text-sm text-gray-500 dark:text-gray-400 self-center"></span>
                                </div>
                                
                                <!-- Área de drag & drop -->
                                <div id="drop-zone-grande" class="mt-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors">
                                    <div class="text-gray-500 dark:text-gray-400">
                                        <svg class="mx-auto h-8 w-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                        </svg>
                                        <p>Arrastra y suelta la imagen aquí</p>
                                        <p class="text-xs">o haz clic para seleccionar</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Campo oculto -->
                        <input type="hidden" id="ruta-imagen-grande" name="imagen_grande" value="{{ old('imagen_grande', $producto->imagen_grande ?? '') }}">
                        <span id="ruta-completa-grande" class="text-sm text-gray-600 dark:text-gray-400 hidden"></span>
                        @error('imagen_grande') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <!-- Imagen Pequeña -->
                    <div>
                        <label class="block mb-2 font-medium text-gray-700 dark:text-gray-200">Imagen Pequeña *</label>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <!-- Selector de carpeta -->
                            <div>
                                <label class="block mb-1 text-sm text-gray-600 dark:text-gray-700">Carpeta</label>
                                <div class="flex gap-2">
                                    <select id="carpeta-imagen-pequena" class="flex-1 px-3 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border text-sm">
                                        <option value="">Selecciona una carpeta</option>
                                        <option value="panales">panales</option>
                                        <option value="categorias">categorias</option>
                                        <option value="tiendas">tiendas</option>
                                    </select>
                                    <button type="button" id="btn-ver-imagenes-pequena" class="bg-gray-500 hover:bg-gray-600 text-white px-3 py-2 rounded text-sm">
                                        Ver
                                    </button>
                                </div>
                                
                                <!-- Información de imagen actual -->
                                @php
                                    $imgPequenaActual = old('imagen_pequena', $producto->imagen_pequena ?? '');
                                    $carpetaPequenaActual = $imgPequenaActual ? explode('/', $imgPequenaActual)[0] : '';
                                @endphp
                                @if($imgPequenaActual)
                                <div class="mt-2 p-2 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded text-xs">
                                    <div class="text-green-700 dark:text-green-300 font-medium">✓ Imagen actual:</div>
                                    <div class="text-green-600 dark:text-green-400 break-words">{{ $imgPequenaActual }}</div>
                                    
                                    <!-- Vista previa de imagen actual -->
                                    <div class="mt-2 flex items-center gap-2">
                                        <img id="preview-upload-pequena" src="{{ asset('images/' . $imgPequenaActual) }}" alt="Vista previa" class="h-12 w-12 object-contain border rounded">
                                        <button type="button" id="btn-limpiar-pequena" class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                            Limpiar
                                        </button>
                                    </div>
                                </div>
                                @else
                                <!-- Vista previa vacía (oculta por defecto) -->
                                <div class="mt-2 flex items-center gap-2 hidden" id="preview-container-pequena">
                                    <img id="preview-upload-pequena" src="" alt="Vista previa" class="h-12 w-12 object-contain border rounded">
                                    <button type="button" id="btn-limpiar-pequena" class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                        Limpiar
                                    </button>
                                </div>
                                @endif
                            </div>
                            
                            <!-- Área de upload -->
                            <div class="md:col-span-2">
                                <label class="block mb-1 text-sm text-gray-600 dark:text-gray-400">Seleccionar imagen</label>
                                <div class="flex gap-2">
                                    <input type="file" id="file-imagen-pequena" accept="image/*" class="hidden">
                                    <button type="button" id="btn-seleccionar-pequena" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">
                                        Seleccionar archivo
                                    </button>
                                    <span id="nombre-archivo-pequena" class="text-sm text-gray-500 dark:text-gray-400 self-center"></span>
                                </div>
                                
                                <!-- Área de drag & drop -->
                                <div id="drop-zone-pequena" class="mt-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors">
                                    <div class="text-gray-500 dark:text-gray-400">
                                        <svg class="mx-auto h-8 w-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                        </svg>
                                        <p>Arrastra y suelta la imagen aquí</p>
                                        <p class="text-xs">o haz clic para seleccionar</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Campo oculto -->
                        <input type="hidden" id="ruta-imagen-pequena" name="imagen_pequena" value="{{ old('imagen_pequena', $producto->imagen_pequena ?? '') }}">
                        <span id="ruta-completa-pequena" class="text-sm text-gray-600 dark:text-gray-400 hidden"></span>
                        @error('imagen_pequena') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>

                <!-- Contenido de la pestaña manual (oculto por defecto) -->
                <div id="content-manual" class="tab-content space-y-4 hidden">
                    <!-- Imagen Grande Manual -->
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre de imagen grande *</label>
                        <div class="flex gap-2 items-center">
                            <input type="text" id="imagen-grande-input" name="imagen_grande_manual" value="{{ old('imagen_grande', $producto->imagen_grande ?? '') }}"
                                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('imagen_grande') border-red-500 @enderror">
                            <button type="button" id="buscar-imagen-grande" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-3 h-full rounded">Buscar imagen</button>
                            @php
                                $imgGrande = old('imagen_grande', $producto->imagen_grande ?? '');
                                $imgGrandeSrc = $imgGrande ? asset('images/' . $imgGrande) : '';
                                $imgGrandeDisplay = $imgGrande ? 'block' : 'none';
                            @endphp
                            <img id="preview-imagen-grande" src="{{ $imgGrandeSrc }}" alt="Vista previa" class="h-12 w-12 object-contain ml-2 border rounded" style="display: {{ $imgGrandeDisplay }};">
                        </div>
                        @error('imagen_grande') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <!-- Imagen Pequeña Manual -->
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre de imagen pequeña *</label>
                        <div class="flex gap-2 items-center">
                            <input type="text" id="imagen-pequena-input" name="imagen_pequena_manual" value="{{ old('imagen_pequena', $producto->imagen_pequena ?? '') }}"
                                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('imagen_pequena') border-red-500 @enderror">
                            <button type="button" id="buscar-imagen-pequena" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-3 h-full rounded">Buscar imagen</button>
                            @php
                                $imgPequena = old('imagen_pequena', $producto->imagen_pequena ?? '') ?? '';
                                $imgPequenaSrc = $imgPequena ? asset('images/' . $imgPequena) : '';
                                $imgPequenaDisplay = $imgPequena ? 'block' : 'none';
                            @endphp
                            <img id="preview-imagen-pequena" src="{{ $imgPequenaSrc }}" alt="Vista previa" class="h-12 w-12 object-contain ml-2 border rounded" style="display: {{ $imgPequenaDisplay }};">
                        </div>
                        @error('imagen_pequena') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>
            </fieldset>


            {{-- INFORMACION PRODUCTO --}}

            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Contenido y características</legend>

                <div class="space-y-4">
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Título *</label>
                        <input type="text" name="titulo" value="{{ old('titulo', $producto->titulo ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('titulo') border-red-500 @enderror">
                        @error('titulo') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Subtítulo</label>
                        <input type="text" name="subtitulo" value="{{ old('subtitulo', $producto->subtitulo ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('subtitulo') border-red-500 @enderror">
                        @error('subtitulo') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Descripción corta</label>
                        <textarea name="descripcion_corta" rows="3"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('descripcion_corta') border-red-500 @enderror">{{ old('descripcion_corta', $producto->descripcion_corta ?? '') }}</textarea>
                        @error('descripcion_corta') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Descripción larga</label>
                        <textarea name="descripcion_larga" rows="5"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('descripcion_larga') border-red-500 @enderror">{{ old('descripcion_larga', $producto->descripcion_larga ?? '') }}</textarea>
                        @error('descripcion_larga') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Características (una por línea)</label>
                        <textarea name="caracteristicas" rows="4"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('caracteristicas') border-red-500 @enderror">{{ is_array(old('caracteristicas', $producto->caracteristicas ?? [])) ? implode("\n", old('caracteristicas', $producto->caracteristicas ?? [])) : old('caracteristicas', '') }}</textarea>
                        @error('caracteristicas') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>
            </fieldset>

            {{-- PROS Y CONTRAS --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Pros y contras</legend>

                <div>
                    <label class="block mb-2 font-medium text-gray-700 dark:text-gray-200">Pros *</label>
                    <div id="pros-list">
                        @php $pros = old('pros', $producto->pros ?? ['']); @endphp
                        @foreach ($pros as $pro)
                        <input type="text" name="pros[]" value="{{ $pro }}"
                            class="w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @endforeach
                    </div>
                    <div class="flex gap-4">
                        <button type="button" id="add-pro" class="text-sm text-green-600 font-medium">+ Añadir pro</button>
                        <button type="button" id="remove-pro" class="text-sm text-red-600 font-medium">– Quitar pro</button>
                    </div>
                </div>

                <div>
                    <label class="block mb-2 font-medium text-gray-700 dark:text-gray-200">Contras *</label>
                    <div id="contras-list">
                        @php $contras = old('contras', $producto->contras ?? ['']); @endphp
                        @foreach ($contras as $contra)
                        <input type="text" name="contras[]" value="{{ $contra }}"
                            class="w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @endforeach
                    </div>
                    <div class="flex gap-4">
                        <button type="button" id="add-contra" class="text-sm text-green-600 font-medium">+ Añadir contra</button>
                        <button type="button" id="remove-contra" class="text-sm text-red-600 font-medium">– Quitar contra</button>
                    </div>
                </div>
            </fieldset>

            {{-- FAQ --}}

            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Preguntas frecuentes</legend>

                <div id="faq-list" class="space-y-4">
                    @php $faqs = old('faq', $producto->faq ?? [['pregunta' => '', 'respuesta' => '']]); @endphp
                    @foreach ($faqs as $index => $faq)
                    <div class="faq-item grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="text" name="faq[{{ $index }}][pregunta]" placeholder="Pregunta"
                            value="{{ $faq['pregunta'] }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        <input type="text" name="faq[{{ $index }}][respuesta]" placeholder="Respuesta"
                            value="{{ $faq['respuesta'] }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>
                    @endforeach
                </div>

                <div class="flex gap-4">
                    <button type="button" id="add-faq" class="text-sm text-green-600 font-medium">+ Añadir FAQ</button>
                    <button type="button" id="remove-faq" class="text-sm text-red-600 font-medium">– Quitar FAQ</button>
                </div>
            </fieldset>

            {{-- PRODUCTOS RELACIONADOS --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Productos relacionados</legend>

                <div id="relacionados-list">
                    <div id="form-producto" data-producto-id="{{ $producto->id ?? '' }}"></div>
                    @php $relacionados = old('keys_relacionados', $producto->keys_relacionados ?? ['']); @endphp
                    @foreach ($relacionados as $relacionado)
                    <input type="text" name="keys_relacionados[]" value="{{ $relacionado }}"
                        class="w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    @endforeach
                </div>

                <div class="flex gap-4">
                    <button type="button" id="add-relacionado" class="text-sm text-green-600 font-medium">+ Añadir relacionado</button>
                    <button type="button" id="remove-relacionado" class="text-sm text-red-600 font-medium">– Quitar relacionado</button>
                </div>
                <div class="mt-4">
                    <button type="button" id="buscar-relacionados" class="text-sm bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded">
                        Buscar productos relacionados
                    </button>
                    <span id="relacionados-resultado" class="ml-4 text-gray-800 dark:text-gray-200 text-sm"></span>
                </div>
            </fieldset>

            {{-- INFORMACION META --}}

            <fieldset class=" bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">SEO</legend>

                <div class="space-y-4">
                <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Meta título</label>
                        <textarea name="meta_titulo" rows="1"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('meta_titulo') border-red-500 @enderror">{{ old('meta_description', $producto->meta_description ?? '') }}</textarea>
                        @error('meta_titulo') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Meta descripción</label>
                        <textarea name="meta_description" rows="3"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border @error('meta_description') border-red-500 @enderror">{{ old('meta_description', $producto->meta_description ?? '') }}</textarea>
                        @error('meta_description') <p class="text-red-500 text-sm mt-1">{{ $message }}</p> @enderror
                    </div>
                </div>
            </fieldset>

            {{-- PALABRAS CLAVE PARA CAMPA├æAS --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Palabras clave para campañas de publicidad</legend>

                <div id="palabras-clave-list">
                    @php
                    $palabras = $producto?->palabrasClave ?? collect([['palabra' => '', 'codigo' => '', 'activa' => 'si']]);
                    @endphp

                    @foreach ($palabras as $index => $item)
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2 palabra-clave-item">
                        <input type="text" name="palabras_clave[{{ $index }}][palabra]" class="palabra-input w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border"
                            value="{{ old("palabras_clave.$index.palabra", $item['palabra'] ?? '') }}" placeholder="Palabra clave">

                        <input type="text" name="palabras_clave[{{ $index }}][codigo]" class="codigo-input w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border"
                            value="{{ old("palabras_clave.$index.codigo", $item['codigo'] ?? '') }}" placeholder="Código" readonly>

                        <select name="palabras_clave[{{ $index }}][activa]" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                            <option value="si" @selected(old("palabras_clave.$index.activa", $item['activa'] ?? '' )==='si' )>Activa</option>
                            <option value="no" @selected(old("palabras_clave.$index.activa", $item['activa'] ?? '' )==='no' )>Inactiva</option>
                        </select>
                    </div>
                    @endforeach
                </div>

                <div class="flex gap-4">
                    <button type="button" id="add-palabra-clave" class="text-sm text-green-600 font-medium">Añadir palabra clave</button>
                    <button type="button" id="remove-palabra-clave" class="text-sm text-red-600 font-medium">Quitar palabra clave</button>

                </div>
            </fieldset>

            {{-- PONER AVISO --}}
            <fieldset class="space-y-2 border border-gray-300 dark:border-gray-600 rounded-xl p-4">
                <legend class="text-sm font-semibold text-gray-700 dark:text-gray-200 px-2">Aviso de revisión</legend>

                @if ($producto && $producto->aviso)
                <p class="text-sm text-gray-800 dark:text-gray-100">
                    Fecha actual de aviso: <strong>{{ \Carbon\Carbon::parse($producto->aviso)->format('d/m/Y H:i') }}</strong>
                </p>

                <label class="inline-flex items-center text-sm text-red-600 font-medium">
                    <input type="checkbox" name="eliminar_aviso" id="eliminar-aviso" class="mr-2">
                    Eliminar este aviso
                </label>
                @else
                <p class="text-sm text-gray-500 dark:text-gray-400">Actualmente no hay aviso configurado.</p>
                @endif

                <div class="flex gap-2">
                    <input type="number" name="aviso_cantidad" placeholder="Cantidad"
                        value="{{ old('aviso_cantidad') }}"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                    <select name="aviso_unidad"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                        <option value="">Unidad</option>
                        <option value="days" {{ old('aviso_unidad') == 'days' ? 'selected' : '' }}>Días</option>
                        <option value="weeks" {{ old('aviso_unidad') == 'weeks' ? 'selected' : '' }}>Semanas</option>
                        <option value="months" {{ old('aviso_unidad') == 'months' ? 'selected' : '' }}>Meses</option>
                        <option value="years" {{ old('aviso_unidad') == 'years' ? 'selected' : '' }}>Años</option>
                    </select>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const checkbox = document.getElementById('eliminar-aviso');
                        const cantidadInput = document.querySelector('input[name="aviso_cantidad"]');
                        const unidadSelect = document.querySelector('select[name="aviso_unidad"]');

                        if (checkbox) {
                            checkbox.addEventListener('change', () => {
                                if (checkbox.checked) {
                                    cantidadInput.value = '';
                                    unidadSelect.value = '';
                                }
                            });
                        }
                    });
                </script>
            </fieldset>


            {{-- ANOTACIONES INTERNAS --}}
            <div>
                <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Anotaciones internas</label>
                <textarea name="anotaciones_internas"
                    class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border"
                    rows="4">{{ old('anotaciones_internas', $producto->anotaciones_internas ?? '') }}</textarea>
            </div>

            <div class="flex justify-between items-center mt-8">
                {{-- A├æADIR OFERTA --}}
                @if ($producto && $producto->id)
                <a href="{{ route('admin.ofertas.create', ['producto' => $producto->id]) }}"
                    target="_blank"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-md shadow-md inline-block text-center">
                    + Añadir oferta
                </a>
                @endif

                {{-- BOTÓN GUARDAR --}}
                <button type="submit"
                    class="inline-flex items-center bg-pink-600 hover:bg-pink-700 text-white font-semibold text-base px-6 py-3 rounded-md shadow-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500">
                    Guardar producto
                </button>
            </div>


        </form>
    </div>

    {{-- MODAL PARA AÑADIR OFERTA --}}
    <div id="modalOferta" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-5xl w-full relative shadow-xl overflow-y-auto max-h-[90vh]">
            <button onclick="cerrarModalOferta()" class="absolute top-3 right-4 text-xl text-gray-800 dark:text-gray-100">×</button>
            <div id="contenido-modal-oferta" class="text-center text-gray-700 dark:text-gray-100">Cargando...</div>
        </div>
    </div>

    {{-- MODAL PARA VER IMÁGENES EXISTENTES --}}
    <div id="modalImagenes" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-6xl w-full relative shadow-xl overflow-y-auto max-h-[90vh]">
            <button onclick="cerrarModalImagenes()" class="absolute top-3 right-4 text-xl text-gray-800 dark:text-gray-100 hover:text-gray-600 dark:hover:text-gray-300">×</button>
            <div class="mb-4">
                <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imágenes en la carpeta: <span id="nombre-carpeta-modal" class="text-blue-600 dark:text-blue-400"></span></h3>
                <p class="text-sm text-gray-500 dark:text-gray-400">Haz clic en una imagen para seleccionarla</p>
            </div>
            <div id="contenido-modal-imagenes" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                <div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>
            </div>
        </div>
    </div>

    {{-- SCRIPTS --}}
    <script>
        // Vista previa de imagen grande
        document.getElementById('buscar-imagen-grande').onclick = function() {
            const input = document.getElementById('imagen-grande-input');
            const preview = document.getElementById('preview-imagen-grande');
            if (input.value.trim() !== '') {
                preview.src = '/images/' + input.value.trim();
                preview.style.display = 'block';
            } else {
                preview.src = '';
                preview.style.display = 'none';
            }
        };
        document.getElementById('imagen-grande-input').addEventListener('input', function() {
            document.getElementById('preview-imagen-grande').style.display = 'none';
        });

        // Vista previa de imagen pequeña
        document.getElementById('buscar-imagen-pequena').onclick = function() {
            const input = document.getElementById('imagen-pequena-input');
            const preview = document.getElementById('preview-imagen-pequena');
            if (input.value.trim() !== '') {
                preview.src = '/images/' + input.value.trim();
                preview.style.display = 'block';
            } else {
                preview.src = '';
                preview.style.display = 'none';
            }
        };
        document.getElementById('imagen-pequena-input').addEventListener('input', function() {
            document.getElementById('preview-imagen-pequena').style.display = 'none';
        });
        const prosList = document.getElementById('pros-list');
        document.getElementById('add-pro').onclick = () => {
            const input = document.createElement('input');
            input.type = 'text';
            input.name = 'pros[]';
            input.className = 'w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
            prosList.appendChild(input);
        };
        document.getElementById('remove-pro').onclick = () => {
            if (prosList.children.length > 1) prosList.removeChild(prosList.lastElementChild);
        };

        const contrasList = document.getElementById('contras-list');
        document.getElementById('add-contra').onclick = () => {
            const input = document.createElement('input');
            input.type = 'text';
            input.name = 'contras[]';
            input.className = 'w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
            contrasList.appendChild(input);
        };
        document.getElementById('remove-contra').onclick = () => {
            if (contrasList.children.length > 1) contrasList.removeChild(contrasList.lastElementChild);
        };

        // Slug autogenerado
        document.getElementById('slug').addEventListener('input', e => {
            e.target.value = e.target.value
                .normalize("NFD").replace(/[\u0300-\u036f]/g, '')
                .replace(/[^a-zA-Z0-9\s-]/g, '')
                .trim().replace(/\s+/g, '-').toLowerCase();
        });

        // Añadir/Eliminar campos en las FAQ
        const faqList = document.getElementById('faq-list');
        let faqIndex = @json(count($faqs));

        document.getElementById('add-faq').onclick = () => {
            const div = document.createElement('div');
            div.className = 'faq-item grid grid-cols-1 md:grid-cols-2 gap-4';
            div.innerHTML = `
            <input type="text" name="faq[${faqIndex}][pregunta]" placeholder="Pregunta"
                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
            <input type="text" name="faq[${faqIndex}][respuesta]" placeholder="Respuesta"
                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
        `;
            faqList.appendChild(div);
            faqIndex++;
        };

        document.getElementById('remove-faq').onclick = () => {
            if (faqList.children.length > 1) {
                faqList.removeChild(faqList.lastElementChild);
                faqIndex--;
            } else {
                alert('Debe haber al menos una pregunta frecuente.');
            }
        };
    </script>

    {{-- SISTEMA DE CATEGORÍAS COMPLETAMENTE REWRITE --}}
    <div id="datos-categorias"
        data-categorias-raiz="{{ json_encode($categoriasRaiz) }}"
        data-categoria-id="{{ old('categoria_id', $producto->categoria_id ?? '') }}">
    </div>

    <script>
        // Variables globales
        let categoriasRaiz = [];
        let categoriaProducto = null;

        // Inicialización cuando se carga la página
        document.addEventListener('DOMContentLoaded', () => {
            const datos = document.getElementById('datos-categorias');
            categoriasRaiz = JSON.parse(datos.dataset.categoriasRaiz || '[]');
            categoriaProducto = datos.dataset.categoriaId || null;

            if (categoriaProducto) {
                // Es un producto existente - cargar toda la jerarquía
                cargarJerarquiaCompleta(categoriaProducto);
            } else {
                // Es un producto nuevo - crear solo el primer selector
                crearSelectorCategoria(0, categoriasRaiz, null);
            }

            // Configurar botones
            configurarBotones();
        });

        function configurarBotones() {
            // Botón para limpiar todo
            const btnLimpiar = document.getElementById('limpiar-categorias');
            if (btnLimpiar) {
                btnLimpiar.addEventListener('click', () => {
                    limpiarTodasLasCategorias();
                });
            }

            // Botón para agregar nivel de categoría
            const btnAgregar = document.getElementById('agregar-categoria');
            if (btnAgregar) {
                btnAgregar.addEventListener('click', () => {
                    agregarNivelCategoria();
                });
            }
        }

        function agregarNivelCategoria() {
            // Obtener el último selector con valor
            const selectores = document.querySelectorAll('.categoria-select');
            let ultimoNivel = -1;
            let ultimaCategoriaId = null;

            // Encontrar el último selector con valor seleccionado
            for (let i = selectores.length - 1; i >= 0; i--) {
                if (selectores[i].value) {
                    ultimoNivel = parseInt(selectores[i].dataset.nivel);
                    ultimaCategoriaId = selectores[i].value;
                    break;
                }
            }

            if (ultimaCategoriaId) {
                // Verificar si la última categoría tiene subcategorías
                verificarYAgregarSubcategoria(ultimoNivel + 1, ultimaCategoriaId);
            } else {
                // Si no hay categoría seleccionada, mostrar mensaje
                alert('Primero debes seleccionar una categoría para poder agregar un nivel adicional.');
            }
        }

        function verificarYAgregarSubcategoria(nivel, categoriaId) {
            fetch(`/panel-privado/categorias/${categoriaId}/subcategorias`, {
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(subcategorias => {
                if (subcategorias && subcategorias.length > 0) {
                    // Crear el nuevo selector con las subcategorías disponibles
                    crearSelectorCategoria(nivel, subcategorias, null);
                    // Actualizar el campo final
                    actualizarCategoriaFinal();
                } else {
                    // No hay subcategorías disponibles
                    alert('La categoría seleccionada no tiene subcategorías disponibles.');
                }
            })
            .catch(error => {
                console.error('Error verificando subcategorías:', error);
                alert('Error al verificar si hay subcategorías disponibles.');
            });
        }

        function cargarJerarquiaCompleta(categoriaId) {
            // Obtener la jerarquía completa de la categoría
            fetch(`/panel-privado/categorias/${categoriaId}/jerarquia`, {
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.jerarquia && data.jerarquia.length > 0) {
                    construirJerarquiaCompleta(data.jerarquia);
                }
            })
            .catch(error => {
                console.error('Error cargando jerarquía:', error);
                // Fallback: crear selector básico
                crearSelectorCategoria(0, categoriasRaiz, null);
            });
        }

        function construirJerarquiaCompleta(jerarquia) {
            // Limpiar contenedor
            const container = document.getElementById('categorias-container');
            container.innerHTML = '';

            // Crear selectores para cada nivel de la jerarquía
            jerarquia.forEach((nivel, index) => {
                if (index === 0) {
                    // Nivel 0: categorías raíz
                    crearSelectorCategoria(0, categoriasRaiz, nivel.id);
                } else {
                    // Niveles superiores: cargar subcategorías del nivel anterior
                    const nivelAnterior = jerarquia[index - 1];
                    cargarSubcategoriasParaJerarquia(index, nivelAnterior.id, nivel.id);
                }
            });

            // Actualizar campo final
            document.getElementById('categoria-final').value = categoriaProducto;
        }

        function cargarSubcategoriasParaJerarquia(nivel, categoriaId, valorSeleccionado) {
            fetch(`/panel-privado/categorias/${categoriaId}/subcategorias`, {
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(subcategorias => {
                if (subcategorias.length > 0) {
                    crearSelectorCategoria(nivel, subcategorias, valorSeleccionado);
                }
            })
            .catch(error => {
                console.error('Error cargando subcategorías:', error);
            });
        }

        function crearSelectorCategoria(nivel, opciones, valorSeleccionado) {
            const container = document.getElementById('categorias-container');
            
            // Verificar si ya existe un selector para este nivel
            const selectorExistente = document.querySelector(`.selector-categoria[data-nivel="${nivel}"]`);
            if (selectorExistente) {
                selectorExistente.remove();
            }
            
            // Crear contenedor del selector
            const div = document.createElement('div');
            div.className = 'selector-categoria flex items-center gap-4 mb-4';
            div.dataset.nivel = nivel;
            
            // Crear label
            const label = document.createElement('label');
            label.className = 'block mb-1 font-medium text-gray-700 dark:text-gray-200 min-w-[120px]';
            label.textContent = nivel === 0 ? 'Categoría principal *' : `Subcategoría ${nivel}`;
            
            // Crear select
            const select = document.createElement('select');
            select.className = 'categoria-select w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
            select.dataset.nivel = nivel;
            
            // Opción por defecto
            const optionDefault = document.createElement('option');
            optionDefault.value = '';
            optionDefault.textContent = nivel === 0 ? 'Selecciona una categoría' : 'Selecciona una subcategoría';
            select.appendChild(optionDefault);
            
            // Ordenar opciones alfabéticamente por nombre
            const opcionesOrdenadas = [...opciones].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', {sensitivity: 'base'}));
            
            // Agregar opciones ordenadas
            opcionesOrdenadas.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.id;
                option.textContent = cat.nombre;
                if (valorSeleccionado == cat.id) {
                    option.selected = true;
                }
                select.appendChild(option);
            });
            
            // Botón de eliminar (solo para niveles > 0)
            let removeBtn = null;
            if (nivel > 0) {
                removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.className = 'bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded text-sm';
                removeBtn.textContent = '×';
                removeBtn.title = 'Eliminar este nivel y los superiores';
                removeBtn.onclick = () => {
                    eliminarSelectorYSuperiores(nivel);
                };
            }
            
            // Ensamblar
            div.appendChild(label);
            div.appendChild(select);
            if (removeBtn) div.appendChild(removeBtn);
            
            container.appendChild(div);
            
            // Configurar evento change
            select.addEventListener('change', () => {
                const categoriaId = select.value;
                if (categoriaId) {
                    // Limpiar selectores de niveles superiores
                    limpiarSelectoresSuperiores(nivel + 1);
                    // Cargar subcategorías del siguiente nivel
                    cargarSubcategorias(nivel + 1, categoriaId);
                    // Actualizar campo final
                    actualizarCategoriaFinal();
                } else {
                    // Limpiar selectores de niveles superiores
                    limpiarSelectoresSuperiores(nivel + 1);
                    // Actualizar campo final
                    actualizarCategoriaFinal();
                }
            });
        }

        function cargarSubcategorias(nivel, categoriaId) {
            // Limpiar selectores de niveles superiores
            limpiarSelectoresSuperiores(nivel);
            
            fetch(`/panel-privado/categorias/${categoriaId}/subcategorias`, {
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(subcategorias => {
                if (subcategorias.length > 0) {
                    crearSelectorCategoria(nivel, subcategorias, null);
                }
            })
            .catch(error => {
                console.error('Error cargando subcategorías:', error);
            });
        }

        function limpiarSelectoresSuperiores(nivel) {
            const selectores = document.querySelectorAll(`.selector-categoria[data-nivel]`);
            selectores.forEach(selector => {
                const nivelSelector = parseInt(selector.dataset.nivel);
                if (nivelSelector >= nivel) {
                    selector.remove();
                }
            });
        }

        function eliminarSelectorYSuperiores(nivel) {
            const selectores = document.querySelectorAll(`.selector-categoria[data-nivel]`);
            selectores.forEach(selector => {
                const nivelSelector = parseInt(selector.dataset.nivel);
                if (nivelSelector >= nivel) {
                    selector.remove();
                }
            });
            // Actualizar campo final después de eliminar
            actualizarCategoriaFinal();
        }

        function limpiarTodasLasCategorias() {
            const container = document.getElementById('categorias-container');
            container.innerHTML = '';
            document.getElementById('categoria-final').value = '';
            // Solo crear el primer selector, no duplicar
            crearSelectorCategoria(0, categoriasRaiz, null);
        }

        function actualizarCategoriaFinal() {
            const selectores = document.querySelectorAll('.categoria-select');
            let categoriaFinal = null;
            
            // Buscar el último selector con valor
            for (let i = selectores.length - 1; i >= 0; i--) {
                if (selectores[i].value) {
                    categoriaFinal = selectores[i].value;
                    break;
                }
            }
            
            document.getElementById('categoria-final').value = categoriaFinal || '';
            
            // Actualizar indicador visual del botón agregar
            actualizarIndicadorBotonAgregar();
        }

        function actualizarIndicadorBotonAgregar() {
            const btnAgregar = document.getElementById('agregar-categoria');
            if (!btnAgregar) return;

            // Obtener el último selector con valor
            const selectores = document.querySelectorAll('.categoria-select');
            let ultimaCategoriaId = null;

            for (let i = selectores.length - 1; i >= 0; i--) {
                if (selectores[i].value) {
                    ultimaCategoriaId = selectores[i].value;
                    break;
                }
            }

            if (ultimaCategoriaId) {
                // Verificar si tiene subcategorías
                verificarSubcategoriasDisponibles(ultimaCategoriaId, btnAgregar);
            } else {
                // No hay categoría seleccionada
                btnAgregar.disabled = true;
                btnAgregar.className = 'bg-gray-400 cursor-not-allowed text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500';
                btnAgregar.title = 'Primero debes seleccionar una categoría';
            }
        }

        function verificarSubcategoriasDisponibles(categoriaId, btnAgregar) {
            fetch(`/panel-privado/categorias/${categoriaId}/subcategorias`, {
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(subcategorias => {
                if (subcategorias && subcategorias.length > 0) {
                    // Hay subcategorías disponibles
                    btnAgregar.disabled = false;
                    btnAgregar.className = 'bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500';
                    btnAgregar.title = `Agregar nivel de subcategoría (${subcategorias.length} opciones disponibles)`;
                } else {
                    // No hay subcategorías disponibles
                    btnAgregar.disabled = true;
                    btnAgregar.className = 'bg-gray-400 cursor-not-allowed text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500';
                    btnAgregar.title = 'Esta categoría no tiene subcategorías disponibles';
                }
            })
            .catch(error => {
                console.error('Error verificando subcategorías:', error);
                btnAgregar.disabled = true;
                btnAgregar.className = 'bg-gray-400 cursor-not-allowed text-white font-semibold px-4 py-2 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500';
                btnAgregar.title = 'Error al verificar subcategorías';
            });
        }
    </script>
    {{--AÑADIR O QUITAR CAMPOS DE PALABRAS CLAVE DE RELACIONADOS --}}
    <script>
        const relacionadosList = document.getElementById('relacionados-list');
        document.getElementById('add-relacionado').onclick = () => {
            const input = document.createElement('input');
            input.type = 'text';
            input.name = 'keys_relacionados[]';
            input.className = 'w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
            relacionadosList.appendChild(input);
        };
        document.getElementById('remove-relacionado').onclick = () => {
            if (relacionadosList.children.length > 1) relacionadosList.removeChild(relacionadosList.lastElementChild);
        };
    </script>
    {{-- BUSCAR PRODUCTOS RELACIONADOS CON LAS PALABRAS CLAVES QUE TENGO ESCRITAS--}}
    <script>
        document.getElementById('buscar-relacionados').addEventListener('click', () => {
            const inputs = document.querySelectorAll('input[name="keys_relacionados[]"]');
            const keywords = Array.from(inputs)
                .map(input => input.value.trim())
                .filter(val => val !== '');

            const productoId = document.getElementById('form-producto').dataset.productoId || null;

            if (keywords.length === 0) {
                document.getElementById('relacionados-resultado').textContent = 'Introduce al menos una palabra clave.';
                return;
            }

            fetch('/panel-privado/productos/buscar-relacionados', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        keywords,
                        producto_id: productoId
                    })
                })
                .then(res => res.json())
                .then(data => {
                    const resultado = document.getElementById('relacionados-resultado');

                    if (data.total === 0) {
                        resultado.innerHTML = '❌ Coincidencias encontradas: 0';
                        resultado.style.color = 'red';
                    } else if (data.total > 4) {
                        resultado.innerHTML = '✅ Coincidencias encontradas: ' + data.total;
                        resultado.style.color = 'green';
                    } else {
                        resultado.textContent = 'Coincidencias encontradas: ' + data.total;
                        resultado.style.color = '';
                    }

                })
                .catch(() => {
                    document.getElementById('relacionados-resultado').textContent = 'Error al buscar productos.';
                });
        });
    </script>
    {{-- SCRIPT PARA AÑADIR OFERTA --}}
    <script>
        function abrirModalOferta(productoId) {
            const modal = document.getElementById('modalOferta');
            const contenedor = document.getElementById('contenido-modal-oferta');

            if (!productoId || productoId === 'null') {
                contenedor.innerHTML = '<p class="text-red-600 dark:text-red-400">Primero debes guardar el producto para poder añadir ofertas.</p>';
                modal.classList.remove('hidden');
                return;
            }

            contenedor.innerHTML = '<p class="text-gray-600 dark:text-gray-300">Cargando formulario...</p>';

            fetch(`/admin/productos/${productoId}/ofertas/create`)
                .then(res => res.text())
                .then(html => {
                    contenedor.innerHTML = html;
                    modal.classList.remove('hidden');
                })
                .catch(() => {
                    contenedor.innerHTML = '<p class="text-red-600 dark:text-red-400">Error al cargar el formulario de oferta.</p>';
                    modal.classList.remove('hidden');
                });
        }

        function cerrarModalOferta() {
            document.getElementById('modalOferta').classList.add('hidden');
            document.getElementById('contenido-modal-oferta').innerHTML = '';
        }
    </script>

    {{-- AÑADIR O ELIMINAR CAMPOS PARA PALABRAS CLAVE --}}
    @php
    $palabraClaveIndex = isset($palabras) ? count($palabras) : 0;
    @endphp

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let palabraClaveIndex = @json($palabraClaveIndex);

            const contenedor = document.getElementById('palabras-clave-list');
            const botonAdd = document.getElementById('add-palabra-clave');
            const botonRemove = document.getElementById('remove-palabra-clave');

            //FUNCION PARA CONVERTIR LA PALABRA CLAVE EN CODIGO
            function normalizarTexto(texto) {
                return texto.toLowerCase()
                    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
                    .trim()
                    .replace(/\s+/g, '');
            }

            function generarCodigo(texto) {
                const normalizado = normalizarTexto(texto);
                let crc = 0;
                for (let i = 0; i < normalizado.length; i++) {
                    crc = (crc >>> 8) ^ crc32Table[(crc ^ normalizado.charCodeAt(i)) & 0xFF];
                }
                const hash = (crc ^ -1) >>> 0;
                return parseInt(hash, 10).toString(36).substring(0, 6);
            }

            const crc32Table = (() => {
                let c;
                const crcTable = [];
                for (let n = 0; n < 256; n++) {
                    c = n;
                    for (let k = 0; k < 8; k++) {
                        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
                    }
                    crcTable[n] = c;
                }
                return crcTable;
            })();

            document.querySelectorAll('.palabra-input').forEach(input => {
                input.addEventListener('input', () => {
                    const codigoInput = input.parentElement.querySelector('.codigo-input');
                    codigoInput.value = generarCodigo(input.value);
                });
            });

            if (botonAdd) {
                botonAdd.onclick = () => {
                    const div = document.createElement('div');
                    div.className = 'grid grid-cols-1 md:grid-cols-3 gap-4 mb-2 palabra-clave-item';
                    div.innerHTML = `
                    <input type="text" name="palabras_clave[${palabraClaveIndex}][palabra]" class="palabra-input w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border" placeholder="Palabra clave">
                    <input type="text" name="palabras_clave[${palabraClaveIndex}][codigo]" class="codigo-input w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border" readonly placeholder="Código">
                    <select name="palabras_clave[${palabraClaveIndex}][activa]" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        <option value="si">Activa</option>
                        <option value="no">Inactiva</option>
                    </select>
                `;
                    contenedor.appendChild(div);

                    const nuevoInput = div.querySelector('.palabra-input');
                    const nuevoCodigo = div.querySelector('.codigo-input');
                    nuevoInput.addEventListener('input', () => {
                        nuevoCodigo.value = generarCodigo(nuevoInput.value);
                    });

                    palabraClaveIndex++;
                };
            }

            if (botonRemove) {
                botonRemove.onclick = () => {
                    if (contenedor.children.length > 1) {
                        contenedor.removeChild(contenedor.lastElementChild);
                    }
                };
            }
        });
    </script>

{{-- SCRIPT PARA RELLENAR INFORMACIÓN AUTOMÁTICAMENTE --}}
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const btnRellenar = document.getElementById('rellenar-info-automatica');
            const btnText = document.getElementById('btn-text');
            const btnLoading = document.getElementById('btn-loading');
            const progresoInfo = document.getElementById('progreso-info');
            const progresoTexto = document.getElementById('progreso-texto');

            // Campos que deben estar vacíos para poder proceder
            const camposAVerificar = [
                'titulo',
                'subtitulo', 
                'descripcion_corta',
                'descripcion_larga',
                'caracteristicas'
            ];

            // Campos que deben estar llenos para proceder
            const camposRequeridos = [
                'nombre',
                'marca', 
                'modelo',
                'talla'
            ];

            btnRellenar.addEventListener('click', async () => {
                // Verificar que los campos requeridos estén llenos
                const camposFaltantes = [];
                camposRequeridos.forEach(campo => {
                    const valor = document.querySelector(`input[name="${campo}"]`).value.trim();
                    if (!valor) {
                        camposFaltantes.push(campo);
                    }
                });

                if (camposFaltantes.length > 0) {
                    alert(`Por favor, rellena los siguientes campos antes de continuar: ${camposFaltantes.join(', ')}`);
                    return;
                }

                // Verificar que los campos a rellenar estén vacíos
                const camposLlenos = [];
                camposAVerificar.forEach(campo => {
                    const elemento = document.querySelector(`[name="${campo}"]`);
                    const valor = elemento.value.trim();
                    if (valor) {
                        camposLlenos.push(campo);
                    }
                });

                if (camposLlenos.length > 0) {
                    const confirmar = confirm(`Los siguientes campos ya tienen contenido: ${camposLlenos.join(', ')}. ¿Deseas continuar y sobrescribir el contenido?`);
                    if (!confirmar) {
                        return;
                    }
                }

                // Iniciar proceso
                btnText.classList.add('hidden');
                btnLoading.classList.remove('hidden');
                progresoInfo.classList.remove('hidden');
                btnRellenar.disabled = true;

                try {
                    // Obtener datos del producto
                    const nombre = document.querySelector('input[name="nombre"]').value.trim();
                    const marca = document.querySelector('input[name="marca"]').value.trim();
                    const modelo = document.querySelector('input[name="modelo"]').value.trim();
                    const talla = document.querySelector('input[name="talla"]').value.trim();

                    progresoTexto.textContent = 'Preparando datos del producto...';

                    // Preparar prompt para ChatGPT
                    const prompt = `Actúa como un experto en SEO y marketing digital especializado en productos para bebés. Necesito que generes contenido optimizado para un comparador de precios.

INFORMACIÓN DEL PRODUCTO:
- Nombre: ${nombre}
- Marca: ${marca}
- Modelo: ${modelo}
- Talla: ${talla}

INSTRUCCIONES ESPECÍFICAS:
Debes generar EXACTAMENTE un objeto JSON con la siguiente estructura, sin texto adicional antes o después:

{
  "titulo": "Comparador de ${nombre} ${marca} - Mejor Precio",
  "subtitulo": "Descripción corta del producto ${nombre} de ${marca}, ideal para padres que buscan calidad y buen precio. Incluye información sobre talla ${talla} y características principales.",
  "descripcion_corta": "El ${nombre} de ${marca} es un producto de alta calidad diseñado para proporcionar la máxima comodidad y protección. Con su modelo ${modelo} en talla ${talla}, ofrece una excelente relación calidad-precio. Perfecto para padres que buscan productos confiables para sus bebés.",
  "descripcion_larga": "<h3>Características principales del ${nombre}</h3><p>Este producto de ${marca} destaca por su calidad superior y diseño innovador. El modelo ${modelo} está específicamente diseñado para proporcionar máxima comodidad y protección.</p><h3>Beneficios para tu bebé</h3><p>Con la talla ${talla}, aseguras un ajuste perfecto que previene fugas y mantiene a tu bebé seco durante más tiempo. La tecnología avanzada de ${marca} garantiza una absorción excepcional.</p><h3>¿Por qué elegir este producto?</h3><p>Los padres que han probado el ${nombre} de ${marca} destacan su durabilidad y la tranquilidad que proporciona. Es una inversión inteligente para el bienestar de tu bebé.</p>",
  "caracteristicas": "Absorción superior, Material hipoalergénico, Diseño ergonómico, Indicador de humedad, Cintura elástica, Protección anti-fugas",
  "meta_titulo": "Comparador ${nombre} ${marca} - Mejor Precio Online",
  "meta_descripcion": "Encuentra el mejor precio para ${nombre} ${marca} talla ${talla}. Compara precios entre tiendas y ahorra en productos para tu bebé.",
  "pros": ["Excelente absorción", "Material hipoalergénico", "Diseño cómodo", "Indicador de humedad", "Precio competitivo", "Marca confiable"],
  "contras": ["Precio superior a marcas genéricas", "Disponibilidad limitada en algunas tiendas", "Talla específica"],
  "preguntas_frecuentes": [
    {"pregunta": "¿Qué talla necesito para mi bebé?", "respuesta": "La talla ${talla} es ideal para bebés de 6-12 meses. Consulta la tabla de tallas de ${marca} para mayor precisión."},
    {"pregunta": "¿Es hipoalergénico?", "respuesta": "Sí, el ${nombre} de ${marca} está fabricado con materiales hipoalergénicos que protegen la piel sensible de tu bebé."},
    {"pregunta": "¿Cuántos pañales vienen por paquete?", "respuesta": "El modelo ${modelo} viene en paquetes de 24-48 unidades, dependiendo de la talla ${talla} y la tienda."},
    {"pregunta": "¿Tiene indicador de humedad?", "respuesta": "Sí, incluye un indicador de humedad que cambia de color cuando el pañal necesita ser cambiado."}
  ]
}

REGLAS IMPORTANTES:
- Devuelve ÚNICAMENTE el JSON, sin explicaciones adicionales
- Asegúrate de que el JSON sea válido
- Incluye exactamente los campos especificados
- Usa la información del producto proporcionada
- Optimiza para SEO con palabras clave relevantes`;

                    progresoTexto.textContent = 'Enviando petición a ChatGPT...';

                    // Hacer petición a ChatGPT
                    const response = await fetch('/productos/generar-contenido', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            prompt: prompt,
                            nombre: nombre,
                            marca: marca,
                            modelo: modelo,
                            talla: talla
                        })
                    });

                    if (!response.ok) {
                        throw new Error(`Error HTTP: ${response.status}`);
                    }

                    progresoTexto.textContent = 'Procesando respuesta de ChatGPT...';

                    const data = await response.json();

                    if (data.error) {
                        throw new Error(data.error);
                    }

                    progresoTexto.textContent = 'Rellenando campos del formulario...';

                    // Rellenar los campos con la respuesta
                    if (data.titulo) {
                        document.querySelector('input[name="titulo"]').value = data.titulo;
                    }
                    if (data.subtitulo) {
                        document.querySelector('input[name="subtitulo"]').value = data.subtitulo;
                    }
                    if (data.descripcion_corta) {
                        document.querySelector('textarea[name="descripcion_corta"]').value = data.descripcion_corta;
                    }
                    if (data.descripcion_larga) {
                        document.querySelector('textarea[name="descripcion_larga"]').value = data.descripcion_larga;
                    }
                    if (data.caracteristicas) {
                        document.querySelector('textarea[name="caracteristicas"]').value = data.caracteristicas;
                    }
                    

                    // Rellenar pros
                    if (data.pros && data.pros.length > 0) {
                        const prosList = document.getElementById('pros-list');
                        prosList.innerHTML = '';
                        data.pros.forEach(pro => {
                            const input = document.createElement('input');
                            input.type = 'text';
                            input.name = 'pros[]';
                            input.value = pro.trim();
                            input.className = 'w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
                            prosList.appendChild(input);
                        });
                    }

                    // Rellenar contras
                    if (data.contras && data.contras.length > 0) {
                        const contrasList = document.getElementById('contras-list');
                        contrasList.innerHTML = '';
                        data.contras.forEach(contra => {
                            const input = document.createElement('input');
                            input.type = 'text';
                            input.name = 'contras[]';
                            input.value = contra.trim();
                            input.className = 'w-full mb-2 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
                            contrasList.appendChild(input);
                        });
                    }

                    // Rellenar FAQ
                    if (data.preguntas_frecuentes && data.preguntas_frecuentes.length > 0) {
                        const faqList = document.getElementById('faq-list');
                        faqList.innerHTML = '';
                        data.preguntas_frecuentes.forEach((faq, index) => {
                            const div = document.createElement('div');
                            div.className = 'faq-item grid grid-cols-1 md:grid-cols-2 gap-4';
                            div.innerHTML = `
                                <input type="text" name="faq[${index}][pregunta]" placeholder="Pregunta"
                                    value="${faq.pregunta}" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                                <input type="text" name="faq[${index}][respuesta]" placeholder="Respuesta"
                                    value="${faq.respuesta}" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                            `;
                            faqList.appendChild(div);
                        });
                    }if (data.caracteristicas) {
                        document.querySelector('textarea[name="meta_titulo"]').value = data.meta_titulo;
                    }
                    if (data.caracteristicas) {
                        document.querySelector('textarea[name="meta_description"]').value = data.meta_descripcion;
                    }

                    progresoTexto.textContent = '¡Información rellenada correctamente!';
                    progresoTexto.className = 'text-green-600 dark:text-green-400';

                } catch (error) {
                    console.error('Error:', error);
                    progresoTexto.textContent = `Error: ${error.message}`;
                    progresoTexto.className = 'text-red-600 dark:text-red-400';
                } finally {
                    // Restaurar estado del botón
                    setTimeout(() => {
                        btnText.classList.remove('hidden');
                        btnLoading.classList.add('hidden');
                        progresoInfo.classList.add('hidden');
                        btnRellenar.disabled = false;
                        progresoTexto.className = 'text-gray-600 dark:text-gray-400';
                    }, 3000);
                }
            });
        });
    </script>
{{-- EVITAR TENER QUE PINCHAR DOS VECES EN LOS ENLACES PARA QUE FUNCIONEN--}}
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>

<!-- Script para gestión de imágenes con pestañas -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Elementos de las pestañas
    const tabUpload = document.getElementById('tab-upload');
    const tabManual = document.getElementById('tab-manual');
    const contentUpload = document.getElementById('content-upload');
    const contentManual = document.getElementById('content-manual');

    // Función para cambiar pestañas
    function cambiarTab(tabActiva, contenidoActivo) {
        // Ocultar todos los contenidos
        contentUpload.classList.add('hidden');
        contentManual.classList.add('hidden');
        
        // Quitar estilos activos de todas las pestañas
        tabUpload.classList.remove('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
        tabUpload.classList.add('border-transparent', 'text-gray-500', 'dark:text-gray-400');
        tabManual.classList.remove('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
        tabManual.classList.add('border-transparent', 'text-gray-500', 'dark:text-gray-400');
        
        // Mostrar contenido activo
        contenidoActivo.classList.remove('hidden');
        
        // Estilo activo para la pestaña seleccionada
        tabActiva.classList.remove('border-transparent', 'text-gray-500', 'dark:text-gray-400');
        tabActiva.classList.add('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
    }

    // Eventos de cambio de pestañas
    tabUpload.addEventListener('click', () => cambiarTab(tabUpload, contentUpload));
    tabManual.addEventListener('click', () => cambiarTab(tabManual, contentManual));

    // Función para manejar la subida de imágenes
    function configurarUpload(tipo) {
        const carpetaSelect = document.getElementById(`carpeta-imagen-${tipo}`);
        const fileInput = document.getElementById(`file-imagen-${tipo}`);
        const btnSeleccionar = document.getElementById(`btn-seleccionar-${tipo}`);
        const dropZone = document.getElementById(`drop-zone-${tipo}`);
        const nombreArchivo = document.getElementById(`nombre-archivo-${tipo}`);
        const preview = document.getElementById(`preview-upload-${tipo}`);
        const rutaImagen = document.getElementById(`ruta-imagen-${tipo}`);
        const rutaCompleta = document.getElementById(`ruta-completa-${tipo}`);

        // Botón de selección de archivo
        btnSeleccionar.addEventListener('click', () => {
            fileInput.click();
        });

        // Cambio de archivo seleccionado
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                procesarArchivo(file, tipo);
            }
        });

        // Drag and drop
        dropZone.addEventListener('click', () => fileInput.click());
        
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
        });

        dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                procesarArchivo(files[0], tipo);
            }
        });

        // Función para procesar el archivo
        function procesarArchivo(file) {
            // Validar que sea una imagen
            if (!file.type.startsWith('image/')) {
                alert('Por favor selecciona un archivo de imagen válido.');
                return;
            }

            // Validar tamaño (máximo 5MB)
            if (file.size > 5 * 1024 * 1024) {
                alert('La imagen es demasiado grande. Máximo 5MB.');
                return;
            }

            // Validar que se haya seleccionado una carpeta
            const carpeta = carpetaSelect.value;
            if (!carpeta) {
                alert('Por favor selecciona una carpeta primero.');
                return;
            }

            // Mostrar nombre del archivo
            nombreArchivo.textContent = file.name;

            // Crear vista previa
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.classList.remove('hidden');
                
                // Mostrar contenedor de vista previa
                const previewContainer = document.getElementById(`preview-container-${tipo}`);
                if (previewContainer) {
                    previewContainer.classList.remove('hidden');
                }
            };
            reader.readAsDataURL(file);

            // Subir imagen al servidor
            subirImagen(file, carpeta, tipo);
        }

        // Función para limpiar campos de imagen
        function limpiarCamposImagen() {
            rutaImagen.value = '';
            rutaCompleta.textContent = '';
            nombreArchivo.textContent = '';
            fileInput.value = '';
            
            // Ocultar contenedor de vista previa
            const previewContainer = document.getElementById(`preview-container-${tipo}`);
            if (previewContainer) {
                previewContainer.classList.add('hidden');
            }
            
            // Limpiar vista previa
            preview.src = '';
            preview.classList.add('hidden');
        }

        // Limpiar campos cuando se cambia la carpeta
        carpetaSelect.addEventListener('change', () => {
            limpiarCamposImagen();
        });

        // Configurar botón de limpiar
        const btnLimpiar = document.getElementById(`btn-limpiar-${tipo}`);
        if (btnLimpiar) {
            btnLimpiar.addEventListener('click', () => {
                limpiarCamposImagen();
            });
        }

        // Función para subir la imagen al servidor
        function subirImagen(file, carpeta, tipo) {
            const formData = new FormData();
            formData.append('imagen', file);
            formData.append('carpeta', carpeta);
            formData.append('_token', '{{ csrf_token() }}');

            // Mostrar indicador de carga
            nombreArchivo.textContent = 'Subiendo...';
            btnSeleccionar.disabled = true;

            fetch('{{ route("admin.imagenes.subir") }}', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Actualizar campos con la respuesta del servidor
                    rutaImagen.value = data.data.ruta_relativa;
                    rutaCompleta.textContent = `Ruta: ${data.data.ruta_relativa}`;
                    nombreArchivo.textContent = '✓ Subida correctamente';
                    
                    // Mostrar contenedor de vista previa
                    const previewContainer = document.getElementById(`preview-container-${tipo}`);
                    if (previewContainer) {
                        previewContainer.classList.remove('hidden');
                    }
                    
                    console.log(`Imagen ${tipo} subida:`, data.data);
                } else {
                    throw new Error(data.message || 'Error al subir la imagen');
                }
            })
            .catch(error => {
                console.error('Error al subir imagen:', error);
                nombreArchivo.textContent = '✗ Error al subir';
                alert(`Error al subir la imagen: ${error.message}`);
                
                // Limpiar campos en caso de error
                rutaImagen.value = '';
                    rutaCompleta.textContent = '';
                    preview.classList.add('hidden');
            })
            .finally(() => {
                btnSeleccionar.disabled = false;
            });
        }

        // Cambio de carpeta
        carpetaSelect.addEventListener('change', () => {
            // Limpiar campos si se cambia la carpeta
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                procesarArchivo(file, tipo);
            }
        });
    }

    // Configurar upload para ambas imágenes
    configurarUpload('grande');
    configurarUpload('pequena');

    // Configurar botones para ver imágenes existentes
    configurarBotonVerImagenes('grande');
    configurarBotonVerImagenes('pequena');

    // Cargar carpetas disponibles al inicio
    cargarCarpetasDisponibles();

    // Inicializar imágenes existentes al cargar la página
    inicializarImagenesExistentes();

    // Función para cargar carpetas disponibles dinámicamente
    function cargarCarpetasDisponibles() {
        fetch('{{ route("admin.imagenes.carpetas") }}')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.length > 0) {
                    // Actualizar ambos selects con las carpetas encontradas
                    actualizarSelectCarpetas('carpeta-imagen-grande', data.data);
                    actualizarSelectCarpetas('carpeta-imagen-pequena', data.data);
                }
            })
            .catch(error => {
                console.error('Error al cargar carpetas:', error);
                // Si hay error, mantener las carpetas por defecto
            });
    }

    // Función para actualizar un select con las carpetas disponibles
    function actualizarSelectCarpetas(selectId, carpetas) {
        const select = document.getElementById(selectId);
        if (!select) return;

        // Mantener la primera opción (Selecciona una carpeta)
        const primeraOpcion = select.querySelector('option[value=""]');
        select.innerHTML = '';
        
        if (primeraOpcion) {
            select.appendChild(primeraOpcion);
        } else {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = 'Selecciona una carpeta';
            select.appendChild(option);
        }

        // Agregar las carpetas encontradas
        carpetas.forEach(carpeta => {
            const option = document.createElement('option');
            option.value = carpeta;
            option.textContent = carpeta.charAt(0).toUpperCase() + carpeta.slice(1);
            select.appendChild(option);
        });
    }

    // Función para inicializar imágenes existentes
    function inicializarImagenesExistentes() {
        // Para imagen grande
        const rutaGrande = document.getElementById('ruta-imagen-grande').value;
        if (rutaGrande) {
            const carpetaGrande = rutaGrande.split('/')[0];
            const selectCarpetaGrande = document.getElementById('carpeta-imagen-grande');
            
            // Seleccionar carpeta automáticamente
            selectCarpetaGrande.value = carpetaGrande;
        }
        
        // Para imagen pequeña
        const rutaPequena = document.getElementById('ruta-imagen-pequena').value;
        if (rutaPequena) {
            const carpetaPequena = rutaPequena.split('/')[0];
            const selectCarpetaPequena = document.getElementById('carpeta-imagen-pequena');
            
            // Seleccionar carpeta automáticamente
            selectCarpetaPequena.value = carpetaPequena;
        }
    }

    // Función para configurar el botón de ver imágenes
    function configurarBotonVerImagenes(tipo) {
        const btnVer = document.getElementById(`btn-ver-imagenes-${tipo}`);
        const carpetaSelect = document.getElementById(`carpeta-imagen-${tipo}`);
        const rutaImagen = document.getElementById(`ruta-imagen-${tipo}`);
        const rutaCompleta = document.getElementById(`ruta-completa-${tipo}`);
        const preview = document.getElementById(`preview-upload-${tipo}`);

        btnVer.addEventListener('click', () => {
            const carpeta = carpetaSelect.value;
            if (!carpeta) {
                alert('Por favor selecciona una carpeta primero.');
                return;
            }
            abrirModalImagenes(carpeta, tipo, rutaImagen, rutaCompleta, preview);
        });
    }

    // Función para abrir el modal de imágenes
    function abrirModalImagenes(carpeta, tipo, rutaImagen, rutaCompleta, preview) {
        const modal = document.getElementById('modalImagenes');
        const nombreCarpeta = document.getElementById('nombre-carpeta-modal');
        const contenido = document.getElementById('contenido-modal-imagenes');

        nombreCarpeta.textContent = carpeta;
        modal.classList.remove('hidden');

        // Cargar imágenes de la carpeta
        cargarImagenesCarpeta(carpeta, contenido, tipo, rutaImagen, rutaCompleta, preview);
    }

    // Función para cargar imágenes de una carpeta
    function cargarImagenesCarpeta(carpeta, contenido, tipo, rutaImagen, rutaCompleta, preview) {
        contenido.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>';

        fetch(`{{ route('admin.imagenes.listar') }}?carpeta=${carpeta}`)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.length > 0) {
                    mostrarImagenesEnModal(data.data, contenido, tipo, rutaImagen, rutaCompleta, preview);
                } else {
                    contenido.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">No hay imágenes en esta carpeta</div>';
                }
            })
            .catch(error => {
                console.error('Error al cargar imágenes:', error);
                contenido.innerHTML = '<div class="text-center text-red-500">Error al cargar las imágenes</div>';
            });
    }

    // Función para mostrar imágenes en el modal
    function mostrarImagenesEnModal(imagenes, contenido, tipo, rutaImagen, rutaCompleta, preview) {
        contenido.innerHTML = '';

        imagenes.forEach(imagen => {
            const div = document.createElement('div');
            div.className = 'relative group cursor-pointer hover:scale-105 transition-transform duration-200';
            div.innerHTML = `
                <img src="${imagen.url}" alt="${imagen.nombre}" 
                     class="w-full h-24 object-cover rounded border-2 border-transparent hover:border-blue-500">
                <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 rounded"></div>
                <div class="absolute bottom-0 left-0 right-0 bg-black bg-opacity-75 text-white text-xs p-1 rounded-b truncate">
                    ${imagen.nombre}
                </div>
            `;

            div.addEventListener('click', () => {
                seleccionarImagenExistente(imagen, tipo, rutaImagen, rutaCompleta, preview);
                cerrarModalImagenes();
            });

            contenido.appendChild(div);
        });
    }

    // Función para seleccionar una imagen existente
    function seleccionarImagenExistente(imagen, tipo, rutaImagen, rutaCompleta, preview) {
        // Actualizar campos
        rutaImagen.value = imagen.ruta;
        rutaCompleta.textContent = `Ruta: ${imagen.ruta}`;

        // Actualizar vista previa
        preview.src = imagen.url;
        preview.classList.remove('hidden');

        // Actualizar nombre del archivo
        const nombreArchivo = document.getElementById(`nombre-archivo-${tipo}`);
        nombreArchivo.textContent = `✓ Seleccionada: ${imagen.nombre}`;

        // Mostrar contenedor de vista previa
        const previewContainer = document.getElementById(`preview-container-${tipo}`);
        if (previewContainer) {
            previewContainer.classList.remove('hidden');
        }

        console.log(`Imagen ${tipo} seleccionada:`, imagen);
    }

    // Función para cerrar el modal de imágenes
    window.cerrarModalImagenes = function() {
        document.getElementById('modalImagenes').classList.add('hidden');
    };

    // Sincronizar campos entre pestañas
    function sincronizarCampos() {
        const rutaGrande = document.getElementById('ruta-imagen-grande').value;
        const rutaPequena = document.getElementById('ruta-imagen-pequena').value;
        
        // Sincronizar imagen grande
        const inputGrande = document.getElementById('imagen-grande-input');
        if (inputGrande) {
            inputGrande.value = rutaGrande || '';
        }
        
        // Sincronizar imagen pequeña
        const inputPequena = document.getElementById('imagen-pequena-input');
        if (inputPequena) {
            inputPequena.value = rutaPequena || '';
        }
        
        // Sincronizar vista previa en pestaña manual
        if (rutaGrande) {
            const previewManualGrande = document.getElementById('preview-imagen-grande');
            if (previewManualGrande) {
                previewManualGrande.src = `{{ asset('images/') }}/${rutaGrande}`;
                previewManualGrande.style.display = 'block';
            }
        }
        
        if (rutaPequena) {
            const previewManualPequena = document.getElementById('preview-imagen-pequena');
            if (previewManualPequena) {
                previewManualPequena.src = `{{ asset('images/') }}/${rutaPequena}`;
                previewManualPequena.style.display = 'block';
            }
        }
    }

    // Sincronizar campos manuales con los campos de upload
    function sincronizarCamposManuales() {
        const inputGrande = document.getElementById('imagen-grande-input');
        const inputPequena = document.getElementById('imagen-pequena-input');
        
        if (inputGrande && inputGrande.value) {
            const rutaGrande = document.getElementById('ruta-imagen-grande');
            if (rutaGrande) {
                rutaGrande.value = inputGrande.value;
            }
        }
        
        if (inputPequena && inputPequena.value) {
            const rutaPequena = document.getElementById('ruta-imagen-pequena');
            if (rutaPequena) {
                rutaPequena.value = inputPequena.value;
            }
        }
    }

    // Sincronizar antes de enviar el formulario
    document.querySelector('form').addEventListener('submit', sincronizarCampos);
    
    // Sincronizar campos manuales cuando se escriba en ellos
    const inputGrande = document.getElementById('imagen-grande-input');
    const inputPequena = document.getElementById('imagen-pequena-input');
    
    if (inputGrande) {
        inputGrande.addEventListener('input', sincronizarCamposManuales);
    }
    
    if (inputPequena) {
        inputPequena.addEventListener('input', sincronizarCamposManuales);
    }
});
</script>

</x-app-layout>
