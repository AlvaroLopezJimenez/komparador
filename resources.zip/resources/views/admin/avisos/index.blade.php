<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">
                    Inicio ->
                </h2>
            </a>
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                Avisos
            </h2>
        </div>
    </x-slot>

    <div class="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="mb-4 flex justify-between items-center">
            <div>
                <label for="filtro-tipo" class="mr-2 text-white">Filtrar por tipo:</label>
                <select id="filtro-tipo" class="border px-8 py-2 rounded">
                    <option value="">Todos</option>
                    <option value="producto">Producto</option>
                    <option value="oferta">Oferta</option>
                    <option value="tienda">Tienda</option>
                </select>
            </div>
        </div>

        <div class="bg-white shadow rounded-lg overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha aviso</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200" id="tabla-avisos">
                    @foreach ($avisos as $aviso)
                    <tr data-tipo="{{ $aviso['tipo'] }}" class="hover:bg-gray-100 dark:hover:bg-gray-300 transition-colors">
                        <td class="px-6 py-4">{{ $aviso['nombre'] }}</td>
                        <td class="px-6 py-4 capitalize">{{ $aviso['tipo'] }}</td>
                        <td class="px-6 py-4">{{ $aviso['aviso'] }}</td>
                        <td class="px-6 py-4 space-x-2">
                            <a href="{{ $aviso['editar'] }}" class="text-blue-500 hover:underline">Editar</a>
                            <button type="button"
                                class="text-gray-600 hover:underline"
                                onclick="verAnotaciones('{{ addslashes($aviso['anotaciones']) }}')">
                                Ver
                            </button>
                            <form action="{{ $aviso['eliminar'] }}" method="POST" class="inline-block"
                                onsubmit="return confirm('¿Seguro que quieres eliminar el aviso?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        @if ($avisos->isEmpty())
        <p class="mt-6 text-center text-gray-500">No hay avisos activos.</p>
        @endif
    </div>

    <div id="modal-anotaciones" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 max-w-md w-full">
            <h2 class="text-lg font-semibold mb-4">Anotaciones</h2>
            <div id="contenido-anotaciones" class="whitespace-pre-line text-gray-700"></div>
            <div class="mt-6 text-right">
                <button onclick="cerrarModal()" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Cerrar</button>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('filtro-tipo').addEventListener('change', function() {
            const tipo = this.value;
            document.querySelectorAll('#tabla-avisos tr').forEach(tr => {
                tr.style.display = !tipo || tr.dataset.tipo === tipo ? '' : 'none';
            });
        });

        function verAnotaciones(texto) {
            document.getElementById('contenido-anotaciones').textContent = texto || 'Sin anotaciones.';
            document.getElementById('modal-anotaciones').classList.remove('hidden');
        }

        function cerrarModal() {
            document.getElementById('modal-anotaciones').classList.add('hidden');
        }
    </script>

    {{-- EVITAR TENER QUE PINCHAR DOS VECES EN LOS ENLACES PARA QUE FUNCIONEN--}}
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>
</x-app-layout>