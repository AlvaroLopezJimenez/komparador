<x-app-layout>
<x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('home') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Web -></h2>
            </a>
                <h2 class="font-semibold text-xl text-white leading-tight">Panel de administración</h2>

        </div>
    </x-slot>

    <div class="py-10 max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

        {{-- Sección Productos --}}
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Productos</h3>
            <div class="space-y-2">
                <a href="{{ route('admin.productos.index') }}"
                    class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 rounded">
                    ➜ Gestionar productos
                </a>
                <a href="{{ route('admin.productos.create') }}"
                    class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 rounded">
                    ➕ Añadir producto
                </a>
                <div class="space-y-2">
                    <button
                        onclick="document.getElementById('modal-precios').classList.remove('hidden')"
                        class="block bg-indigo-500 hover:bg-indigo-600 text-white text-center py-2 rounded w-full">
                        🔄 Ejecuciones histórico de precios
                    </button>
                </div>
                <div class="space-y-2">
                    <button
                        onclick="document.getElementById('modal-clicks').classList.remove('hidden')"
                        class="block bg-orange-500 hover:bg-orange-600 text-white text-center py-2 rounded w-full">
                        📊 Actualizar clicks de productos
                    </button>
                    
                </div>
            </div>
        </div>

        {{-- Sección Ofertas --}}
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Ofertas</h3>
            <div class="space-y-2">
                <a href="{{ route('admin.ofertas.todas') }}"
                    class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 rounded">
                    ➜ Gestionar ofertas
                </a>
                <a href="{{ route('admin.ofertas.create.formularioGeneral') }}"
                    class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 rounded">
                    ➕ Añadir oferta
                </a>
                <button
                    onclick="document.getElementById('modal-precios-ofertas').classList.remove('hidden')"
                    class="block bg-indigo-500 hover:bg-indigo-600 text-white text-center py-2 rounded w-full">
                    🔄 Ejecuciones histórico de precios
                </button>
                <button
                    onclick="document.getElementById('modal-clicks-ofertas').classList.remove('hidden')"
                    class="block bg-orange-500 hover:bg-orange-600 text-white text-center py-2 rounded w-full">
                    📊 Actualizar clicks de ofertas
                </button>
                <button
                    onclick="document.getElementById('modal-scraper-ofertas').classList.remove('hidden')"
                    class="block bg-purple-500 hover:bg-purple-600 text-white text-center py-2 rounded w-full">
                    🕷️ Ejecuciones Scraper
                </button>
                
            </div>
        </div>

        {{-- Sección Tiendas --}}
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Tiendas</h3>
            <div class="space-y-2">
                <a href="{{ route('admin.tiendas.index') }}" class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 rounded">
                    ➜ Gestionar tiendas
                </a>
                <a href="{{ route('admin.tiendas.create') }}" class="block bg-green-500 hover:bg-green-600 text-white text-center py-2 rounded">
                    ➕ Añadir tienda
                </a>
                
            </div>
        </div>

    </div>

    <!-- SEGUNDA FILA -->
    <div class="py-10 max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {{-- Sección Categorías --}}
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Categorias</h3>
            <div class="space-y-2">
                <a href="{{ route('admin.categorias.index') }}"
                    class="block bg-blue-500 hover:bg-blue-600 text-white text-center py-2 rounded">
                    ➜ Gestionar categorías
                </a>
                <button
                        onclick="document.getElementById('modal-clicks-categorias').classList.remove('hidden')"
                        class="block bg-orange-500 hover:bg-orange-600 text-white text-center py-2 rounded w-full">
                        📊 Actualizar clicks de categorías
                    </button>
                <button
                        onclick="document.getElementById('modal-precios-hot').classList.remove('hidden')"
                        class="block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded w-full">
                        🔥 Precios Hot
                    </button>
            </div>
        </div>

        {{-- Sección Ajustes --}}
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Ajustes</h3>
            <div class="space-y-2">
                <a href="{{ route('admin.avisos.index') }}"
                    class="block relative bg-yellow-600 hover:bg-yellow-600 text-white text-center py-2 rounded">
                    ⚠️ Avisos
                    @if ($totalAvisos > 0)
                    <span
                        class="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-600 text-xs text-white rounded-full px-2 py-0.5">
                        {{ $totalAvisos }}
                    </span>
                    @endif
                </a>
            </div>
        </div>
    </div>




<script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>

{{-- Modal para elegir cómo ejecutar (Historico productos)--}}
<div id="modal-precios" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Actualizar historial de precios de cada productos</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso?</p>
        <div class="space-y-2">
            <a href="{{ url('/panel-privado/productos/historico-precios/ejecutar?token=' . env('TOKEN_ACTUALIZAR_PRECIOS')) }}"
                class="block w-full bg-green-700 hover:bg-green-800 text-white text-center py-2 rounded">
                ▶ Ejecutar en segundo plano
            </a>
            <a href="{{ route('admin.precios.actualizar.ver') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>

            <a href="{{ route('admin.productos.historico.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>
            <button onclick="document.getElementById('modal-precios').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Historico ofertas) --}}
<div id="modal-precios-ofertas" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Actualizar historial de precios de ofertas</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso?</p>
        <div class="space-y-2">
            <a href="{{ route('admin.ofertas.historico.ejecutar', ['token' => env('TOKEN_ACTUALIZAR_PRECIOS')]) }}"
                class="block w-full bg-green-700 hover:bg-green-800 text-white text-center py-2 rounded">
                ▶ Ejecutar en segundo plano
            </a>
            <a href="{{ route('admin.ofertas.historico.ver') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>

            <a href="{{ route('admin.ofertas.historico.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>

            <button onclick="document.getElementById('modal-precios-ofertas').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Scraper ofertas) --}}
<div id="modal-scraper-ofertas" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Ejecuciones Scraper de Ofertas</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso de scraping?</p>
        <div class="space-y-2">
            
            <a href="{{ route('admin.scraping.diagnostico') }}"
                class="block bg-orange-600 hover:bg-orange-700 text-white text-center py-2 rounded">
                🔍 Diagnóstico del Sistema
            </a>
        
            <a href="{{ route('admin.scraping.ejecucion-tiempo-real') }}"
                class="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded">
                ⚡ Ejecución en Tiempo Real
            </a>
            <a href="{{ route('admin.ofertas.scraper.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>

            <a href="{{ route('admin.scraping.test') }}"
                class="block bg-indigo-600 hover:bg-indigo-700 text-white text-center py-2 rounded">
                🔍 URL -> HTML
            </a>

            <a href="{{ route('admin.scraping.test.precio') }}"
                class="block bg-purple-600 hover:bg-purple-700 text-white text-center py-2 rounded">
                💰 URL -> Precio
            </a>

            
            <a href="{{ url('/panel-privado/ofertas/scraper/ejecutar-segundo-plano?token=' . env('TOKEN_ACTUALIZAR_PRECIOS')) }}"
                class="block w-full bg-green-700 hover:bg-green-800 text-white text-center py-2 rounded">
                ▶ Ejecutar en segundo plano
            </a>


            <button onclick="document.getElementById('modal-scraper-ofertas').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Actualización de clicks) --}}
<div id="modal-clicks" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Actualizar Clicks de Productos</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso de actualización de clicks?</p>
        <div class="space-y-2">
            <a href="{{ route('admin.productos.actualizar.clicks.ejecutar') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>
            <a href="{{ route('admin.productos.actualizar.clicks.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>
            <button onclick="document.getElementById('modal-clicks').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Actualización de clicks de categorías) --}}
<div id="modal-clicks-categorias" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Actualizar Clicks de Categorías</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso de actualización de clicks de categorías?</p>
        <p class="text-sm text-gray-500 dark:text-gray-400">Nota: Se contarán los clicks de los últimos 7 días de las ofertas de productos pertenecientes a cada categoría y sus subcategorías.</p>
        <div class="space-y-2">
            <a href="{{ route('admin.categorias.actualizar.clicks.ejecutar') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>
            <a href="{{ route('admin.categorias.actualizar.clicks.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>
            <button onclick="document.getElementById('modal-clicks-categorias').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Actualización de clicks de ofertas) --}}
<div id="modal-clicks-ofertas" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Actualizar Clicks de Ofertas</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso de actualización de clicks de ofertas?</p>
        <p class="text-sm text-gray-500 dark:text-gray-400">Nota: Se contarán los clicks de los últimos 7 días de cada oferta desde la tabla clicks.</p>
        <div class="space-y-2">
            <a href="{{ route('admin.ofertas.actualizar.clicks.ejecutar') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>
            <a href="{{ route('admin.ofertas.actualizar.clicks.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>
            <button onclick="document.getElementById('modal-clicks-ofertas').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>

{{-- Modal para elegir cómo ejecutar (Precios Hot) --}}
<div id="modal-precios-hot" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white dark:bg-gray-900 rounded-lg shadow-lg p-6 w-full max-w-md space-y-4">
        <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Precios Hot</h2>
        <p class="text-gray-600 dark:text-gray-300">¿Cómo quieres ejecutar el proceso de cálculo de precios hot?</p>
        <p class="text-sm text-gray-500 dark:text-gray-400">Nota: Se calcularán los productos con mejores ofertas respecto a su precio medio del último mes.</p>
        <div class="space-y-2">
            <a href="{{ url('/panel-privado/precios-hot/ejecutar-segundo-plano?token=' . env('TOKEN_ACTUALIZAR_PRECIOS')) }}"
                class="block w-full bg-green-700 hover:bg-green-800 text-white text-center py-2 rounded">
                ▶ Ejecutar en segundo plano
            </a>
            <a href="{{ route('admin.precios-hot.ejecutar') }}"
                class="block text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">
                👀 Ver ejecución en tiempo real
            </a>
            <a href="{{ route('admin.precios-hot.ejecuciones') }}"
                class="block bg-gray-600 hover:bg-gray-700 text-white text-center py-2 rounded">
                📋 Ver historial de ejecuciones
            </a>
            <button onclick="document.getElementById('modal-precios-hot').classList.add('hidden')"
                class="w-full block bg-red-500 hover:bg-red-600 text-white text-center py-2 rounded">
                Cancelar
            </button>
        </div>
    </div>
</div>
</x-app-layout>