<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Testing de Scraping') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <!-- Formulario de testing -->
                    <div class="mb-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Probar URL de Scraping</h3>
                        
                        <form id="testForm" class="space-y-4">
                            @csrf
                            <div>
                                <label for="url" class="block text-sm font-medium text-gray-700 mb-2">
                                    URL a probar
                                </label>
                                <input type="url" 
                                       id="url" 
                                       name="url" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                       placeholder="https://ejemplo.com/producto"
                                       required>
                            </div>
                            
                            <div class="flex items-center space-x-4">
                                <button type="submit" 
                                        id="btnProcesar"
                                        class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 focus:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                                    </svg>
                                    Procesar URL
                                </button>
                                
                                <div id="loading" class="hidden">
                                    <div class="flex items-center">
                                        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        <span class="text-sm text-gray-600">Procesando...</span>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Resultados -->
                    <div id="resultados" class="hidden">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">Resultado del Scraping</h3>
                        
                        <!-- Información de la URL -->
                        <div id="urlInfo" class="mb-4 p-3 bg-gray-50 rounded-md">
                            <span class="text-sm font-medium text-gray-700">URL procesada: </span>
                            <span id="urlProcesada" class="text-sm text-gray-600"></span>
                        </div>
                        
                        <!-- Área de HTML -->
                        <div class="mb-4">
                            <label for="htmlResult" class="block text-sm font-medium text-gray-700 mb-2">
                                HTML obtenido
                                <button type="button" 
                                        id="btnCopiar" 
                                        class="ml-2 inline-flex items-center px-2 py-1 bg-gray-600 border border-transparent rounded text-xs text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">
                                    <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                    </svg>
                                    Copiar
                                </button>
                            </label>
                            <textarea id="htmlResult" 
                                      class="w-full h-96 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 font-mono text-xs"
                                      readonly
                                      placeholder="El HTML aparecerá aquí..."></textarea>
                        </div>
                        
                        <!-- Estadísticas -->
                        <div id="estadisticas" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="p-3 bg-blue-50 rounded-md">
                                <div class="text-sm font-medium text-blue-800">Tamaño del HTML</div>
                                <div id="tamanoHTML" class="text-lg font-bold text-blue-900">0 bytes</div>
                            </div>
                            <div class="p-3 bg-green-50 rounded-md">
                                <div class="text-sm font-medium text-green-800">Líneas de código</div>
                                <div id="lineasHTML" class="text-lg font-bold text-green-900">0</div>
                            </div>
                            <div class="p-3 bg-purple-50 rounded-md">
                                <div class="text-sm font-medium text-purple-800">Tiempo de respuesta</div>
                                <div id="tiempoRespuesta" class="text-lg font-bold text-purple-900">0ms</div>
                            </div>
                        </div>
                    </div>

                    <!-- Mensaje de error -->
                    <div id="error" class="hidden mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
                        <div class="flex">
                            <svg class="w-5 h-5 text-red-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
                            </svg>
                            <div>
                                <h3 class="text-sm font-medium text-red-800">Error en el procesamiento</h3>
                                <div id="errorMensaje" class="mt-1 text-sm text-red-700"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('testForm');
            const btnProcesar = document.getElementById('btnProcesar');
            const loading = document.getElementById('loading');
            const resultados = document.getElementById('resultados');
            const error = document.getElementById('error');
            const htmlResult = document.getElementById('htmlResult');
            const urlProcesada = document.getElementById('urlProcesada');
            const errorMensaje = document.getElementById('errorMensaje');
            const btnCopiar = document.getElementById('btnCopiar');
            const tamanoHTML = document.getElementById('tamanoHTML');
            const lineasHTML = document.getElementById('lineasHTML');
            const tiempoRespuesta = document.getElementById('tiempoRespuesta');

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const url = document.getElementById('url').value;
                if (!url) return;

                // Mostrar loading
                btnProcesar.disabled = true;
                loading.classList.remove('hidden');
                resultados.classList.add('hidden');
                error.classList.add('hidden');

                const inicio = Date.now();

                // Hacer petición AJAX
                fetch('{{ route("admin.scraping.test.procesar") }}', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify({ url: url })
                })
                .then(response => response.json())
                .then(data => {
                    const tiempo = Date.now() - inicio;
                    
                    if (data.success) {
                        // Mostrar resultados
                        urlProcesada.textContent = data.url;
                        htmlResult.value = data.html;
                        
                        // Calcular estadísticas
                        const tamano = new Blob([data.html]).size;
                        const lineas = data.html.split('\n').length;
                        
                        tamanoHTML.textContent = formatBytes(tamano);
                        lineasHTML.textContent = lineas.toLocaleString();
                        tiempoRespuesta.textContent = tiempo + 'ms';
                        
                        resultados.classList.remove('hidden');
                    } else {
                        // Mostrar error
                        errorMensaje.textContent = data.error;
                        error.classList.remove('hidden');
                    }
                })
                .catch(err => {
                    errorMensaje.textContent = 'Error de conexión: ' + err.message;
                    error.classList.remove('hidden');
                })
                .finally(() => {
                    // Ocultar loading
                    btnProcesar.disabled = false;
                    loading.classList.add('hidden');
                });
            });

            // Función para copiar HTML
            btnCopiar.addEventListener('click', function() {
                htmlResult.select();
                htmlResult.setSelectionRange(0, 99999); // Para móviles
                document.execCommand('copy');
                
                // Feedback visual
                const originalText = btnCopiar.innerHTML;
                btnCopiar.innerHTML = '<svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>Copiado';
                btnCopiar.classList.remove('bg-gray-600', 'hover:bg-gray-700');
                btnCopiar.classList.add('bg-green-600', 'hover:bg-green-700');
                
                setTimeout(() => {
                    btnCopiar.innerHTML = originalText;
                    btnCopiar.classList.remove('bg-green-600', 'hover:bg-green-700');
                    btnCopiar.classList.add('bg-gray-600', 'hover:bg-gray-700');
                }, 2000);
            });

            // Función para formatear bytes
            function formatBytes(bytes, decimals = 2) {
                if (bytes === 0) return '0 Bytes';
                
                const k = 1024;
                const dm = decimals < 0 ? 0 : decimals;
                const sizes = ['Bytes', 'KB', 'MB', 'GB'];
                
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                
                return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
            }
        });
    </script>
</x-app-layout>
