<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Inicio -></h2>
            </a>
            <a href="{{ route('admin.tiendas.index') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Tiendas -></h2>
            </a>
            <h2 class="font-semibold text-xl text-white leading-tight">
                {{ $tienda->exists ? 'Editar tienda' : 'Añadir tienda' }}
            </h2>
        </div>
    </x-slot>

    <div class="max-w-5xl mx-auto py-10 px-4 space-y-8 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-md">
        @if ($errors->any())
        <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
            <ul class="list-disc pl-5">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
        <form method="POST" action="{{ $tienda->exists ? route('admin.tiendas.update', $tienda) : route('admin.tiendas.store') }}">
            @csrf
            @if($tienda->exists)
            @method('PUT')
            @endif

            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Información de la tienda</legend>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre *</label>
                        <input type="text" name="nombre" required
                            value="{{ old('nombre', $tienda->nombre) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @error('nombre')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">URL</label>
                        <input type="text" name="url"
                            value="{{ old('url', $tienda->url) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Envío gratis</label>
                        <input type="text" name="envio_gratis"
                            value="{{ old('envio_gratis', $tienda->envio_gratis) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Envío normal</label>
                        <input type="text" name="envio_normal"
                            value="{{ old('envio_normal', $tienda->envio_normal) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>



                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Ruta del logo</label>
                        <input type="text" name="url_imagen"
                            value="{{ old('url_imagen', $tienda->url_imagen) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @if($tienda->url_imagen)
                        <div class="mt-3">
                            <img src="{{ asset('images/' .$tienda->url_imagen) }}" alt="Logo tienda"
                                class="max-h-10 rounded shadow border">
                        </div>
                        @endif
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Opiniones</label>
                        <input type="number" name="opiniones" min="0"
                            value="{{ old('opiniones', $tienda->opiniones ?? 0) }}" required

                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Puntuación (0 - 5)</label>
                        <input type="number" step="0.1" min="0" max="5" name="puntuacion"
                            value="{{ old('puntuacion', $tienda->puntuacion ?? 0) }}" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">URL de opiniones</label>
                        <input type="text" name="url_opiniones"
                            value="{{ old('url_opiniones', $tienda->url_opiniones) }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>
                </div>
            </fieldset>

            {{-- ARBOL DE LAS CATEGORIAS CON SUS RESPECTIVAS COMISIONES--}}
            <script src="//unpkg.com/alpinejs" defer></script>
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
    <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Comisiones por categoría</legend>

    <div id="arbol-comisiones" class="space-y-3">
        @php
            function renderCategorias($categorias, $comisiones, $nivel = 0, $padreId = null) {
                foreach ($categorias as $categoria) {
                    $valor = old("comisiones.{$categoria->id}", $comisiones[$categoria->id] ?? '');
                    $hasChildren = $categoria->children && $categoria->children->count();
                    $margin = $nivel * 4;
        @endphp

        <div class="ml-{{ $margin }}" x-data="{ open{{ $categoria->id }}: false }">
            <div class="flex items-center gap-2">
    @if($hasChildren)
        <button type="button"
            @click="open{{ $categoria->id }} = !open{{ $categoria->id }}"
            class="w-7 h-7 flex items-center justify-center text-white bg-pink-600 hover:bg-pink-700 rounded-full transition"
            :aria-label="open{{ $categoria->id }} ? 'Contraer' : 'Expandir'">
            <span x-text="open{{ $categoria->id }} ? '-' : '+'"></span>
        </button>
    @else
        <span class="w-7 h-7 inline-block"></span>
    @endif

    <label class="flex items-center gap-2 text-sm font-medium text-gray-800 dark:text-gray-200">
        <span>{{ $categoria->nombre }}</span>
        <input
            type="number"
            step="0.01"
            min="0"
            max="100"
            name="comisiones[{{ $categoria->id }}]"
            data-id="{{ $categoria->id }}"
            @if ($padreId)
                data-parent-id="{{ $padreId }}"
            @endif
            class="comision-input px-2 py-1 w-24 bg-gray-100 dark:bg-gray-700 text-white border rounded"
            value="{{ $valor }}"
        >
        <span class="text-sm text-gray-500 dark:text-gray-400">%</span>
    </label>
</div>


            @if ($hasChildren)
                <div class="space-y-2 mt-2 ml-4" x-show="open{{ $categoria->id }}" x-cloak>
                    @php renderCategorias($categoria->children, $comisiones, $nivel + 1, $categoria->id); @endphp
                </div>
            @endif
        </div>

        @php
                }
            }

            renderCategorias($categorias, $comisiones);
        @endphp
    </div>
</fieldset>



            {{-- PONER AVISO --}}
            <fieldset class="space-y-2 border border-gray-300 dark:border-gray-600 rounded-xl p-4">
                <legend class="text-sm font-semibold text-gray-700 dark:text-gray-200 px-2">Aviso de revisión</legend>

                @if ($tienda && $tienda->aviso)
                <p class="text-sm text-gray-800 dark:text-gray-100">
                    Fecha actual de aviso: <strong>{{ \Carbon\Carbon::parse($tienda->aviso)->format('d/m/Y H:i') }}</strong>
                </p>

                <label class="inline-flex items-center text-sm text-red-600 font-medium">
                    <input type="checkbox" name="eliminar_aviso" id="eliminar-aviso" class="mr-2">
                    Eliminar este aviso
                </label>
                @else
                <p class="text-sm text-gray-500 dark:text-gray-400">Actualmente no hay aviso configurado.</p>
                @endif

                <div class="flex gap-2">
                    <input type="number" name="aviso_cantidad" placeholder="Cantidad"
                        value="{{ old('aviso_cantidad') }}"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                    <select name="aviso_unidad"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                        <option value="">Unidad</option>
                        <option value="days" {{ old('aviso_unidad') == 'days' ? 'selected' : '' }}>Días</option>
                        <option value="weeks" {{ old('aviso_unidad') == 'weeks' ? 'selected' : '' }}>Semanas</option>
                        <option value="months" {{ old('aviso_unidad') == 'months' ? 'selected' : '' }}>Meses</option>
                        <option value="years" {{ old('aviso_unidad') == 'years' ? 'selected' : '' }}>Años</option>
                    </select>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const checkbox = document.getElementById('eliminar-aviso');
                        const cantidadInput = document.querySelector('input[name="aviso_cantidad"]');
                        const unidadSelect = document.querySelector('select[name="aviso_unidad"]');

                        if (checkbox) {
                            checkbox.addEventListener('change', () => {
                                if (checkbox.checked) {
                                    cantidadInput.value = '';
                                    unidadSelect.value = '';
                                }
                            });
                        }
                    });
                </script>
            </fieldset>

            {{-- ANOTACIONES INTERNAS --}}
            <div class="md:col-span-2">
                <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Anotaciones internas</label>
                <textarea name="anotaciones_internas" rows="4"
                    class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">{{ old('anotaciones_internas', $tienda->anotaciones_internas ?? '') }}</textarea>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                    class="inline-flex items-center bg-pink-600 hover:bg-pink-700 text-white font-semibold text-base px-6 py-3 rounded-md shadow-md transition">
                    {{ $tienda->exists ? 'Actualizar tienda' : 'Crear tienda' }}
                </button>
            </div>
        </form>
    </div>
    <script>
        document.querySelector('form').addEventListener('submit', function(e) {
            const inputs = this.querySelectorAll('[required]');
            let valido = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    valido = false;
                    input.classList.add('border-red-500');
                } else {
                    input.classList.remove('border-red-500');
                }
            });

            if (!valido) {
                e.preventDefault();
                alert('Por favor, completa todos los campos obligatorios.');
            }
        });
    </script>

    {{-- SCRIPT PARA SINCRONIZAR LAS COMISIONES ESCRITAS DE PADRE A HIJO--}}
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const inputs = document.querySelectorAll('.comision-input');

        // Si cambias un padre, cambia también sus hijos
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                const valor = input.value;
                const id = input.dataset.id;

                const hijos = Array.from(inputs).filter(child =>
                    child.dataset.parentId === id
                );

                hijos.forEach(hijo => {
                    hijo.value = valor;
                    hijo.dispatchEvent(new Event('input')); // propaga en cascada
                });
            });
        });
    });
</script>

</x-app-layout>