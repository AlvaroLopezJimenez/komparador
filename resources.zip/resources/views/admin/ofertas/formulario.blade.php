<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Inicio -></h2>
            </a>
            @if($producto)
            <a href="{{ route('admin.productos.index') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Productos -></h2>
            </a>
            @endif
            <a href="{{ route('admin.ofertas.todas') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Ofertas -></h2>
            </a>
            <h2 class="font-semibold text-xl text-white leading-tight">
                {{ $oferta ? 'Editar oferta' : 'Añadir oferta' }}
            </h2>
        </div>
    </x-slot>

    <div class="max-w-5xl mx-auto py-10 px-4 space-y-8 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-md">
        <form method="POST"
                            action="{{ $oferta ? route('admin.ofertas.update', $oferta) : route('admin.ofertas.store') }}">
            @csrf
            @if($oferta)
            @method('PUT')
            @endif

            {{-- INFORMACIÓN GENERAL --}}
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-6 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Información general</legend>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {{-- PRODUCTO --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Producto *</label>
                        <div class="flex gap-2">
                            <input type="hidden" name="producto_id" id="producto_id" value="{{ old('producto_id', $producto->id ?? '') }}">
                            <input type="text" id="producto_nombre"
                                value="{{ old('producto_nombre', isset($producto) ? $producto->nombre . ' - ' . $producto->marca . ' - ' . $producto->modelo . ' - ' . $producto->talla : '') }}"
                                readonly
                                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                            <button type="button" onclick="abrirSelector('producto')"
                                class="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600">Buscar</button>
                        </div>
                        @error('producto_id')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- TIENDA --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Tienda *</label>
                        <div class="flex gap-2">
                            <input type="hidden" name="tienda_id" id="tienda_id" value="{{ old('tienda_id', $oferta->tienda_id ?? '') }}">
                            <input type="text" id="tienda_nombre" readonly
                                value="{{ old('tienda_nombre', $oferta->tienda->nombre ?? '') }}"
                                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                            <button type="button" onclick="abrirSelector('tienda')"
                                class="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600">Buscar</button>
                        </div>
                        @error('tienda_id')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- UNIDADES --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Unidades *</label>
                        <input type="number" name="unidades" min="1" required
                            value="{{ old('unidades', $oferta->unidades ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    {{-- PRECIO TOTAL --}}
<div>
    <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Precio total (€) *</label>
    <div class="flex gap-2">
        <div class="flex-1">
            <input type="number" name="precio_total" step="0.01" required
                value="{{ old('precio_total', $oferta->precio_total ?? '') }}"
                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
        </div>
        <button type="button" id="btnObtenerPrecio" onclick="obtenerPrecioAutomatico()"
    class="h-full px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded transition disabled:opacity-50 disabled:cursor-not-allowed">
    🔍 Obtener Precio
</button>
    </div>
</div>

                    {{-- TIEMPO DE ACTUALIZACION DE PRECIO --}}
                    @php
                    $frecuencia = $oferta->frecuencia_actualizar_precio_minutos ?? 1440;
                    if ($frecuencia % 1440 === 0) {
                    $frecuencia_valor = $frecuencia / 1440;
                    $frecuencia_unidad = 'dias';
                    } elseif ($frecuencia % 60 === 0) {
                    $frecuencia_valor = $frecuencia / 60;
                    $frecuencia_unidad = 'horas';
                    } else {
                    $frecuencia_valor = $frecuencia;
                    $frecuencia_unidad = 'minutos';
                    }
                    @endphp
                    <div class="col-span-1">
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Actualizar cada *</label>
                        <div class="flex gap-2">
                            <input type="number" step="0.1" min="0.1" name="frecuencia_valor" required
                                value="{{ old('frecuencia_valor', $frecuencia_valor ?? 1) }}"
                                class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                            <select name="frecuencia_unidad"
                                class="px-3 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                                <option value="minutos" {{ old('frecuencia_unidad', $frecuencia_unidad ?? '') == 'minutos' ? 'selected' : '' }}>Minutos</option>
                                <option value="horas" {{ old('frecuencia_unidad', $frecuencia_unidad ?? '') == 'horas' ? 'selected' : '' }}>Horas</option>
                                <option value="dias" {{ old('frecuencia_unidad', $frecuencia_unidad ?? '') == 'dias' ? 'selected' : '' }}>Días</option>
                            </select>

                        </div>
                    </div>

                    {{-- PRECIO UNIDAD --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Precio por unidad (€) *</label>
                        <input type="number" name="precio_unidad" step="0.0001" required
                            value="{{ old('precio_unidad', $oferta->precio_unidad ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @error('precio_unidad')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    {{-- URL --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">URL de la oferta *</label>
                        <input type="url" name="url" required
                            value="{{ old('url', $oferta->url ?? '') }}"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                    </div>

                    {{-- VARIANTE --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Variante</label>
                        <input type="text" name="variante" 
                            value="{{ old('variante', $oferta->variante ?? '') }}"
                            placeholder="Número, texto, etc. (opcional)"
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                        @error('variante')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>


                    {{-- MOSTRAR --}}
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">¿Mostrar en web? *</label>
                        <div class="flex gap-4 mt-2">
                            <label>
                                <input type="radio" name="mostrar" value="si" required
                                    {{ old('mostrar', $oferta->mostrar ?? '') === 'si' ? 'checked' : '' }}>
                                <span class="ml-1 text-gray-700 dark:text-gray-200">Sí</span>
                            </label>
                            <label>
                                <input type="radio" name="mostrar" value="no"
                                    {{ old('mostrar', $oferta->mostrar ?? '') === 'no' ? 'checked' : '' }}>
                                <span class="ml-1 text-gray-700 dark:text-gray-200">No</span>
                            </label>
                        </div>
                        @error('mostrar')
                        <p class="text-sm text-red-500 mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
            </fieldset>

            {{-- PONER AVISO --}}
            <fieldset class="space-y-2 border border-gray-300 dark:border-gray-600 rounded-xl p-4">
                <legend class="text-sm font-semibold text-gray-700 dark:text-gray-200 px-2">Aviso de revisión</legend>

                @if ($oferta && $oferta->aviso)
                <p class="text-sm text-gray-800 dark:text-gray-100">
                    Fecha actual de aviso: <strong>{{ \Carbon\Carbon::parse($oferta->aviso)->format('d/m/Y H:i') }}</strong>
                </p>

                <label class="inline-flex items-center text-sm text-red-600 font-medium">
                    <input type="checkbox" name="eliminar_aviso" id="eliminar-aviso" class="mr-2">
                    Eliminar este aviso
                </label>
                @else
                <p class="text-sm text-gray-500 dark:text-gray-400">Actualmente no hay aviso configurado.</p>
                @endif

                <div class="flex gap-2">
                    <input type="number" name="aviso_cantidad" placeholder="Cantidad"
                        value="{{ old('aviso_cantidad') }}"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                    <select name="aviso_unidad"
                        class="w-1/2 rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white">
                        <option value="">Unidad</option>
                        <option value="days" {{ old('aviso_unidad') == 'days' ? 'selected' : '' }}>Días</option>
                        <option value="weeks" {{ old('aviso_unidad') == 'weeks' ? 'selected' : '' }}>Semanas</option>
                        <option value="months" {{ old('aviso_unidad') == 'months' ? 'selected' : '' }}>Meses</option>
                        <option value="years" {{ old('aviso_unidad') == 'years' ? 'selected' : '' }}>Años</option>
                    </select>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const checkbox = document.getElementById('eliminar-aviso');
                        const cantidadInput = document.querySelector('input[name="aviso_cantidad"]');
                        const unidadSelect = document.querySelector('select[name="aviso_unidad"]');

                        if (checkbox) {
                            checkbox.addEventListener('change', () => {
                                if (checkbox.checked) {
                                    cantidadInput.value = '';
                                    unidadSelect.value = '';
                                }
                            });
                        }
                    });
                </script>
            </fieldset>


            {{-- ANOTACIONES INTERNAS --}}
            <div class="col-span-1 md:col-span-2">
                <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Anotaciones internas</label>
                <textarea name="anotaciones_internas" rows="4"
                    class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">{{ old('anotaciones_internas', $oferta->anotaciones_internas ?? '') }}</textarea>
            </div>


            {{-- GUARDAR --}}
            <div class="flex justify-end">
                <button type="submit"
                    class="inline-flex items-center bg-pink-600 hover:bg-pink-700 text-white font-semibold text-base px-6 py-3 rounded-md shadow-md transition">
                    Guardar oferta
                </button>
            </div>
        </form>
    </div>

    {{-- MODAL SELECCIÓN ACTUALIZADO --}}
    <div id="modalSelector" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full shadow-lg relative">
            <button onclick="cerrarSelector()" class="absolute top-2 right-3 text-gray-600 dark:text-gray-200">✕</button>
            <h3 id="selectorTitulo" class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Seleccionar</h3>

            <form onsubmit="buscarSelector(event)" class="flex gap-2 mb-4">
                <input type="text" id="selectorBusqueda" name="q"
                    placeholder="Buscar por nombre, marca, modelo, talla..."
                    class="w-full px-3 py-2 rounded border bg-gray-100 dark:bg-gray-700 text-white">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Buscar
                </button>
            </form>

            <div id="selectorResultados" class="max-h-64 overflow-y-auto divide-y divide-gray-300 dark:divide-gray-600"></div>
        </div>
    </div>


    <script>
        let tipoSeleccion = '';
        let resultadosData = [];

        async function buscarSelector(e) {
            e.preventDefault();
            const query = document.getElementById('selectorBusqueda').value;
            const url = `/panel-privado/buscador-${tipoSeleccion}?q=${encodeURIComponent(query)}`;
            const response = await fetch(url);
            resultadosData = await response.json();
            mostrarResultados();
        }

        function abrirSelector(tipo) {
            tipoSeleccion = tipo;
            document.getElementById('modalSelector').classList.remove('hidden');
            document.getElementById('selectorTitulo').textContent = tipo === 'producto' ? 'Seleccionar producto' : 'Seleccionar tienda';
            fetch(`/panel-privado/buscador-${tipo}`).then(r => r.json()).then(data => {
                resultadosData = data;
                mostrarResultados();
            });
        }

        function cerrarSelector() {
            document.getElementById('modalSelector').classList.add('hidden');
        }

        function mostrarResultados(filtro = '') {
            const contenedor = document.getElementById('selectorResultados');
            contenedor.innerHTML = '';

            resultadosData.forEach(item => {
                const text = tipoSeleccion === 'producto' ?
                    `${item.nombre} - ${item.marca} - ${item.modelo} - ${item.talla}` :
                    item.nombre;

                if (text.toLowerCase().includes(filtro.toLowerCase())) {
                    const div = document.createElement('div');
                    div.className = 'p-2 hover:bg-gray-200 dark:hover:bg-gray-700 cursor-pointer text-gray-900 dark:text-white';
                    div.innerHTML = `
    <div class="flex justify-between items-center">
        <span>${text}</span>
        ${tipoSeleccion === 'producto' ? `<a href="/${item.slug}" target="_blank" class="text-blue-500 underline text-sm ml-4">Ir</a>` : ''}
    </div>
`;
                    div.onclick = () => {
                        document.getElementById(`${tipoSeleccion}_id`).value = item.id;
                        document.getElementById(`${tipoSeleccion}_nombre`).value = text;
                        cerrarSelector();
                    };

                    contenedor.appendChild(div);
                }
            });
        }

        // Calcular precio por unidad automáticamente con 2 decimales
        function actualizarPrecioUnidad() {
            const unidades = parseFloat(document.querySelector('[name="unidades"]').value);
            const precioTotal = parseFloat(document.querySelector('[name="precio_total"]').value);

            if (!isNaN(unidades) && unidades > 0 && !isNaN(precioTotal)) {
                const resultado = (precioTotal / unidades).toFixed(2);
                document.querySelector('[name="precio_unidad"]').value = resultado;
            }
        }

        // Eventos
        document.querySelector('[name="unidades"]').addEventListener('input', actualizarPrecioUnidad);
        document.querySelector('[name="precio_total"]').addEventListener('input', actualizarPrecioUnidad);

        // Función para obtener precio automáticamente
        async function obtenerPrecioAutomatico() {
            const btnObtenerPrecio = document.getElementById('btnObtenerPrecio');
            const urlInput = document.querySelector('[name="url"]');
            const tiendaIdInput = document.getElementById('tienda_id');
            const varianteInput = document.querySelector('[name="variante"]');
            const unidadesInput = document.querySelector('[name="unidades"]');
            const precioTotalInput = document.querySelector('[name="precio_total"]');
            const precioUnidadInput = document.querySelector('[name="precio_unidad"]');

            // Validar que todos los campos necesarios estén completos
            if (!urlInput.value.trim()) {
                alert('Por favor, introduce la URL de la oferta');
                urlInput.focus();
                return;
            }

            if (!tiendaIdInput.value) {
                alert('Por favor, selecciona una tienda');
                return;
            }

            if (!unidadesInput.value || unidadesInput.value <= 0) {
                alert('Por favor, introduce el número de unidades');
                unidadesInput.focus();
                return;
            }

            // Obtener el nombre de la tienda
            const tiendaNombre = document.getElementById('tienda_nombre').value;
            if (!tiendaNombre) {
                alert('Por favor, selecciona una tienda válida');
                return;
            }

            // Deshabilitar botón y mostrar estado de carga
            btnObtenerPrecio.disabled = true;
            btnObtenerPrecio.textContent = '⏳ Obteniendo...';

            try {
                // Preparar datos para la petición
                const datos = {
                    url: urlInput.value.trim(),
                    tienda: tiendaNombre,
                    variante: varianteInput.value.trim() || null
                };

                // Hacer petición al scraper
                const response = await fetch('/panel-privado/ofertas/scraper/obtener-precio', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify(datos)
                });

                const resultado = await response.json();

                if (resultado.success) {
                    // Actualizar precio total
                    precioTotalInput.value = resultado.precio;
                    
                    // Calcular y actualizar precio por unidad
                    const unidades = parseFloat(unidadesInput.value);
                    const precioTotal = parseFloat(resultado.precio);
                    const precioUnidad = (precioTotal / unidades).toFixed(4);
                    precioUnidadInput.value = precioUnidad;

                    // Mostrar mensaje de éxito
                    mostrarNotificacion('✅ Precio obtenido correctamente: ' + resultado.precio + '€', 'success');
                } else {
                    // Mostrar error
                    mostrarNotificacion('❌ Error al obtener precio: ' + resultado.error, 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                mostrarNotificacion('❌ Error de conexión al obtener precio', 'error');
            } finally {
                // Restaurar botón
                btnObtenerPrecio.disabled = false;
                btnObtenerPrecio.textContent = '🔍 Obtener Precio';
            }
        }

        // Función para mostrar notificaciones
        function mostrarNotificacion(mensaje, tipo = 'info') {
            // Crear elemento de notificación
            const notificacion = document.createElement('div');
            notificacion.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 max-w-sm ${
                tipo === 'success' ? 'bg-green-500 text-white' :
                tipo === 'error' ? 'bg-red-500 text-white' :
                'bg-blue-500 text-white'
            }`;
            notificacion.textContent = mensaje;

            // Añadir al DOM
            document.body.appendChild(notificacion);

            // Eliminar después de 5 segundos
            setTimeout(() => {
                if (notificacion.parentNode) {
                    notificacion.parentNode.removeChild(notificacion);
                }
            }, 5000);
        }
    </script>
{{-- EVITAR TENER QUE PINCHAR DOS VECES EN LOS ENLACES PARA QUE FUNCIONEN--}}
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>
</x-app-layout>