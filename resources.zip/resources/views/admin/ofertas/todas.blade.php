<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Inicio -></h2>
            </a>
            <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                Todas las ofertas
            </h2>
        </div>
    </x-slot>

    <div class="py-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="mb-4 text-right">
            <a href="{{ route('admin.ofertas.create.formularioGeneral') }}"
                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                + Añadir oferta
            </a>
        </div>
        {{-- Formulario de búsqueda --}}
        <div class="mb-4 text-left">
<form method="GET" class="mb-6 flex flex-wrap items-center gap-2">
    <input type="text" name="busqueda" value="{{ request('busqueda') }}"
        placeholder="Buscar por tienda, producto, modelo, talla o URL"
        class="flex-1 min-w-[200px] px-4 py-2 border rounded bg-white dark:bg-gray-800 text-sm text-gray-800 dark:text-white" />
    <button type="submit"
        class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 text-sm">
        Buscar
    </button>
</form>
</div>

        {{-- Selector de cantidad por página --}}
        <div class="mb-4 flex justify-end items-center gap-2">
            <label for="perPage" class="text-sm text-gray-700 dark:text-gray-300">Mostrar:</label>
            <select id="perPage" name="perPage"
                class="px-2 py-1 pr-8 rounded border bg-white dark:bg-gray-800 text-sm text-gray-800 dark:text-white"
                onchange="cambiarCantidad()">
                @foreach ([20, 50, 100, 200] as $cantidad)
                <option value="{{ $cantidad }}" {{ $perPage == $cantidad ? 'selected' : '' }}>
                    {{ $cantidad }}
                </option>
                @endforeach
            </select>
            <span class="text-sm text-gray-700 dark:text-gray-300">resultados por página</span>
        </div>

        <div class="bg-white shadow rounded-lg overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>

                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tienda</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producto</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unidades</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">€/Unidad</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mostrar</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @forelse ($ofertas as $oferta)
                    <tr class="hover:bg-gray-100 dark:hover:bg-gray-300 transition-colors">

                        <td class="px-6 py-4">{{ $oferta->tienda->nombre }}</td>
                        <td class="px-6 py-4">{{ $oferta->producto->nombre }}</td>
                        <td class="px-6 py-4">{{ $oferta->unidades }}</td>
                        <td class="px-6 py-4">{{ number_format($oferta->precio_total, 2) }} €</td>
                        <td class="px-6 py-4">{{ number_format($oferta->precio_unidad, 4) }} €</td>
                        <td class="px-6 py-4">{{ $oferta->mostrar }}</td>
                        <td class="px-6 py-4 text-right">
                            <a href="{{ $oferta->url }}" target="_blank" class="text-green-500 hover:underline mr-4">Ir</a>
                            <a href="{{ route('admin.ofertas.estadisticas', $oferta) }}" class="text-indigo-500 hover:underline mr-4">Estadísticas</a>
                            <a href="{{ route('admin.ofertas.edit', $oferta) }}" class="text-blue-500 hover:underline mr-4">Editar</a>
                            <form action="{{ route('admin.ofertas.destroy', $oferta) }}" method="POST" class="inline-block"
                                onsubmit="return confirm('¿Seguro que quieres eliminar esta oferta?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="text-red-600 hover:underline">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="px-6 py-4 text-center text-gray-500">No hay ofertas registradas.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            {{ $ofertas->links() }}
        </div>
    </div>

    <script>
        function cambiarCantidad() {
            const cantidad = document.getElementById('perPage').value;
            const params = new URLSearchParams(window.location.search);
            params.set('perPage', cantidad);
            window.location.search = params.toString();
        }
    </script>
    {{-- EVITAR TENER QUE PINCHAR DOS VECES EN LOS ENLACES PARA QUE FUNCIONEN--}}
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>
</x-app-layout>