<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Inicio -></h2>
            </a>
            <a href="{{ route('admin.ofertas.todas') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Ofertas -></h2>
            </a>
            <h2 class="font-semibold text-xl text-white leading-tight">Ejecuciones Scraper</h2>
        </div>
    </x-slot>

    <div class="max-w-7xl mx-auto py-10 px-4 space-y-8 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-md">
        
        <!-- Header con estadísticas -->
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200">Ejecuciones de Scraper</h3>
                <div class="text-sm text-gray-600 dark:text-gray-400">
                    Total: {{ $totalEjecuciones }} ejecuciones
                </div>
            </div>

            <!-- Filtros -->
            <form method="GET" class="flex gap-4 mb-6">
                <input type="text" name="buscar" placeholder="Buscar por fecha..." 
                    value="{{ $busqueda }}"
                    class="flex-1 px-4 py-2 rounded border bg-gray-100 dark:bg-gray-700 text-white">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                    Buscar
                </button>
                @if($busqueda)
                <a href="{{ route('admin.ofertas.scraper.ejecuciones') }}" 
                    class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                    Limpiar
                </a>
                @endif
            </form>
        </div>

        <!-- Lista de ejecuciones -->
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 dark:bg-gray-700">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                ID
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Inicio
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Duración
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Total Ofertas
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Actualizadas
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Errores
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Acciones
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        @forelse($ejecuciones as $ejecucion)
                        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                #{{ $ejecucion->id }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                {{ $ejecucion->inicio->format('d/m/Y H:i:s') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                @if($ejecucion->fin)
                                    {{ $ejecucion->inicio->diffForHumans($ejecucion->fin, ['parts' => 2]) }}
                                @else
                                    <span class="text-yellow-600 dark:text-yellow-400">En progreso</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100">
                                {{ $ejecucion->total }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600 dark:text-green-400 font-medium">
                                {{ $ejecucion->total_guardado }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-red-600 dark:text-red-400 font-medium">
                                {{ $ejecucion->total_errores }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex gap-2">
                                    <button onclick="verJson({{ $ejecucion->id }})" 
                                        class="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300">
                                        Ver JSON
                                    </button>
                                    <form method="POST" action="{{ route('admin.ofertas.scraper.ejecuciones.eliminar', $ejecucion) }}" 
                                        onsubmit="return confirm('¿Estás seguro de que quieres eliminar esta ejecución?')" 
                                        class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                                            Eliminar
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                                No hay ejecuciones de scraper registradas
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Paginación -->
        @if($ejecuciones->hasPages())
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 border border-gray-200 dark:border-gray-700">
            {{ $ejecuciones->links() }}
        </div>
        @endif
    </div>

    <!-- Modal para mostrar JSON -->
    <div id="modalJson" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center">
        <div class="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-4xl w-full mx-4 shadow-lg relative">
            <button onclick="cerrarModalJson()" class="absolute top-4 right-4 text-gray-600 dark:text-gray-200 hover:text-gray-800 dark:hover:text-gray-100">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
            <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200 mb-4">Detalles de la Ejecución</h3>
            <div id="jsonContent" class="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 max-h-96 overflow-y-auto font-mono text-sm">
                <div class="text-gray-500 dark:text-gray-400">Cargando...</div>
            </div>
        </div>
    </div>

    <script>
        function verJson(ejecucionId) {
            document.getElementById('modalJson').classList.remove('hidden');
            document.getElementById('jsonContent').innerHTML = '<div class="text-gray-500 dark:text-gray-400">Cargando...</div>';
            
            fetch(`/panel-privado/ofertas/scraper/ejecuciones/${ejecucionId}/json`)
                .then(response => response.json())
                .then(data => {
                    mostrarJson(data);
                })
                .catch(error => {
                    document.getElementById('jsonContent').innerHTML = '<div class="text-red-500">Error al cargar los datos</div>';
                });
        }

        function mostrarJson(data) {
            const container = document.getElementById('jsonContent');
            container.innerHTML = '';
            
            if (!data || data.length === 0) {
                container.innerHTML = '<div class="text-gray-500 dark:text-gray-400">No hay datos disponibles</div>';
                return;
            }
            
            data.forEach((item, index) => {
                const div = document.createElement('div');
                div.className = 'mb-4 p-3 rounded border';
                
                const icono = item.success ? '✅' : '❌';
                const clase = item.success ? 'border-green-200 bg-green-50 dark:bg-green-900/20' : 'border-red-200 bg-red-50 dark:bg-red-900/20';
                div.className = `mb-4 p-3 rounded border ${clase}`;
                
                let contenido = `
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-lg">${icono}</span>
                        <span class="font-semibold">Oferta #${item.oferta_id} - ${item.tienda_nombre}</span>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                        <div><strong>URL:</strong> <a href="${item.url}" target="_blank" class="text-blue-600 hover:underline">${item.url}</a></div>
                        <div><strong>Variante:</strong> ${item.variante || 'N/A'}</div>
                        <div><strong>Precio anterior:</strong> ${item.precio_anterior}€</div>
                        <div><strong>Precio nuevo:</strong> ${item.precio_nuevo || 'N/A'}€</div>
                `;
                
                if (!item.success && item.error) {
                    contenido += `<div class="col-span-2"><strong>Error:</strong> <span class="text-red-600">${item.error}</span></div>`;
                }
                
                if (item.cambios_detectados) {
                    contenido += `<div class="col-span-2"><strong>⚠️ , Actualizado precio Producto</strong></div>`;
                }
                
                contenido += '</div>';
                div.innerHTML = contenido;
                container.appendChild(div);
            });
        }

        function cerrarModalJson() {
            document.getElementById('modalJson').classList.add('hidden');
        }

        // Cerrar modal al hacer clic fuera
        document.getElementById('modalJson').addEventListener('click', function(e) {
            if (e.target === this) {
                cerrarModalJson();
            }
        });
    </script>
    {{-- EVITAR TENER QUE PINCHAR DOS VECES EN LOS ENLACES PARA QUE FUNCIONEN--}}
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Prevenir doble clic en enlaces
    const links = document.querySelectorAll('a[href]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            // Si el enlace ya está siendo procesado, prevenir el clic
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            // Marcar como en procesamiento
            this.dataset.processing = 'true';
            
            // Remover la marca después de un tiempo
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
    
    // Prevenir doble clic en botones
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.dataset.processing === 'true') {
                e.preventDefault();
                return false;
            }
            
            this.dataset.processing = 'true';
            
            setTimeout(() => {
                this.dataset.processing = 'false';
            }, 2000);
        });
    });
});
</script>
</x-app-layout> 