<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}">
                <h2 class="font-semibold text-xl text-white leading-tight">Inicio -></h2>
            </a>
            <h2 class="font-semibold text-xl text-white leading-tight">Categorías</h2>
            <style>[x-cloak]{ display:none !important; }</style>
        </div>
    </x-slot>

    <div class="max-w-5xl mx-auto py-10 px-4 space-y-8 bg-gray-50 dark:bg-gray-900 rounded-lg shadow-md"
        x-data="{
            openModal: false,
            openModalImagenes: false,
            openModalImagenesEditar: false,
            editarId: null,
            editarNombre: '',
            editarImagen: '',
            editarCategoria(id, nombre, imagen) {
                this.editarId = id;
                this.editarNombre = nombre;
                this.editarImagen = imagen;
                this.openModal = true;
            },
            async actualizarNombre() {
                try {
                    const response = await fetch(`/panel-privado/categorias/${this.editarId}/editar-nombre`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: JSON.stringify({
                            nombre: this.editarNombre,
                            imagen: this.editarImagen
                        })
                    });

                    if (!response.ok) throw new Error('Error al actualizar');

                    this.openModal = false;
                    location.reload();
                } catch (err) {
                    alert('Error al guardar los cambios');
                }
            },
            buscarImagenModal() {
                console.log('Función buscarImagenModal ejecutada');
                this.openModalImagenesEditar = true;
                // Cargar imágenes de la carpeta categorias
                cargarImagenesEnModalEditar('categorias');
            },
            cambiarTabUpload() {
                console.log('Alpine.js: Clic en pestaña upload');
                const tabUpload = document.getElementById('tab-upload-categoria');
                const tabManual = document.getElementById('tab-manual-categoria');
                const contentUpload = document.getElementById('content-upload-categoria');
                const contentManual = document.getElementById('content-manual-categoria');
                
                if (tabUpload && tabManual && contentUpload && contentManual) {
                    // Ocultar todos los contenidos
                    contentUpload.classList.remove('hidden');
                    contentManual.classList.add('hidden');
                    
                    // Quitar estilos activos de todas las pestañas
                    tabUpload.classList.remove('border-transparent', 'text-gray-500', 'dark:text-gray-400');
                    tabUpload.classList.add('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
                    tabManual.classList.remove('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
                    tabManual.classList.add('border-transparent', 'text-gray-500', 'dark:text-gray-400');
                }
            },
            cambiarTabManual() {
                console.log('Alpine.js: Clic en pestaña manual');
                const tabUpload = document.getElementById('tab-upload-categoria');
                const tabManual = document.getElementById('tab-manual-categoria');
                const contentUpload = document.getElementById('content-upload-categoria');
                const contentManual = document.getElementById('content-manual-categoria');
                
                if (tabUpload && tabManual && contentUpload && contentManual) {
                    // Ocultar todos los contenidos
                    contentUpload.classList.add('hidden');
                    contentManual.classList.remove('hidden');
                    
                    // Quitar estilos activos de todas las pestañas
                    tabUpload.classList.remove('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
                    tabUpload.classList.add('border-transparent', 'text-gray-500', 'dark:text-gray-400');
                    tabManual.classList.remove('border-transparent', 'text-gray-500', 'dark:text-gray-400');
                    tabManual.classList.add('border-blue-500', 'text-blue-600', 'dark:text-blue-400');
                }
            },
            openCategorias: [],
            toggle(id) {
                if (this.openCategorias.includes(id)) {
                    this.openCategorias = this.openCategorias.filter(i => i !== id);
                } else {
                    this.openCategorias.push(id);
                }
            },
            isOpen(id) {
                return this.openCategorias.includes(id);
            }
        }">
        


        {{-- MENSAJES FLASH --}}
        @if (session('success'))
        <div class="p-3 bg-green-100 text-green-800 rounded shadow-sm border border-green-300">
            {{ session('success') }}
        </div>
        @endif
        @if (session('error'))
        <div class="p-3 bg-red-100 text-red-800 rounded shadow-sm border border-red-300">
            {{ session('error') }}
        </div>
        @endif

        {{-- FORMULARIO CREAR CATEGORÍA --}}
        <form method="POST" action="{{ route('admin.categorias.store') }}">
            @csrf
            <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-4 border border-gray-200 dark:border-gray-700">
                <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Nueva Categoría</legend>

                {{-- SISTEMA DE CATEGORÍAS DINÁMICO --}}
                <div id="categorias-container" class="space-y-4">
                    <!-- Los selectores de categorías se generarán dinámicamente aquí -->
                </div>

                <!-- Campo oculto para la categoría padre final -->
                <input type="hidden" name="parent_id" id="categoria-final" value="">

                <div>
                    <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre *</label>
                    <input type="text" name="nombre" required class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                </div>

                {{-- IMÁGENES --}}
                <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-4 border border-gray-200 dark:border-gray-700">
                    <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imagen de la categoría</legend>

                    <!-- Pestañas de gestión de imágenes -->
                    <div class="border-b border-gray-200 dark:border-gray-600">
                        <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                                                    <button type="button" id="tab-upload-categoria" @click="cambiarTabUpload()" class="tab-button-categoria border-b-2 border-blue-500 py-2 px-1 text-sm font-medium text-blue-600 dark:text-blue-400" aria-current="page">
                            Subir imagen
                        </button>
                        <button type="button" id="tab-manual-categoria" @click="cambiarTabManual()" class="tab-button-categoria border-b-2 border-transparent py-2 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300">
                            Nombre manual
                        </button>
                        </nav>
                    </div>

                    <!-- Contenido de la pestaña de subida -->
                    <div id="content-upload-categoria" class="tab-content-categoria space-y-4">
                        <div>
                            <label class="block mb-2 font-medium text-gray-700 dark:text-gray-200">Imagen de la categoría *</label>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <!-- Selector de carpeta -->
                                <div>
                                    <label class="block mb-1 text-sm text-gray-600 dark:text-gray-400">Carpeta</label>
                                    <div class="flex gap-2">
                                        <select id="carpeta-imagen-categoria" class="flex-1 px-3 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border text-sm">
                                            <option value="">Selecciona una carpeta</option>
                                            <option value="categorias">categorias</option>
                                            <option value="panales">panales</option>
                                            <option value="tiendas">tiendas</option>
                                        </select>
                                        <button type="button" id="btn-ver-imagenes-categoria" class="bg-gray-500 hover:bg-gray-600 text-white px-3 py-2 rounded text-sm">
                                            Ver
                                        </button>
                                    </div>
                                    
                                    <!-- Vista previa de imagen actual -->
                                    <div class="mt-2 flex items-center gap-2 hidden" id="preview-container-categoria">
                                        <img id="preview-upload-categoria" src="" alt="Vista previa" class="h-12 w-12 object-contain border rounded">
                                        <button type="button" id="btn-limpiar-categoria" class="text-xs text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300">
                                            Limpiar
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- Área de upload -->
                                <div class="md:col-span-2">
                                    <label class="block mb-1 text-sm text-gray-600 dark:text-gray-400">Seleccionar imagen</label>
                                    <div class="flex gap-2">
                                        <input type="file" id="file-imagen-categoria" accept="image/*" class="hidden">
                                        <button type="button" id="btn-seleccionar-categoria" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">
                                            Seleccionar archivo
                                        </button>
                                        <span id="nombre-archivo-categoria" class="text-sm text-gray-500 dark:text-gray-400 self-center"></span>
                                    </div>
                                    
                                    <!-- Área de drag & drop -->
                                    <div id="drop-zone-categoria" class="mt-2 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-4 text-center hover:border-blue-400 dark:hover:border-blue-500 transition-colors">
                                        <div class="text-gray-500 dark:text-gray-400">
                                            <svg class="mx-auto h-8 w-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                                            </svg>
                                            <p>Arrastra y suelta la imagen aquí</p>
                                            <p class="text-xs">o haz clic para seleccionar</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Campo oculto -->
                            <input type="hidden" id="ruta-imagen-categoria" name="imagen" value="">
                            <span id="ruta-completa-categoria" class="text-sm text-gray-600 dark:text-gray-400 hidden"></span>
                        </div>
                    </div>

                    <!-- Contenido de la pestaña manual (oculto por defecto) -->
                    <div id="content-manual-categoria" class="tab-content-categoria space-y-4 hidden">
                        <div>
                            <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre de imagen *</label>
                            <div class="flex gap-2 items-center">
                                <input type="text" id="imagen-categoria-input" name="imagen_manual" placeholder="categorias/ejemplo.jpg" class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border">
                                <button type="button" id="buscar-imagen-categoria" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-3 h-full rounded">Buscar imagen</button>
                                <img id="preview-imagen-categoria" src="" alt="Vista previa" class="h-12 w-12 object-contain ml-2 border rounded hidden">
                            </div>
                            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Ejemplo: categorias/panales.jpg</p>
                        </div>
                    </div>
                </fieldset>

                <div class="text-right">
                    <button type="submit" class="bg-pink-600 hover:bg-pink-700 text-white font-semibold px-6 py-2 rounded shadow">
                        Guardar categoría
                    </button>
                </div>
            </fieldset>
        </form>

        {{-- SISTEMA DE CATEGORÍAS COMPLETAMENTE REWRITE --}}
        <div id="datos-categorias"
            data-categorias-raiz="{{ json_encode($categoriasRaiz) }}">
        </div>

        <script>
            // Variables globales
            let categoriasRaiz = [];

            // Inicialización cuando se carga la página
            document.addEventListener('DOMContentLoaded', () => {
                console.log('DOM cargado, inicializando sistema de categorías...');
                
                const datos = document.getElementById('datos-categorias');
                console.log('Elemento datos-categorias encontrado:', datos);
                
                if (datos) {
                    const categoriasData = datos.dataset.categoriasRaiz;
                    console.log('Datos de categorías raíz:', categoriasData);
                    
                    try {
                        categoriasRaiz = JSON.parse(categoriasData || '[]');
                        console.log('Categorías raíz parseadas:', categoriasRaiz);
                        
                        if (categoriasRaiz.length > 0) {
                            // Es una categoría nueva - crear solo el primer selector
                            console.log('Creando selector inicial con', categoriasRaiz.length, 'categorías');
                            crearSelectorCategoria(0, categoriasRaiz, null);
                        } else {
                            console.log('No hay categorías raíz disponibles');
                            // Mostrar mensaje de que no hay categorías
                            const container = document.getElementById('categorias-container');
                            container.innerHTML = '<p class="text-gray-500">No hay categorías padre disponibles. Puedes crear una categoría raíz.</p>';
                        }
                    } catch (error) {
                        console.error('Error parseando categorías raíz:', error);
                        console.log('Datos crudos:', categoriasData);
                    }
                } else {
                    console.error('No se encontró el elemento datos-categorias');
                }
            });

            function crearSelectorCategoria(nivel, opciones, valorSeleccionado) {
                console.log(`Creando selector nivel ${nivel} con ${opciones.length} opciones`);
                
                const container = document.getElementById('categorias-container');
                if (!container) {
                    console.error('No se encontró el contenedor de categorías');
                    return;
                }
                
                // Crear contenedor del selector
                const div = document.createElement('div');
                div.className = 'selector-categoria flex items-center gap-4 mb-4';
                div.dataset.nivel = nivel;
                
                // Crear label
                const label = document.createElement('label');
                label.className = 'block mb-1 font-medium text-gray-700 dark:text-gray-200 min-w-[120px]';
                label.textContent = nivel === 0 ? 'Categoría padre' : `Subcategoría ${nivel}`;
                
                // Crear select
                const select = document.createElement('select');
                select.className = 'categoria-select w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-white border';
                select.dataset.nivel = nivel;
                
                // Opción por defecto
                const optionDefault = document.createElement('option');
                optionDefault.value = '';
                optionDefault.textContent = nivel === 0 ? '-- Ninguna (raíz) --' : '-- Ninguna --';
                select.appendChild(optionDefault);
                
                // Ordenar opciones alfabéticamente por nombre
                const opcionesOrdenadas = [...opciones].sort((a, b) => a.nombre.localeCompare(b.nombre, 'es', {sensitivity: 'base'}));
                
                // Agregar opciones ordenadas
                opcionesOrdenadas.forEach(cat => {
                    const option = document.createElement('option');
                    option.value = cat.id;
                    option.textContent = cat.nombre;
                    if (valorSeleccionado == cat.id) {
                        option.selected = true;
                    }
                    select.appendChild(option);
                });
                
                // Botón de eliminar (solo para niveles > 0)
                let removeBtn = null;
                if (nivel > 0) {
                    removeBtn = document.createElement('button');
                    removeBtn.type = 'button';
                    removeBtn.className = 'bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded text-sm';
                    removeBtn.textContent = '×';
                    removeBtn.onclick = () => {
                        eliminarSelectorYSuperiores(nivel);
                    };
                }
                
                // Ensamblar
                div.appendChild(label);
                div.appendChild(select);
                if (removeBtn) div.appendChild(removeBtn);
                
                container.appendChild(div);
                console.log(`Selector nivel ${nivel} creado y agregado al DOM`);
                
                // Configurar evento change
                select.addEventListener('change', () => {
                    const categoriaId = select.value;
                    console.log(`Cambio en selector nivel ${nivel}, categoría seleccionada:`, categoriaId);
                    
                    if (categoriaId) {
                        // Cargar subcategorías del siguiente nivel
                        console.log(`Cargando subcategorías para categoría ${categoriaId} en nivel ${nivel + 1}`);
                        cargarSubcategorias(nivel + 1, categoriaId);
                        // Actualizar campo final
                        actualizarCategoriaFinal();
                    } else {
                        // Limpiar selectores de niveles superiores
                        console.log(`Limpiando selectores superiores al nivel ${nivel + 1}`);
                        limpiarSelectoresSuperiores(nivel + 1);
                        // Actualizar campo final
                        actualizarCategoriaFinal();
                    }
                });
            }

            function cargarSubcategorias(nivel, categoriaId) {
                console.log(`Iniciando carga de subcategorías para nivel ${nivel}, categoría ${categoriaId}`);
                
                // Limpiar selectores de niveles superiores
                limpiarSelectoresSuperiores(nivel);
                
                const url = `/panel-privado/categorias/${categoriaId}/subcategorias`;
                console.log(`Haciendo fetch a: ${url}`);
                
                fetch(url, {
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                })
                .then(res => {
                    console.log('Respuesta del servidor:', res.status, res.statusText);
                    return res.json();
                })
                .then(subcategorias => {
                    console.log('Subcategorías recibidas:', subcategorias);
                    if (subcategorias && subcategorias.length > 0) {
                        console.log(`Creando selector para nivel ${nivel} con ${subcategorias.length} subcategorías`);
                        crearSelectorCategoria(nivel, subcategorias, null);
                    } else {
                        console.log('No hay subcategorías disponibles para este nivel');
                    }
                })
                .catch(error => {
                    console.error('Error cargando subcategorías:', error);
                });
            }

            function limpiarSelectoresSuperiores(nivel) {
                const selectores = document.querySelectorAll(`.selector-categoria[data-nivel="${nivel}"]`);
                console.log(`Limpiando ${selectores.length} selectores del nivel ${nivel}`);
                selectores.forEach(selector => selector.remove());
            }

            function eliminarSelectorYSuperiores(nivel) {
                const selectores = document.querySelectorAll(`.selector-categoria[data-nivel="${nivel}"]`);
                selectores.forEach(selector => selector.remove());
                actualizarCategoriaFinal();
            }

            function actualizarCategoriaFinal() {
                const selectores = document.querySelectorAll('.categoria-select');
                let categoriaFinal = null;
                
                // Buscar el último selector con valor
                for (let i = selectores.length - 1; i >= 0; i--) {
                    if (selectores[i].value) {
                        categoriaFinal = selectores[i].value;
                        break;
                    }
                }
                
                document.getElementById('categoria-final').value = categoriaFinal || '';
                console.log('Categoría final actualizada:', categoriaFinal);
            }
        </script>

        {{-- CATEGORÍAS EXISTENTES --}}
        <fieldset class="bg-white dark:bg-gray-800 shadow-sm rounded-xl p-6 space-y-4 border border-gray-200 dark:border-gray-700">
            <legend class="text-lg font-semibold text-gray-700 dark:text-gray-200">Categorías existentes</legend>

            @foreach ($categoriasRaiz as $categoria)
                @include('admin.categorias.partial-categoria', ['categoria' => $categoria, 'nivel' => 0])
            @endforeach
        </fieldset>

        {{-- MODAL EDITAR NOMBRE --}}
        <div x-show="openModal" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-2xl space-y-4">
                <h2 class="text-lg font-bold text-gray-800 dark:text-white">Editar categoría</h2>
                <form @submit.prevent="actualizarNombre" class="space-y-4">
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Nombre</label>
                        <input type="text" name="nombre" x-model="editarNombre" required
                            class="w-full px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white border">
                    </div>
                    
                    <div>
                        <label class="block mb-1 font-medium text-gray-700 dark:text-gray-200">Imagen</label>
                        <div class="flex gap-2">
                            <input type="text" name="imagen" x-model="editarImagen" placeholder="categorias/ejemplo.jpg"
                                class="flex-1 px-4 py-2 rounded bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white border">
                            <button type="button" @click="buscarImagenModal" 
                                class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-sm">
                                Buscar imagen
                            </button>
                        </div>
                        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">Ejemplo: categorias/panales.jpg</p>
                    </div>
                    
                    <div class="flex justify-end gap-2">
                        <button type="button" @click="openModal = false"
                            class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">Cancelar</button>
                        <button type="submit" class="bg-pink-600 hover:bg-pink-700 text-white px-4 py-2 rounded">Guardar</button>
                    </div>
                </form>
            </div>
        </div>

        {{-- MODAL PARA BUSCAR IMÁGENES EN EDICIÓN --}}
        <div x-show="openModalImagenesEditar" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" style="display: none !important;">
            <div class="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-6xl w-full relative shadow-xl overflow-y-auto max-h-[90vh]">
                <button @click="openModalImagenesEditar = false" class="absolute top-3 right-4 text-xl text-gray-800 dark:text-gray-100 hover:text-gray-600 dark:hover:text-gray-300">×</button>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imágenes en la carpeta: <span class="text-blue-600 dark:text-blue-400">categorias</span></h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Haz clic en una imagen para seleccionarla</p>
                </div>
                <div id="contenido-modal-imagenes-editar" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    <div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>
                </div>
            </div>
        </div>

        {{-- MODAL PARA VER IMÁGENES EXISTENTES --}}
        <div x-show="openModalImagenes" x-cloak class="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" style="display: none !important;">
            <div class="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-6xl w-full relative shadow-xl overflow-y-auto max-h-[90vh]">
                <button @click="openModalImagenes = false" class="absolute top-3 right-4 text-xl text-gray-800 dark:text-gray-100 hover:text-gray-600 dark:hover:text-gray-300">×</button>
                <div class="mb-4">
                    <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imágenes en la carpeta: <span class="text-blue-600 dark:text-blue-400">categorias</span></h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Haz clic en una imagen para seleccionarla</p>
                </div>
                <div id="contenido-modal-imagenes-categoria" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    <div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>
                </div>
            </div>
        </div>
    </div>

    {{-- SCRIPTS PARA GESTIÓN DE IMÁGENES DE CATEGORÍAS --}}
    <script>
        // Script de emergencia para asegurar que los modales estén ocultos
        (function() {
            // Ocultar solo los modales de imágenes, no el modal de edición principal
            const modales = document.querySelectorAll('[x-show]');
            modales.forEach(modal => {
                if (modal.getAttribute('x-show') && 
                    (modal.getAttribute('x-show').includes('openModalImagenes') || 
                     modal.getAttribute('x-show').includes('openModalImagenesEditar'))) {
                    modal.style.display = 'none';
                    modal.style.visibility = 'hidden';
                    modal.style.opacity = '0';
                    modal.style.pointerEvents = 'none';
                }
            });
            
            // Ocultar cualquier elemento con fixed y bg-black que no sea el modal de edición
            const elementosNegros = document.querySelectorAll('.fixed.inset-0.bg-black');
            elementosNegros.forEach(elemento => {
                // No ocultar si es el modal de edición principal
                if (!elemento.querySelector('form[\\@submit\\.prevent="actualizarNombre"]')) {
                    elemento.style.display = 'none';
                    elemento.style.visibility = 'hidden';
                    elemento.style.opacity = '0';
                    elemento.style.pointerEvents = 'none';
                }
            });
            
            // Esperar a que Alpine.js se inicialice y luego asegurar que los modales estén ocultos
            document.addEventListener('alpine:init', () => {
                console.log('Alpine.js inicializado');
                // Asegurar que solo los modales de imágenes estén ocultos después de la inicialización
                setTimeout(() => {
                    const scope = document.querySelector('[x-data]')?._x_dataStack?.[0];
                    if (scope) {
                        scope.openModalImagenes = false;
                        scope.openModalImagenesEditar = false;
                        // NO tocar openModal para que el modal de edición funcione
                    }
                }, 100);
            });
        })();
        // Vista previa de imagen manual
        document.addEventListener('DOMContentLoaded', function() {
            const btnBuscar = document.getElementById('buscar-imagen-categoria');
            const inputImagen = document.getElementById('imagen-categoria-input');
            
            if (btnBuscar) {
                btnBuscar.onclick = function() {
                    const input = document.getElementById('imagen-categoria-input');
                    const preview = document.getElementById('preview-imagen-categoria');
                    if (input && preview && input.value.trim() !== '') {
                        preview.src = '/images/' + input.value.trim();
                        preview.classList.remove('hidden');
                    } else if (preview) {
                        preview.src = '';
                        preview.classList.add('hidden');
                    }
                };
            }
            
            if (inputImagen) {
                inputImagen.addEventListener('input', function() {
                    const preview = document.getElementById('preview-imagen-categoria');
                    if (preview) {
                        preview.classList.add('hidden');
                    }
                });
            }
        });

        // Script para gestión de imágenes con pestañas
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Script de gestión de imágenes de categorías cargado');
            
            // Elementos de las pestañas
            const tabUpload = document.getElementById('tab-upload-categoria');
            const tabManual = document.getElementById('tab-manual-categoria');
            const contentUpload = document.getElementById('content-upload-categoria');
            const contentManual = document.getElementById('content-manual-categoria');

            // Verificar que los elementos existen
            if (!tabUpload || !tabManual || !contentUpload || !contentManual) {
                console.error('No se encontraron los elementos de las pestañas');
                return;
            }

            console.log('Elementos de pestañas encontrados correctamente');
            console.log('JavaScript funcionando correctamente');
            console.log('Funciones de pestañas disponibles en Alpine.js');

            // Función para manejar la subida de imágenes
            function configurarUpload() {
                const carpetaSelect = document.getElementById('carpeta-imagen-categoria');
                const fileInput = document.getElementById('file-imagen-categoria');
                const btnSeleccionar = document.getElementById('btn-seleccionar-categoria');
                const dropZone = document.getElementById('drop-zone-categoria');
                const nombreArchivo = document.getElementById('nombre-archivo-categoria');
                const preview = document.getElementById('preview-upload-categoria');
                const rutaImagen = document.getElementById('ruta-imagen-categoria');

                // Verificar que todos los elementos existen
                if (!carpetaSelect || !fileInput || !btnSeleccionar || !dropZone || !nombreArchivo || !preview || !rutaImagen) {
                    console.error('No se encontraron todos los elementos necesarios para la subida de imágenes');
                    return;
                }

                // Botón de selección de archivo
                btnSeleccionar.addEventListener('click', () => {
                    fileInput.click();
                });

                // Cambio de archivo seleccionado
                fileInput.addEventListener('change', (e) => {
                    const file = e.target.files[0];
                    if (file) {
                        procesarArchivo(file);
                    }
                });

                // Drag and drop
                dropZone.addEventListener('click', () => {
                    fileInput.click();
                });
                
                dropZone.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    dropZone.classList.add('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
                });

                dropZone.addEventListener('dragleave', (e) => {
                    e.preventDefault();
                    dropZone.classList.remove('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
                });

                dropZone.addEventListener('drop', (e) => {
                    e.preventDefault();
                    dropZone.classList.remove('border-blue-500', 'bg-blue-50', 'dark:bg-blue-900/20');
                    
                    const files = e.dataTransfer.files;
                    if (files.length > 0) {
                        procesarArchivo(files[0]);
                    }
                });

                // Función para procesar el archivo
                function procesarArchivo(file) {
                    // Validar que sea una imagen
                    if (!file.type.startsWith('image/')) {
                        alert('Por favor selecciona un archivo de imagen válido.');
                        return;
                    }

                    // Validar tamaño (máximo 5MB)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('La imagen es demasiado grande. Máximo 5MB.');
                        return;
                    }

                    // Validar que se haya seleccionado una carpeta
                    const carpeta = carpetaSelect.value;
                    if (!carpeta) {
                        alert('Por favor selecciona una carpeta primero.');
                        return;
                    }

                    // Mostrar nombre del archivo
                    nombreArchivo.textContent = file.name;

                    // Crear vista previa
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);

                    // Subir archivo
                    const formData = new FormData();
                    formData.append('imagen', file);
                    formData.append('carpeta', carpeta);

                    fetch('{{ route("admin.imagenes.subir") }}', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Actualizar campo oculto con la ruta
                            const rutaCompleta = `${carpeta}/${data.data.nombre}`;
                            rutaImagen.value = rutaCompleta;
                            alert('Imagen subida correctamente');
                        } else {
                            alert('Error al subir la imagen: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error al subir imagen:', error);
                        alert('Error al subir la imagen');
                    });
                }
            }

            // Configurar upload
            configurarUpload();

            // Configurar botón para ver imágenes existentes
            configurarBotonVerImagenes();

            // Cargar carpetas disponibles al inicio
            // cargarCarpetasDisponibles(); // Comentado temporalmente para pruebas
            
            console.log('Todas las funciones básicas configuradas correctamente');

            // Función para cargar carpetas disponibles dinámicamente
            function cargarCarpetasDisponibles() {
                fetch('{{ route("admin.imagenes.carpetas") }}', {
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data.length > 0) {
                            // Actualizar select con las carpetas encontradas
                            actualizarSelectCarpetas('carpeta-imagen-categoria', data.data);
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar carpetas:', error);
                        // Si hay error, mantener las carpetas por defecto
                    });
            }

            // Función para actualizar un select con las carpetas disponibles
            function actualizarSelectCarpetas(selectId, carpetas) {
                const select = document.getElementById(selectId);
                if (!select) return;

                // Mantener la primera opción (Selecciona una carpeta)
                const primeraOpcion = select.querySelector('option[value=""]');
                select.innerHTML = '';
                
                if (primeraOpcion) {
                    select.appendChild(primeraOpcion);
                } else {
                    const option = document.createElement('option');
                    option.value = '';
                    option.textContent = 'Selecciona una carpeta';
                    select.appendChild(option);
                }

                // Agregar las carpetas encontradas
                carpetas.forEach(carpeta => {
                    const option = document.createElement('option');
                    option.value = carpeta;
                    option.textContent = carpeta.charAt(0).toUpperCase() + carpeta.slice(1);
                    select.appendChild(option);
                });
            }

            // Función para configurar el botón de ver imágenes
            function configurarBotonVerImagenes() {
                const btnVer = document.getElementById('btn-ver-imagenes-categoria');
                const carpetaSelect = document.getElementById('carpeta-imagen-categoria');

                if (!btnVer || !carpetaSelect) {
                    console.error('No se encontraron los elementos para el botón de ver imágenes');
                    return;
                }

                btnVer.addEventListener('click', () => {
                    const carpeta = carpetaSelect.value;
                    
                    if (!carpeta) {
                        alert('Por favor selecciona una carpeta primero.');
                        return;
                    }
                    
                    // Abrir modal directamente sin Alpine.js
                    abrirModalImagenesCategoria(carpeta);
                });
            }

            // Función para abrir el modal de imágenes de categoría
            function abrirModalImagenesCategoria(carpeta) {
                // Crear modal dinámicamente si no existe
                let modal = document.getElementById('modalImagenesCategoria');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.id = 'modalImagenesCategoria';
                    modal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center';
                    modal.innerHTML = `
                        <div class="bg-white dark:bg-gray-900 rounded-lg p-6 max-w-6xl w-full relative shadow-xl overflow-y-auto max-h-[90vh]">
                            <button onclick="cerrarModalImagenesCategoria()" class="absolute top-3 right-4 text-xl text-gray-800 dark:text-gray-100 hover:text-gray-600 dark:hover:text-gray-300">×</button>
                            <div class="mb-4">
                                <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-200">Imágenes en la carpeta: <span class="text-blue-600 dark:text-blue-400">${carpeta}</span></h3>
                                <p class="text-sm text-gray-500 dark:text-gray-400">Haz clic en una imagen para seleccionarla</p>
                            </div>
                            <div id="contenido-modal-imagenes-categoria" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                <div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(modal);
                } else {
                    modal.style.display = 'flex';
                }
                
                // Cargar imágenes
                cargarImagenesEnModal(carpeta);
            }

            // Función para cerrar el modal de imágenes de categoría
            window.cerrarModalImagenesCategoria = function() {
                const modal = document.getElementById('modalImagenesCategoria');
                if (modal) {
                    modal.style.display = 'none';
                }
            };

            // Función para cargar imágenes en el modal de edición
            function cargarImagenesEnModalEditar(carpeta) {
                const contenedor = document.getElementById('contenido-modal-imagenes-editar');
                if (!contenedor) {
                    console.error('No se encontró el contenedor del modal de imágenes de edición');
                    return;
                }
                
                contenedor.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>';

                fetch(`{{ route('admin.imagenes.listar') }}?carpeta=${carpeta}`, {
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data.length > 0) {
                            contenedor.innerHTML = '';
                            data.data.forEach(imagen => {
                                const div = document.createElement('div');
                                div.className = 'relative group cursor-pointer';
                                div.innerHTML = `
                                    <img src="${imagen.url}" alt="${imagen.nombre}" 
                                         class="w-full h-24 object-cover rounded border hover:border-blue-500 transition-colors">
                                    <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center">
                                        <button onclick="seleccionarImagenEditar('${imagen.ruta}')" 
                                                class="bg-blue-600 text-white px-3 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                            Seleccionar
                                        </button>
                                    </div>
                                    <div class="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">${imagen.nombre}</div>
                                `;
                                contenedor.appendChild(div);
                            });
                        } else {
                            contenedor.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">No se encontraron imágenes en esta carpeta.</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar imágenes:', error);
                        contenedor.innerHTML = '<div class="text-center text-red-500">Error al cargar las imágenes.</div>';
                    });
            }

            // Función para cargar imágenes en el modal
            function cargarImagenesEnModal(carpeta) {
                const contenedor = document.getElementById('contenido-modal-imagenes-categoria');
                if (!contenedor) {
                    console.error('No se encontró el contenedor del modal de imágenes');
                    return;
                }
                
                contenedor.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">Cargando imágenes...</div>';

                fetch(`{{ route('admin.imagenes.listar') }}?carpeta=${carpeta}`, {
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error en la respuesta del servidor');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data.length > 0) {
                            contenedor.innerHTML = '';
                            data.data.forEach(imagen => {
                                const div = document.createElement('div');
                                div.className = 'relative group cursor-pointer';
                                div.innerHTML = `
                                    <img src="${imagen.url}" alt="${imagen.nombre}" 
                                         class="w-full h-24 object-cover rounded border hover:border-blue-500 transition-colors">
                                    <div class="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center">
                                        <button onclick="seleccionarImagenCategoria('${imagen.ruta}')" 
                                                class="bg-blue-600 text-white px-3 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity">
                                            Seleccionar
                                        </button>
                                    </div>
                                    <div class="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">${imagen.nombre}</div>
                                `;
                                contenedor.appendChild(div);
                            });
                        } else {
                            contenedor.innerHTML = '<div class="text-center text-gray-500 dark:text-gray-400">No se encontraron imágenes en esta carpeta.</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error al cargar imágenes:', error);
                        contenedor.innerHTML = '<div class="text-center text-red-500">Error al cargar las imágenes.</div>';
                    });
            }
        });

         // Función global para seleccionar imagen desde el modal
 function seleccionarImagenCategoria(ruta) {
   // Actualizar el campo oculto con la ruta seleccionada
   const inputImagen = document.getElementById('ruta-imagen-categoria');
   if (inputImagen) {
       inputImagen.value = ruta;
   }
   
   // Actualizar la vista previa
   const preview = document.getElementById('preview-imagen-categoria');
   if (preview) {
       preview.src = `/storage/${ruta}`;
       preview.style.display = 'block';
   }
   
   // Cerrar el modal
   cerrarModalImagenesCategoria();
 }

        // Función global para cerrar modal
        function cerrarModalImagenesCategoria() {
            const modal = document.getElementById('modalImagenesCategoria');
            if (modal) {
                modal.style.display = 'none';
                modal.classList.add('hidden');
            }
        }

         // Función global para seleccionar imagen en el modal de edición
 function seleccionarImagenEditar(ruta) {
   // Actualizar el campo de imagen usando Alpine.js
   const scope = document.querySelector('[x-data]')?._x_dataStack?.[0];
   if (scope) {
       scope.editarImagen = ruta;
   }
   
   // Cerrar el modal
   if (scope) {
       scope.openModalImagenesEditar = false;
   }
 }

 // Función de emergencia para ocultar todos los modales
 function ocultarModalesEmergencia() {
     // Ocultar modales por CSS de múltiples maneras
     const modales = document.querySelectorAll('[x-show]');
     modales.forEach(modal => {
         if (modal.getAttribute('x-show') && modal.getAttribute('x-show').includes('openModal')) {
             modal.style.display = 'none';
             modal.style.visibility = 'hidden';
             modal.style.opacity = '0';
             modal.style.pointerEvents = 'none';
             modal.style.position = 'absolute';
             modal.style.zIndex = '-9999';
         }
     });
     
     // Ocultar cualquier elemento con fixed y bg-black
     const elementosNegros = document.querySelectorAll('.fixed.inset-0.bg-black');
     elementosNegros.forEach(elemento => {
         elemento.style.display = 'none';
         elemento.style.visibility = 'hidden';
         elemento.style.opacity = '0';
         elemento.style.pointerEvents = 'none';
         elemento.style.position = 'absolute';
         elemento.style.zIndex = '-9999';
     });
     
     // Ocultar modales por Alpine.js
     const scope = document.querySelector('[x-data]')?._x_dataStack?.[0];
     if (scope) {
         scope.openModalImagenes = false;
         scope.openModalImagenesEditar = false;
         scope.openModal = false;
     }
     
     console.log('Modales ocultados por emergencia');
 }





     </script>

    {{-- SCRIPT PARA PREVENIR DOBLE CLIC --}}
    <script>
        // Prevenir doble clic en enlaces y botones
        document.addEventListener('DOMContentLoaded', function() {
            const links = document.querySelectorAll('a[href]');
            links.forEach(link => {
                link.addEventListener('click', function(e) {
                    if (this.dataset.processing === 'true') {
                        e.preventDefault();
                        return false;
                    }
                    this.dataset.processing = 'true';
                    setTimeout(() => {
                        this.dataset.processing = 'false';
                    }, 2000);
                });
            });
            
            const buttons = document.querySelectorAll('button');
            buttons.forEach(button => {
                button.addEventListener('click', function(e) {
                    if (this.dataset.processing === 'true') {
                        e.preventDefault();
                        return false;
                    }
                    this.dataset.processing = 'true';
                    setTimeout(() => {
                        this.dataset.processing = 'false';
                    }, 2000);
                });
            });
        });
    </script>
</x-app-layout>