<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Búsqueda: {{ $query }} - CholloPañales</title>
  <meta name="description" content="Resultados de búsqueda para {{ $query }} en CholloPañales">
  <meta property="og:title" content="Resultados para '{{ $query }}' - CholloPañales">
<meta property="og:description" content="Explora productos relacionados con '{{ $query }}' en CholloPañales.">
<meta property="og:image" content="{{ asset('images/logo.png') }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:type" content="website">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Búsqueda: {{ $query }}">
<meta name="twitter:description" content="Compara precios en CholloPañales para '{{ $query }}'.">
<meta name="twitter:image" content="{{ asset('images/logo.png') }}">
  @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="bg-gray-50">
  {{-- HEADER --}}
  <x-header />
<main class="max-w-7xl mx-auto flex flex-col gap-6 py-4 px-4 bg-gray-100">

      {{-- RESULTADOS --}}
      <div class="mb-4">
        <h1 class="text-xl font-bold text-gray-800">
  Resultados para "{{ $query }}"
</h1>
        <p class="text-gray-600">
          Se encontraron {{ $productos->total() }} productos para "{{ $query }}"
        </p>
      </div>

      @if($productos->count() > 0)
        <div class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          @foreach($productos as $producto)
            <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}" class="bg-white rounded-lg shadow p-4 card-hover hover:shadow-md">
              <div class="flex justify-center mb-3">
                <img loading="lazy" src="{{ asset('images/' . $producto->imagen_pequena) }}" 
                     alt="{{ $producto->nombre }}" 
                     class="w-24 h-24 object-contain">
              </div>
              <div class="text-center">
                <h3 class="font-semibold text-gray-800 mb-1">
                  {{ Str::limit($producto->nombre, 50) }}
                </h3>
                <p class="text-center mb-1">
    <span class="text-xs text-gray-500">Desde:</span>
<span class="text-xl font-bold text-pink-600">{{ number_format($producto->precio, 2) }}€
    @if($producto->unidadDeMedida === 'unidad')
        <span class="text-xs text-gray-500">/Und.</span>
    @elseif($producto->unidadDeMedida === 'kilos')
        <span class="text-xs text-gray-500">/kg.</span>
    @elseif($producto->unidadDeMedida === 'litros')
        <span class="text-xs text-gray-500">/L.</span>
    @endif
</span>
</p>
              </div>
            </a>
          @endforeach
        </div>

        {{-- PAGINACIÓN --}}
        <div class="mt-8">
          {{ $productos->appends(['q' => $query])->links() }}
        </div>
      @else
        <div class="text-center py-8">
          <div class="text-gray-500 mb-4">
            <svg class="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
            </svg>
            <h3 class="text-lg font-semibold mb-2">No se encontraron resultados</h3>
            <p class="text-gray-600">Intenta con otros términos de búsqueda</p>
          </div>
        </div>
      @endif
    </div>
  </div>
</main>
  {{-- FOOTER DESDE LA RUTA COMPONENTS/FOOTER --}}
  <x-footer />

{{-- JS PARA EL BUSCADOR DEL HEADER --}}
@stack('scripts')
</body>

</html> 