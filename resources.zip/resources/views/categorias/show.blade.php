<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $categoriaActual->nombre }} - CholloPañales</title>
    <meta name="description" content="Descubre {{ $productos->total() }} productos en la categoría {{ $categoriaActual->nombre }} al mejor precio. Compara ofertas y encuentra pañales baratos y más en CholloPañales.">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    {{-- HEADER DESDE COMPONENTS/HEADER --}}
    <x-header />

    {{-- CONTENIDO PRINCIPAL --}}
    <main class="max-w-7xl mx-auto px-6 py-2 bg-gray-100">
        
        {{-- BREADCRUMB --}}
        <nav class="mb-2">
            <ol class="flex items-center space-x-2 text-sm text-gray-600">
                <li>
                    <a href="{{ route('home') }}" class="hover:text-pink-600">Inicio</a>
                </li>
                @foreach($breadcrumb as $item)
                <li class="flex items-center">
                    <svg class="w-4 h-4 mx-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    <a href="{{ $item['url'] }}" class="hover:text-pink-600">{{ $item['nombre'] }}</a>
                </li>
                @endforeach
            </ol>
        </nav>

        {{-- TÍTULO Y CONTADOR --}}
        <div class="mb-4 bg-gray-200 px-4 py-3 rounded">
    <h1 class="text-3xl font-bold text-gray-800 mb-2">{{ $categoriaActual->nombre }}</h1>
    <p class="text-gray-600">{{ $productos->total() }} productos encontrados</p>
</div>

        

        {{-- BLOQUE DE CATEGORÍAS PRINCIPALES O SUBCATEGORÍAS --}}
        @php
        // Si estamos en "todas las categorías", usamos $categorias, si no, $subcategorias
        $bloqueCategorias = isset($categoriaActual) && $categoriaActual->nombre === 'Todas las categorías' ? $categorias : $subcategorias;
        @endphp
        @if($bloqueCategorias->count() > 0)
            <section class="mb-12">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">
                  {{ isset($categoriaActual) && $categoriaActual->nombre === 'Todas las categorías' ? 'Todas las categorías' : 'Subcategorías' }}
                </h2>
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" id="subcategorias-container">
                    @foreach($bloqueCategorias->take(8) as $index => $cat)
                    <div class="{{ $index >= 4 ? 'hidden sm:block' : '' }} bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-4 flex flex-col items-center text-center">
                        <div class="h-24 w-24 mb-4 mx-auto">
                            @if($cat->imagen)
                                <img loading="lazy" src="{{ asset('images/'.$cat->imagen) }}" alt="{{ $cat->nombre }}" class="w-full h-full object-contain">
                            @else
                                <div class="w-full h-full bg-gray-200 flex items-center justify-center rounded">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h2.586a1 1 0 01.707.293l1.414 1.414A1 1 0 009.414 5H20a1 1 0 011 1v11a1 1 0 01-1 1H4a1 1 0 01-1-1V4z"></path>
                                    </svg>
                                </div>
                            @endif
                        </div>
                        <a href="{{ route('categoria.show', $cat->slug) }}" class="text-pink-500 text-lg font-bold hover:text-pink-600">
                        <div class="flex items-center justify-center gap-2 mb-2">
                            {{ $cat->nombre }}
                            <svg class="w-4 h-4 text-pink-500 hover:text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                            </svg>
                        </div>
                        </a>
                        <hr class="border-t border-gray-300 w-40 mx-auto mb-2">
                        {{-- Categorías hijas --}}
                        @php
                        $hijas = $cat->subcategorias()->orderBy('nombre')->limit(10)->get();
                        @endphp
                        @if($hijas->count() > 0)
                            <div class="w-full flex flex-col items-start">
                                <ul class="text-base text-gray-700 space-y-2 text-left px-4 w-full">
                                    @foreach($hijas as $hija)
                                    <li>
                                        <a href="{{ route('categoria.show', $hija->slug) }}" class="hover:text-pink-600 hover:underline transition">
                                            {{ $hija->nombre }}
                                        </a>
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                    @endforeach
                </div>
                @if($bloqueCategorias->count() > 8)
                <div class="text-center mt-6">
                    <button id="btn-mostrar-subcategorias" 
                            class="bg-pink-500 hover:bg-pink-600 text-white px-6 py-2 rounded-lg transition-colors">
                        Mostrar más categorías
                    </button>
                </div>
                @endif
            </section>
        @endif

        {{-- SECCIÓN PRECIOS HOT --}}
        @if(isset($preciosHot) && $preciosHot && count($preciosHot->datos) > 0)
<section class="mb-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">🔥 Precios Hot</h2>
    <div class="flex overflow-x-auto scrollbar-hide gap-4 px-1">
        @foreach($preciosHot->datos as $productoHot)
        <div class="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 relative min-w-[320px] md:min-w-[360px] flex-shrink-0">
            <div class="p-4">
                {{-- Badge descuento --}}
                <span class="absolute top-2 right-2 bg-red-100 text-red-700 text-xs font-semibold px-2 py-1 rounded z-10">
    -{{ (int) floatval(str_replace(',', '.', $productoHot['porcentaje_diferencia'])) }}%
</span>

                <div class="flex mb-3 items-start">
                    {{-- Imagen producto --}}
                    <img loading="lazy" src="{{ asset('images/' . $productoHot['img_producto']) }}"
                         alt="{{ $productoHot['producto_nombre'] }}"
                         class="w-20 h-20 object-contain rounded bg-gray-100 shadow-sm flex-shrink-0">

                    {{-- Logo tienda + nombre producto --}}
                    <div class="flex flex-col justify-between flex-grow h-full">
                        <div class="flex justify-center w-full">
                            <img loading="lazy" src="{{ asset('images/' . $productoHot['img_tienda']) }}"
                                 alt="{{ $productoHot['tienda_nombre'] }}"
                                 class="object-contain max-h-7 w-auto mb-2">
                        </div>
                        <h3 class="font-semibold text-gray-800 text-sm md:text-base leading-tight pl-3">
                            {{ $productoHot['producto_nombre'] }}
                        </h3>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <div>
                        <div class="flex items-baseline gap-1">
                            <p class="text-lg font-bold text-red-600">
                                {{ number_format($productoHot['precio_oferta'], 2) }}€
                            </p>
                            <span class="text-sm text-gray-500">/Und.</span>
                        </div>
                        @if(isset($productoHot['unidades']))
                            <p class="text-sm text-gray-600">{{ $productoHot['unidades'] }} unidades</p>
                        @endif
                    </div>
                    <a href="{{ $productoHot['url_producto'] }}" 
                           class="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded transition">
                            Ver producto
                        </a>
                    <a href="{{ $productoHot['url_oferta'] }}"
                       target="_blank"
                       class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                        Comprar
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</section>
@endif



        {{-- PRODUCTOS --}}
        @if($productos->count() > 0)
    <section class="mb-12">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 border-b-4 border-blue-500 inline-block">
    Productos más visitados de {{ $categoriaActual->nombre }}
</h2>

        <div id="productos-container" class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-5 gap-6">
            @foreach($productos->take(10) as $producto)
            <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}"
               class="group flex flex-col items-center bg-white rounded-xl shadow-md transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer p-4">
                <div class="w-full flex justify-center mb-3">
                    @if($producto->imagen_pequena)
                        <img loading="lazy" src="{{ asset('images/' .$producto->imagen_pequena) }}"
                             alt="{{ $producto->nombre }}"
                             class="w-32 h-32 object-contain rounded-lg shadow-sm transition-all duration-300 group-hover:shadow-lg bg-gray-100">
                    @else
                        <div class="w-32 h-32 flex items-center justify-center rounded-lg bg-gradient-to-br from-blue-100 to-blue-200">
                            <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                    @endif
                </div>
                <p class="font-semibold text-gray-700 text-center text-sm mb-1 line-clamp-2">{{ $producto->nombre }}</p>
                <p class="text-center mb-1">
                    <span class="text-xs text-gray-500">Desde:</span>
                    <span class="text-xl font-bold text-pink-600">{{ number_format($producto->precio, 2) }}€
                        @if($producto->unidadDeMedida === 'unidad')
                            <span class="text-xs text-gray-500">/Und.</span>
                        @elseif($producto->unidadDeMedida === 'kilos')
                            <span class="text-xs text-gray-500">/kg.</span>
                        @elseif($producto->unidadDeMedida === 'litros')
                            <span class="text-xs text-gray-500">/L.</span>
                        @endif
                    </span>
                </p>
            </a>
            @endforeach
        </div>

            @if($productos->count() > 12)
            <div class="text-center mt-6">
                <button id="btn-mostrar-productos" 
                        class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors">
                    Mostrar más productos
                </button>
            </div>
            @endif
        </section>
        @endif

        {{-- ÚLTIMOS PRODUCTOS AÑADIDOS --}}
        @if($ultimosProductos->count() > 0)
        <section class="mb-12">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Últimos Productos Añadidos</h2>
            <div class="relative">
                <div class="flex space-x-6 overflow-x-auto pb-4 scrollbar-hide">
                    @foreach($ultimosProductos as $producto)
                    <a href="{{ $producto->categoria->construirUrlCategorias($producto->slug) }}"
                    class="group flex flex-col items-center bg-white rounded-xl shadow-md transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer p-4 w-2/5 min-w-[160px] sm:w-1/4 sm:min-w-[200px] lg:w-1/5 lg:min-w-[220px]">
                        <div class="w-full flex justify-center mb-3">
                            @if($producto->imagen_pequena)
                                <img loading="lazy" src="{{ asset('images/' .$producto->imagen_pequena) }}"
                                    alt="{{ $producto->nombre }}"
                                    class="w-32 h-32 object-contain rounded-lg shadow-sm transition-all duration-300 group-hover:shadow-lg bg-gray-100">
                            @else
                                <div class="w-32 h-32 flex items-center justify-center rounded-lg bg-gradient-to-br from-blue-100 to-blue-200">
                                    <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                </div>
                            @endif
                        </div>
                        <h3 class="font-semibold text-gray-700 text-center text-sm mb-1 line-clamp-2">
                            {{ $producto->nombre }}
                        </h3>
                        <p class="text-center mb-1">
                            <span class="text-xl font-bold text-pink-600">{{ number_format($producto->precio, 2) }}€
                                @if($producto->unidadDeMedida === 'unidad')
                                    <span class="text-xs text-gray-500">/Und.</span>
                                @elseif($producto->unidadDeMedida === 'kilos')
                                    <span class="text-xs text-gray-500">/kg.</span>
                                @elseif($producto->unidadDeMedida === 'litros')
                                    <span class="text-xs text-gray-500">/L.</span>
                                @endif
                            </span>
                        </p>
                    </a>
                    @endforeach
                </div>
            </div>
        </section>
        @endif

    </main>

    {{-- FOOTER DESDE LA RUTA COMPONENTS/FOOTER --}}
    <x-footer />

    {{-- JS PARA EL MENÚ MÓVIL Y CARGA DINÁMICA --}}
    <style>
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>

    <script>

        // Determinar qué variable usar según el contexto
        const esTodasCategorias = {{ isset($categoriaActual) && $categoriaActual->nombre === 'Todas las categorías' ? 'true' : 'false' }};
        const categorias = @json($categorias ?? []);
        const subcategorias = @json($subcategorias);
        
        // Usar la variable correcta según el contexto
        const categoriasParaMostrar = esTodasCategorias ? categorias : subcategorias;
        
        const btnMostrarSubcategorias = document.getElementById('btn-mostrar-subcategorias');
        if (btnMostrarSubcategorias) {
            btnMostrarSubcategorias.addEventListener('click', function () {
                const container = document.getElementById('subcategorias-container');
                const yaRenderizadas = container.children.length;

                for (let i = yaRenderizadas; i < categoriasParaMostrar.length; i++) {
                    const cat = categoriasParaMostrar[i];

                    const div = document.createElement('div');
                    div.className = "bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-4 flex flex-col items-center text-center";

                    let imagenHtml = cat.imagen
                        ? `<img loading="lazy" src="/images/${cat.imagen}" alt="${cat.nombre}" class="w-full h-full object-contain">`
                        : `<div class="w-full h-full bg-gray-200 flex items-center justify-center rounded">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h2.586a1 1 0 01.707.293l1.414 1.414A1 1 0 009.414 5H20a1 1 0 011 1v11a1 1 0 01-1 1H4a1 1 0 01-1-1V4z"></path>
                                </svg>
                           </div>`;

                    div.innerHTML = `
                        <div class="h-24 w-24 mb-4">${imagenHtml}</div>
                        <a href="/categoria/${cat.slug}" class="text-pink-500 text-lg font-bold hover:text-pink-600">
                            <div class="flex items-center justify-center gap-2 mb-2">
                                ${cat.nombre}
                                <svg class="w-4 h-4 text-pink-500 hover:text-pink-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </div>
                        </a>
                        <hr class="border-t border-gray-300 w-60 mx-auto mb-2">
                        <ul class="text-base text-gray-700 space-y-2 text-left px-4">
                            ${(cat.hijas || []).slice(0, 10).map(hija => `
                                <li>
                                    <a href="/categoria/${hija.slug}" class="hover:text-pink-600 hover:underline transition">
                                        ${hija.nombre}
                                    </a>
                                </li>
                            `).join('')}
                        </ul>
                    `;

                    container.appendChild(div);
                }

                btnMostrarSubcategorias.style.display = 'none';
            });
        }


        // Mostrar más productos
        const productos = {!! json_encode($productos->values()) !!};
        const btnMostrarProductos = document.getElementById('btn-mostrar-productos');
if (btnMostrarProductos) {
    btnMostrarProductos.addEventListener('click', function () {
        const container = document.getElementById('productos-container');

        let html = '';
        productos.forEach(producto => {
            const padre = producto.categoria?.padre?.padre?.slug || 'categoria';
            const sub = producto.categoria?.padre?.slug || 'subcategoria';
            const subsub = producto.categoria?.slug || 'subsubcategoria';
            const unidad = producto.unidadDeMedida;
            const imagen = producto.imagen_pequena
                ? `<img loading="lazy" src="/images/${producto.imagen_pequena}" alt="${producto.nombre}" class="w-32 h-32 object-contain rounded-lg shadow-sm transition-all duration-300 group-hover:shadow-lg bg-gray-100">`
                : `<div class="w-32 h-32 flex items-center justify-center rounded-lg bg-gradient-to-br from-blue-100 to-blue-200">
                        <svg class="w-12 h-12 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                   </div>`;

            html += `
                <a href="/${padre}/${sub}/${subsub}/${producto.slug}"
                   class="group flex flex-col items-center bg-white rounded-xl shadow-md transition-all duration-300 transform hover:scale-105 hover:shadow-2xl cursor-pointer p-4">
                    <div class="w-full flex justify-center mb-3">
                        ${imagen}
                    </div>
                    <p class="font-semibold text-gray-700 text-center text-sm mb-1 line-clamp-2">${producto.nombre}</p>
                    <p class="text-center mb-1">
                        <span class="text-xs text-gray-500">Desde:</span>
                        <span class="text-xl font-bold text-pink-600">${parseFloat(producto.precio).toFixed(2)}€
                            ${unidad === 'unidad' ? '<span class="text-xs text-gray-500">/Und.</span>' :
                               unidad === 'kilos' ? '<span class="text-xs text-gray-500">/kg.</span>' :
                               unidad === 'litros' ? '<span class="text-xs text-gray-500">/L.</span>' : ''}
                        </span>
                    </p>
                </a>
            `;
        });

        container.innerHTML = html;
        btnMostrarProductos.style.display = 'none';
    });
}
    </script>
    {{-- JS PARA EL BUSCADOR DEL HEADER --}}
@stack('scripts')
</body>
</html> 