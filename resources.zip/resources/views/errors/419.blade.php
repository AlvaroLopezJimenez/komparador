<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>¡Vaya! Algo salió mal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800 min-h-screen flex flex-col">

  <x-header />

  <main class="flex-grow flex flex-col justify-center items-center px-4 text-center">
    <div class="text-6xl mb-4">⏰</div>
        <h1 class="text-3xl font-bold text-blue-600 mb-2">419 - Sesión expirada</h1>
        <p class="text-gray-700 mb-4 max-w-md">
        Tu sesión ha expirado, como un pañal olvidado. Recarga la página e inténtalo de nuevo.
        </p>
  </main>

  <x-footer />

</body>
</html>
