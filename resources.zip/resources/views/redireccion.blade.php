<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Redirigiendo...</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        html,
        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
        }

        .contenedor {
            max-width: 400px;
            padding: 2rem;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #ddd;
            border-top: 5px solid #3b82f6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 2rem auto;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        .mensaje {
            font-size: 1.2rem;
            font-weight: 500;
        }
    </style>
</head>

<body>
    <div class="contenedor">
        <div class="spinner"></div>
        <p class="mensaje">Estás siendo redirigido a la tienda...</p>
        <p class="text-sm text-gray-500">Si no ocurre nada en unos segundos, <a href="{{ $url }}" style="color:#3b82f6; font-weight:600;">haz clic aquí</a>.</p>
    </div>

    <script>
        setTimeout(() => {
            window.location.href = @json($url);
        }, 0);
    </script>
</body>

</html>