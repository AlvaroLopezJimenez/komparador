{{-- HEADER --}}
    <header class="bg-white shadow px-6 py-4 max-w-7xl mx-auto w-full">
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 w-full">

{{-- LOGO + BUSCADOR (movil/tablet) + HAMBURGUESA --}}
<div class="flex items-center w-full gap-2 lg:w-auto flex-nowrap">
    {{-- LOGO --}}
    <div class="flex items-center flex-shrink-0">
        <a href="{{ route('home') }}" class="flex items-center">
        <img src="{{ asset('images/icono.png') }}" alt="Logo móvil" class="h-10 w-auto block sm:hidden">
        <img src="{{ asset('images/logo.webp') }}" alt="Logo escritorio" class="h-12 w-auto hidden sm:block">
        </a>
    </div>

    {{-- BUSCADOR MÓVIL + TABLET --}}
    <div class="flex-1 lg:hidden">
        <div class="relative w-full">
            <form action="{{ route('buscar') }}" method="GET" class="flex w-full">
                <input type="text"
                       name="q"
                       placeholder="Buscar productos..."
                       class="flex-1 px-2 py-2 border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                       id="searchInputMobile">
                <button type="submit"
                        class="px-3 py-2 bg-blue-500 text-white rounded-r-lg hover:bg-blue-600 transition-colors text-sm">
                    Buscar
                </button>
            </form>
            {{-- SUGERENCIAS QUE MUESTRA EL BUSCADOR--}}
            <div id="sugerencias-mobile" class="max-h-72 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-b-lg shadow-lg z-50 hidden">
                {{-- Las sugerencias se cargarán aquí dinámicamente --}}
            </div>
        </div>
    </div>

    {{-- BOTÓN HAMBURGUESA --}}
    <button id="btnMenu" class="ml-2 block lg:hidden flex-shrink-0">
        <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16" />
        </svg>
    </button>
</div>


        {{-- BUSCADOR ESCRITORIO --}}
        <div class="hidden lg:block flex-1 max-w-xl mx-auto">
            <div class="relative">
                <form action="{{ route('buscar') }}" method="GET" class="flex w-full">
                    <input type="text"
                           name="q"
                           placeholder="Buscar productos..."
                           class="flex-1 px-3 py-2 border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base"
                           id="searchInput">
                    <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white rounded-r-lg hover:bg-blue-600 transition-colors text-base">
                        Buscar
                    </button>
                </form>

                {{-- SUGERENCIAS --}}
                <div id="sugerencias-desktop" class="max-h-72 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-b-lg shadow-lg z-50 hidden">
                    {{-- Las sugerencias se cargarán aquí dinámicamente --}}
                </div>
            </div>
        </div>

        {{-- NAV ESCRITORIO --}}
        <nav class="hidden lg:flex space-x-2">
            <a href="{{ route('home') }}" class="px-4 py-2 rounded text-gray-700 font-medium hover:bg-[#ef76b6] hover:text-white hover:shadow-md">Inicio</a>
            <a href="{{ route('categorias.todas') }}" class="px-4 py-2 rounded text-gray-700 font-medium hover:bg-[#ef76b6] hover:text-white hover:shadow-md">Marcas</a>
            <div class="relative group">
    <button type="button" id="btnTallasDesktop" class="px-4 py-2 rounded text-gray-700 font-medium hover:bg-[#ef76b6] hover:text-white hover:shadow-md flex items-center gap-1">
        Tallas
        <svg class="w-4 h-4 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
    </button>
    <div id="submenuTallasDesktop" class="absolute hidden top-full left-0 mt-2 w-48 bg-white shadow-md rounded-md border border-gray-200 z-50">
        <a href="{{ route('buscar', ['q' => 'talla 1']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 1</a>
        <a href="{{ route('buscar', ['q' => 'talla 2']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 2</a>
        <a href="{{ route('buscar', ['q' => 'talla 3']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 3</a>
        <a href="{{ route('buscar', ['q' => 'talla 4']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 4</a>
        <a href="{{ route('buscar', ['q' => 'talla 5']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 5</a>
        <a href="{{ route('buscar', ['q' => 'talla 6']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 6</a>
    </div>
</div>
            <a href="#" class="px-4 py-2 rounded text-gray-700 font-medium hover:bg-[#ef76b6] hover:text-white hover:shadow-md">Contacto</a>
        </nav>
    </div>
</header>



    {{-- NAV MÓVIL --}}
    <nav id="navMobile" class="hidden bg-white shadow-lg lg:hidden">
        <div class="px-6 py-4 space-y-2">
            <a href="{{ route('home') }}" class="block px-4 py-2 rounded text-gray-700 font-medium transition-all duration-200 hover:bg-[#ef76b6] hover:text-white">
                Inicio
            </a>
            <a href="#" class="block px-4 py-2 rounded text-gray-700 font-medium transition-all duration-200 hover:bg-[#ef76b6] hover:text-white">
                Marcas
            </a>
            <div>
    <button type="button" id="btnTallasMobile" class="block w-full text-left px-4 py-2 rounded text-gray-700 font-medium transition-all duration-200 hover:bg-[#ef76b6] hover:text-white">
        Tallas
    </button>
    <div id="submenuTallasMobile" class="hidden pl-6">
        <a href="{{ route('buscar', ['q' => 'talla 1']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 1</a>
        <a href="{{ route('buscar', ['q' => 'talla 2']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 2</a>
        <a href="{{ route('buscar', ['q' => 'talla 3']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 3</a>
        <a href="{{ route('buscar', ['q' => 'talla 4']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 4</a>
        <a href="{{ route('buscar', ['q' => 'talla 5']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 5</a>
        <a href="{{ route('buscar', ['q' => 'talla 6']) }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Talla 6</a>
    </div>
</div>

            <a href="#" class="block px-4 py-2 rounded text-gray-700 font-medium transition-all duration-200 hover:bg-[#ef76b6] hover:text-white">
                Contacto
            </a>
        </div>
    </nav>


    @push('scripts')
    <script>
    {{-- Menú móvil --}}
    document.getElementById('btnMenu').addEventListener('click', function() {
        const nav = document.getElementById('navMobile');
        nav.classList.toggle('hidden');
    });

    {{-- Submenú Tallas (escritorio) --}}
document.getElementById('btnTallasDesktop')?.addEventListener('click', function (e) {
    e.preventDefault();
    const submenu = document.getElementById('submenuTallasDesktop');
    submenu.classList.toggle('hidden');
});

{{-- Submenú Tallas (móvil) --}}
document.getElementById('btnTallasMobile')?.addEventListener('click', function (e) {
    e.preventDefault();
    const submenu = document.getElementById('submenuTallasMobile');
    submenu.classList.toggle('hidden');
});

    {{-- Buscador con sugerencias (funciona con ambos inputs) --}}
    const inputsBusqueda = [
        document.getElementById('searchInput'),
        document.getElementById('searchInputMobile')
    ].filter(Boolean);

    inputsBusqueda.forEach(input => {
        const contenedor = input.closest('div.relative') || input.closest('div.lg\\:hidden');
        const sugerencias = input.id === 'searchInputMobile'
    ? contenedor?.querySelector('#sugerencias-mobile')
    : contenedor?.querySelector('#sugerencias-desktop');

        if (!sugerencias) return;

        let timeoutId;

        input.addEventListener('input', function() {
            clearTimeout(timeoutId);
            const query = this.value.trim();

            if (query.length < 2) {
                sugerencias.classList.add('hidden');
                return;
            }

            timeoutId = setTimeout(() => {
                fetch(`/api/buscar-productos?q=${encodeURIComponent(query)}`)
                    .then(response => response.json())
                    .then(data => {
    if (data.length > 0) {
        let html = data.slice(0, 6).map((producto, index) => `
            <a href="${producto.url}" 
               class="block px-4 py-3 hover:bg-gray-100 border-b border-gray-200 last:border-b-0">
                <div class="flex items-center space-x-3">
                    <img src="/images/${producto.imagen_pequena || 'placeholder.jpg'}" 
                         alt="${producto.nombre}" 
                         class="w-12 h-12 object-cover rounded">
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-gray-900 truncate">${producto.nombre}</p>
                        <p class="text-lg font-bold text-pink-500">
                            ${producto.precio}€
                            ${producto.unidadDeMedida === 'unidad' ? '<span class="text-xs text-gray-500">/Und.</span>' : ''}
                            ${producto.unidadDeMedida === 'kilos' ? '<span class="text-xs text-gray-500">/kg.</span>' : ''}
                            ${producto.unidadDeMedida === 'litros' ? '<span class="text-xs text-gray-500">/L.</span>' : ''}
                        </p>
                    </div>
                </div>
            </a>
        `).join('');

        if (data.length === 7) {
            html += `
                <div class="px-4">
                    <button class="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 rounded-md transition" 
                            onclick="window.location.href='/buscar?q=${encodeURIComponent(input.value)}'">
                        Mostrar más productos
                    </button>
                </div>
            `;
        }

        sugerencias.innerHTML = html;
        sugerencias.classList.remove('hidden');
    } else {
        sugerencias.classList.add('hidden');
    }
})

                    .catch(error => {
                        console.error('Error:', error);
                        sugerencias.classList.add('hidden');
                    });
            }, 300);
        });

        {{-- Ocultar sugerencias al hacer clic fuera --}}
        document.addEventListener('click', function(e) {
            if (!input.contains(e.target) && !sugerencias.contains(e.target)) {
                sugerencias.classList.add('hidden');
            }
        });
    });
</script>
@endpush